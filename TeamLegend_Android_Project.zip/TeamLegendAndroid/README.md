# TEAM LEGEND — Native Android Application (Kotlin + Jetpack Compose)

- **Application Name:** TEAM LEGEND
- **Package Name:** `com.teamlegend.app`
- **Version:** `1.0.0` (`versionCode = 1`)
- **Min SDK / Target SDK:** Android 7.0 (API 24) / Android 15 (API 35)
- **Primary Portal Backend:** `https://teamlegendsofficial.novahost.xyz/`
- **Numbers API:** `https://all.novahost.xyz/api/all/numbers`

## 1. Building the Standalone APK in Android Studio (Free — No Play Store Required)

1. Open **Android Studio** (Ladybug / Koala or newer, JDK 17).
2. Choose **File -> Open** and select the unzipped `TeamLegendAndroid` folder.
3. Let Gradle sync download dependencies from Google Maven / Maven Central.
4. For a quick installable debug APK:
   - Run **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** (or `./gradlew assembleDebug`).
   - Output: `app/build/outputs/apk/debug/app-debug.apk`.
5. For a signed release APK suitable for direct sharing via Telegram / Google Drive / GitHub Releases:
   - Go to **Build -> Generate Signed App Bundle or APK -> APK**.
   - Create or select your own `.jks` keystore (keep it private; never commit it).
   - Select **release** build variant and finish.
   - Output: `app/build/outputs/apk/release/app-release.apk`.

## 2. Mounting the Multi-Device Signup & Approval Extension on `Main.py`

Copy `backend_extension/android_auth_approval_extension.py` next to `Main.py` and add these 2 lines inside `create_fastapi_web_app()` before `return app`:

```python
from android_auth_approval_extension import register_android_auth_routes
register_android_auth_routes(
    app=app,
    db_path="team_legend_android_auth.sqlite3",
    extract_token_fn=_extract_token,
    get_session_fn=get_web_session_from_token,
    persist_token_fn=_persist_web_token,
    web_auth_tokens_dict=web_auth_tokens,
    secret_key=SECRET_KEY,
)
```

## 3. Direct APK Installation on Android (No Play Store)

1. Download `TEAM_LEGEND_v1.0.0.apk` from your Telegram channel, Google Drive, or direct web link.
2. Tap the downloaded APK file in your Android file manager or Telegram Downloads.
3. If Android prompts for permission, enable **Allow from this source** for that specific app only (do not disable Android security globally).
4. Tap **Install** and open **TEAM LEGEND**.
5. Tap **Create Account**, submit your details, wait for Administrator approval, and sign in once approved.
