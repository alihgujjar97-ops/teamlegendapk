# Retrofit & OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
# Gson DTOs
-keep class com.teamlegend.app.data.remote.dto.** { *; }
# Room Entities
-keep class com.teamlegend.app.data.local.entity.** { *; }
