package com.teamlegend.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.teamlegend.app.presentation.navigation.TeamLegendRoot
import com.teamlegend.app.presentation.theme.TeamLegendTheme
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: TeamLegendViewModel by viewModels {
        TeamLegendViewModel.Factory((application as TeamLegendApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val session by viewModel.session.collectAsState()
            TeamLegendTheme(darkTheme = session.darkTheme) {
                TeamLegendRoot(vm = viewModel)
            }
        }
    }
}
