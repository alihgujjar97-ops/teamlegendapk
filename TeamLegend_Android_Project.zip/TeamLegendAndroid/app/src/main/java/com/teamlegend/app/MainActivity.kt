package com.teamlegend.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.ui.admin.AdminConsoleShell
import com.teamlegend.app.ui.auth.AuthFlowScreen
import com.teamlegend.app.ui.auth.ForceAdminPasswordChangeScreen
import com.teamlegend.app.ui.theme.TeamLegendTheme
import com.teamlegend.app.ui.update.MandatoryUpdateGate
import com.teamlegend.app.ui.user.UserVaultShell

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tokenManager = TokenManager(applicationContext)

        setContent {
            var darkTheme by remember { mutableStateOf(tokenManager.isDarkTheme()) }
            var loggedIn by remember { mutableStateOf(!tokenManager.getToken().isNullOrBlank()) }
            var role by remember { mutableStateOf(tokenManager.getRole()) }
            var mustChangePwd by remember { mutableStateOf(tokenManager.mustChangePassword()) }

            TeamLegendTheme(darkTheme = darkTheme) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when {
                        !loggedIn -> AuthFlowScreen(
                            tokenManager = tokenManager,
                            onAuthenticated = { r, forcePwd ->
                                role = r
                                mustChangePwd = forcePwd
                                loggedIn = true
                            }
                        )
                        role == "ADMIN" && mustChangePwd -> ForceAdminPasswordChangeScreen(
                            tokenManager = tokenManager,
                            onPasswordUpdated = { mustChangePwd = false }
                        )
                        role == "ADMIN" -> AdminConsoleShell(
                            tokenManager = tokenManager,
                            onLogout = { loggedIn = false; role = "USER"; mustChangePwd = false }
                        )
                        else -> UserVaultShell(
                            tokenManager = tokenManager,
                            isDark = darkTheme,
                            onToggleTheme = {
                                darkTheme = !darkTheme
                                tokenManager.setDarkTheme(darkTheme)
                            },
                            onLogout = { loggedIn = false; role = "USER"; mustChangePwd = false }
                        )
                    }

                    // Automatic GitHub Forced-Update Popup Gate
                    MandatoryUpdateGate()
                }
            }
        }
    }
}
