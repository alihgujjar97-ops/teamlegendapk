package com.teamlegend.app

import android.app.Application
import com.teamlegend.app.data.local.TeamLegendDatabase
import com.teamlegend.app.data.remote.NetworkClient
import com.teamlegend.app.data.remote.OtpSseClient
import com.teamlegend.app.data.repository.TeamLegendRepository
import com.teamlegend.app.security.NetworkMonitor
import com.teamlegend.app.security.SessionManager

class TeamLegendApp : Application() {
    lateinit var sessionManager: SessionManager
        private set
    lateinit var database: TeamLegendDatabase
        private set
    lateinit var repository: TeamLegendRepository
        private set

    override fun onCreate() {
        super.onCreate()
        sessionManager = SessionManager(this)
        database = TeamLegendDatabase.getInstance(this)
        val networkMonitor = NetworkMonitor(this)
        val networkClient = NetworkClient(sessionManager)
        val sseClient = OtpSseClient(sessionManager)
        repository = TeamLegendRepository(
            networkClient = networkClient,
            dao = database.dao(),
            sessionManager = sessionManager,
            networkMonitor = networkMonitor,
            sseClient = sseClient
        )
    }
}
