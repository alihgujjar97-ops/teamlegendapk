package com.teamlegend.app

import android.app.Application
import com.teamlegend.app.worker.OtpSyncWorker

class TeamLegendApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        OtpSyncWorker.schedulePeriodicSync(this)
    }
}
