package com.teamlegend.app.data.local

import android.content.Context
import androidx.room.*

@Entity(tableName = "cached_otps")
data class CachedOtpEntity(
    @PrimaryKey val id: Int,
    val phoneNumber: String,
    val sender: String,
    val otpCode: String,
    val fullMessage: String,
    val serviceName: String,
    val countryName: String,
    val receivedAt: Long
)

@Dao
interface OtpCacheDao {
    @Query("SELECT * FROM cached_otps ORDER BY receivedAt DESC LIMIT 100")
    suspend fun getRecentOtps(): List<CachedOtpEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<CachedOtpEntity>)

    @Query("DELETE FROM cached_otps")
    suspend fun clearAll()
}

@Database(entities = [CachedOtpEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun otpCacheDao(): OtpCacheDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "teamlegend_local_cache.db"
            ).build().also { INSTANCE = it }
        }
    }
}
