package com.teamlegend.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.teamlegend.app.data.local.dao.TeamLegendDao
import com.teamlegend.app.data.local.entity.*

@Database(
    entities = [
        UserProfileEntity::class,
        CachedStockEntity::class,
        CachedNumberEntity::class,
        AllocationEntity::class,
        SmsRecordEntity::class,
        WithdrawalEntity::class,
        LearningProgressEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TeamLegendDatabase : RoomDatabase() {
    abstract fun dao(): TeamLegendDao

    companion object {
        @Volatile private var INSTANCE: TeamLegendDatabase? = null

        /**
         * Versioned migration registry. Never uses fallbackToDestructiveMigration()
         * so user data and learning progress are preserved across app updates.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Reserved for future schema additions without data loss.
            }
        }

        fun getInstance(context: Context): TeamLegendDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TeamLegendDatabase::class.java,
                    "team_legend_v1.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
