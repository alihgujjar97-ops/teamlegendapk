package com.teamlegend.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.teamlegend.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TeamLegendDao {
    // User Profile
    @Query("SELECT * FROM user_profile LIMIT 1")
    fun observeUserProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUserProfile(profile: UserProfileEntity)

    @Query("DELETE FROM user_profile")
    suspend fun clearUserProfile()

    // Live Stock Cache
    @Query("SELECT * FROM cached_stock ORDER BY available DESC")
    fun observeStock(): Flow<List<CachedStockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStock(items: List<CachedStockEntity>)

    @Query("DELETE FROM cached_stock")
    suspend fun clearStock()

    // External Numbers API Cache (https://all.novahost.xyz/api/all/numbers)
    @Query("SELECT * FROM cached_numbers ORDER BY country ASC, number ASC")
    fun observeCachedNumbers(): Flow<List<CachedNumberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCachedNumbers(items: List<CachedNumberEntity>)

    @Query("DELETE FROM cached_numbers")
    suspend fun clearCachedNumbers()

    // Active Allocations
    @Query("SELECT * FROM active_allocations ORDER BY updatedAtMs DESC")
    fun observeAllocations(): Flow<List<AllocationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAllocations(items: List<AllocationEntity>)

    @Query("DELETE FROM active_allocations")
    suspend fun clearAllocations()

    // SMS & OTP Inbox
    @Query("SELECT * FROM sms_records ORDER BY updatedAtMs DESC")
    fun observeSmsRecords(): Flow<List<SmsRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSmsRecords(items: List<SmsRecordEntity>)

    @Query("DELETE FROM sms_records")
    suspend fun clearSmsRecords()

    // Withdrawals / Transactions
    @Query("SELECT * FROM withdrawal_records ORDER BY updatedAtMs DESC")
    fun observeWithdrawals(): Flow<List<WithdrawalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWithdrawals(items: List<WithdrawalEntity>)

    @Query("DELETE FROM withdrawal_records")
    suspend fun clearWithdrawals()

    // English Learning Progress (persisted locally)
    @Query("SELECT * FROM learning_progress")
    fun observeLearningProgress(): Flow<List<LearningProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLearningProgress(progress: LearningProgressEntity)

    @Query("DELETE FROM user_profile")
    suspend fun wipeProfileOnLogout()
}
