package com.teamlegend.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val userId: Long,
    val username: String,
    val role: String,
    val accountStatus: String,
    val currency: String,
    val language: String,
    val balancePkr: Double,
    val balanceUsd: Double,
    val balanceDual: String,
    val pkrWallet: String,
    val usdtWallet: String,
    val totalOtps: Int,
    val totalRefers: Int,
    val weeklyOtps: Int,
    val monthlyOtps: Int,
    val streakLine: String,
    val refLink: String,
    val shareUrl: String,
    val vipTierName: String,
    val vipTierBadge: String,
    val vipTierMult: String,
    val vipProgressPct: Int,
    val vipNextTier: String,
    val updatedAtMs: Long
)

@Entity(
    tableName = "cached_stock",
    indices = [Index(value = ["country"]), Index(value = ["service"])]
)
data class CachedStockEntity(
    @PrimaryKey val keyId: String,
    val rangeName: String,
    val service: String,
    val restrictedCli: String,
    val country: String,
    val rawCountry: String,
    val iso: String,
    val available: Int,
    val ratePkr: Double,
    val rateUsd: Double,
    val rateDual: String,
    val updatedAtMs: Long
)

@Entity(
    tableName = "cached_numbers",
    indices = [Index(value = ["country"]), Index(value = ["service"])]
)
data class CachedNumberEntity(
    @PrimaryKey val number: String,
    val country: String,
    val service: String,
    val rangeName: String,
    val status: String,
    val sourcePanel: String,
    val updatedAtMs: Long
)

@Entity(tableName = "active_allocations")
data class AllocationEntity(
    @PrimaryKey val number: String,
    val numberNoCc: String,
    val service: String,
    val country: String,
    val rangeName: String,
    val otpCount: Int,
    val origin: String,
    val latestOtp: String,
    val latestSms: String,
    val updatedAtMs: Long
)

@Entity(
    tableName = "sms_records",
    indices = [Index(value = ["fullNumber"])]
)
data class SmsRecordEntity(
    @PrimaryKey val recordKey: String,
    val maskedNumber: String,
    val fullNumber: String,
    val otpCode: String,
    val fullSms: String,
    val service: String,
    val country: String,
    val timeLabel: String,
    val updatedAtMs: Long
)

@Entity(tableName = "withdrawal_records")
data class WithdrawalEntity(
    @PrimaryKey val reqId: String,
    val amountDual: String,
    val method: String,
    val status: String,
    val timeLabel: String,
    val updatedAtMs: Long
)

@Entity(tableName = "learning_progress")
data class LearningProgressEntity(
    @PrimaryKey val lessonId: String,
    val completed: Boolean,
    val bestQuizScore: Int,
    val completedAtMs: Long
)
