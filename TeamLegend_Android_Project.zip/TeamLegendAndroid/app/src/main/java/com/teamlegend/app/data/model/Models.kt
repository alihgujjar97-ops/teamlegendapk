package com.teamlegend.app.data.model

import com.google.gson.annotations.SerializedName

data class SignupRequest(
    @SerializedName("full_name") val fullName: String,
    val username: String,
    val email: String,
    val password: String,
    @SerializedName("confirm_password") val confirmPassword: String,
    val phone: String = "",
    val whatsapp: String = "",
    @SerializedName("referral_code") val referralCode: String = ""
)

data class SignupResponse(
    val status: String,
    @SerializedName("account_id") val accountId: Int,
    val username: String,
    val message: String
)

data class LoginRequest(
    val identifier: String,
    val password: String,
    @SerializedName("device_name") val deviceName: String = "Android"
)

data class UserSessionProfile(
    val id: Int,
    @SerializedName("full_name") val fullName: String,
    val username: String,
    val email: String,
    val role: String,
    val status: String,
    @SerializedName("must_change_password") val mustChangePassword: Boolean,
    @SerializedName("referral_code") val referralCode: String
)

data class AuthResponse(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String,
    @SerializedName("expires_at") val expiresAt: Long,
    val user: UserSessionProfile
)

data class ChangePasswordRequest(
    @SerializedName("current_password") val currentPassword: String,
    @SerializedName("new_password") val newPassword: String,
    @SerializedName("confirm_new_password") val confirmNewPassword: String
)

data class WalletSummaryDto(
    @SerializedName("balance_usd") val balanceUsd: Double,
    @SerializedName("balance_pkr") val balancePkr: Double,
    @SerializedName("total_earnings_usd") val totalEarningsUsd: Double,
    @SerializedName("fx_usd_to_pkr") val fxUsdToPkr: Double
)

data class UserStatsDto(
    @SerializedName("active_numbers") val activeNumbers: Int,
    @SerializedName("total_number_requests") val totalNumberRequests: Int,
    @SerializedName("total_otps") val totalOtps: Int,
    @SerializedName("referrals_total") val referralsTotal: Int,
    @SerializedName("referrals_verified") val referralsVerified: Int
)

data class VipInfoDto(
    val rank: String,
    val multiplier: Double,
    @SerializedName("next_rank") val nextRank: String?,
    @SerializedName("otps_to_next") val otpsToNext: Int
)

data class StreakInfoDto(
    @SerializedName("current_days") val currentDays: Int,
    @SerializedName("can_claim") val canClaim: Boolean,
    @SerializedName("next_claim_at") val nextClaimAt: Long,
    @SerializedName("ladder_usd") val ladderUsd: List<Double>
)

data class OtpMessageDto(
    val id: Int,
    @SerializedName("phone_number") val phoneNumber: String,
    val sender: String,
    @SerializedName("otp_code") val otpCode: String,
    @SerializedName("full_message") val fullMessage: String? = null,
    @SerializedName("service_name") val serviceName: String,
    @SerializedName("country_name") val countryName: String,
    @SerializedName("payout_usd") val payoutUsd: Double = 0.0,
    @SerializedName("payout_pkr") val payoutPkr: Double = 0.0,
    @SerializedName("received_at") val receivedAt: Long
)

data class DashboardResponse(
    val profile: Map<String, Any>,
    val wallet: WalletSummaryDto,
    val stats: UserStatsDto,
    val vip: VipInfoDto,
    val streak: StreakInfoDto,
    @SerializedName("recent_activity") val recentActivity: List<OtpMessageDto>
)

data class StockItemDto(
    val id: Int,
    @SerializedName("phone_number") val phoneNumber: String,
    @SerializedName("country_name") val countryName: String,
    @SerializedName("country_code") val countryCode: String,
    @SerializedName("country_flag") val countryFlag: String,
    @SerializedName("service_name") val serviceName: String,
    @SerializedName("range_name") val rangeName: String,
    val prefix: String
)

data class StockResponse(
    val mode: String,
    @SerializedName("total_available") val totalAvailable: Int,
    val items: List<StockItemDto>,
    @SerializedName("synced_at") val syncedAt: Long
)

data class ClaimNumberRequest(
    @SerializedName("number_id") val numberId: Int? = null,
    @SerializedName("country_name") val countryName: String? = null,
    @SerializedName("service_name") val serviceName: String? = null,
    @SerializedName("range_name") val rangeName: String? = null,
    val prefix: String? = null
)

data class TempMailCreateRequest(
    val engine: String = "mailtm",
    @SerializedName("custom_username") val customUsername: String = "",
    val domain: String = ""
)

data class TempMailBoxDto(
    val id: Int,
    val address: String,
    val engine: String,
    val domain: String,
    @SerializedName("created_at") val createdAt: Long
)

data class ExchangeRequest(val direction: String, val amount: Double)

data class WithdrawalCreateRequest(
    val method: String,
    @SerializedName("bank_or_network") val bankOrNetwork: String = "",
    val amount: Double,
    val destination: String,
    @SerializedName("account_title") val accountTitle: String = ""
)

data class SupportTicketCreateRequest(
    val subject: String,
    val category: String = "General",
    val message: String,
    @SerializedName("attachment_url") val attachmentUrl: String = ""
)

data class AdminUserRowDto(
    val id: Int,
    @SerializedName("full_name") val fullName: String,
    val username: String,
    val email: String,
    val status: String,
    @SerializedName("balance_usd") val balanceUsd: Double,
    @SerializedName("balance_pkr") val balancePkr: Double,
    @SerializedName("total_otps") val totalOtps: Int
)

data class AdminUsersResponse(val users: List<AdminUserRowDto>)
data class GenericOkResponse(val ok: Boolean = true, val message: String = "")
