package com.teamlegend.app.data.remote

import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.model.*
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface TeamLegendApiService {
    // Authentication
    @POST("/api/v1/auth/signup")
    suspend fun signup(@Body body: SignupRequest): SignupResponse

    @POST("/api/v1/auth/login")
    suspend fun userLogin(@Body body: LoginRequest): AuthResponse

    @POST("/api/v1/auth/admin/login")
    suspend fun adminLogin(@Body body: LoginRequest): AuthResponse

    @POST("/api/v1/auth/logout")
    suspend fun logout(): GenericOkResponse

    @POST("/api/v1/auth/change-password")
    suspend fun userChangePassword(@Body body: ChangePasswordRequest): GenericOkResponse

    @POST("/api/v1/admin/change-password")
    suspend fun adminChangePassword(@Body body: ChangePasswordRequest): GenericOkResponse

    // User Vault
    @GET("/api/v1/user/dashboard")
    suspend fun getUserDashboard(): DashboardResponse

    @GET("/api/v1/numbers/stock")
    suspend fun getLiveStock(
        @Query("mode") mode: String = "all",
        @Query("country") country: String? = null,
        @Query("service") service: String? = null,
        @Query("range_name") rangeName: String? = null,
        @Query("prefix") prefix: String? = null
    ): StockResponse

    @POST("/api/v1/numbers/claim")
    suspend fun claimNumber(@Body body: ClaimNumberRequest): Map<String, Any>

    @POST("/api/v1/numbers/release/{numberId}")
    suspend fun releaseNumber(@Path("numberId") numberId: Int): GenericOkResponse

    @GET("/api/v1/otp/inbox")
    suspend fun getOtpInbox(): Map<String, Any>

    // Temp Mail (8 Engines)
    @GET("/api/v1/tempmail/mailboxes")
    suspend fun listTempMail(): Map<String, List<TempMailBoxDto>>

    @POST("/api/v1/tempmail/create")
    suspend fun createTempMail(@Body body: TempMailCreateRequest): TempMailBoxDto

    @DELETE("/api/v1/tempmail/{id}")
    suspend fun deleteTempMail(@Path("id") id: Int): GenericOkResponse

    // Wallet, Exchange, Withdrawals, Streaks, Referrals, Tickets
    @GET("/api/v1/wallet")
    suspend fun getWallet(): Map<String, Any>

    @POST("/api/v1/wallet/exchange")
    suspend fun exchangeCurrency(@Body body: ExchangeRequest): Map<String, Any>

    @POST("/api/v1/wallet/withdraw")
    suspend fun requestWithdrawal(@Body body: WithdrawalCreateRequest): Map<String, Any>

    @POST("/api/v1/rewards/claim-streak")
    suspend fun claimStreak(): Map<String, Any>

    @GET("/api/v1/referrals")
    suspend fun getReferrals(): Map<String, Any>

    @GET("/api/v1/tv-methods")
    suspend fun getTvMethods(): Map<String, Any>

    @GET("/api/v1/leaderboard")
    suspend fun getLeaderboard(): Map<String, Any>

    @GET("/api/v1/support/tickets")
    suspend fun getSupportTickets(): Map<String, Any>

    @POST("/api/v1/support/tickets")
    suspend fun createSupportTicket(@Body body: SupportTicketCreateRequest): Map<String, Any>

    // Master Admin Command Center (Single Admin RBAC)
    @GET("/api/v1/admin/overview")
    suspend fun getAdminOverview(): Map<String, Any>

    @GET("/api/v1/admin/users")
    suspend fun getAdminUsers(@Query("status_filter") statusFilter: String? = null): AdminUsersResponse

    @POST("/api/v1/admin/users/{id}/approve")
    suspend fun approveUser(@Path("id") userId: Int): GenericOkResponse

    @POST("/api/v1/admin/users/{id}/reject")
    suspend fun rejectUser(@Path("id") userId: Int, @Body body: Map<String, String>): GenericOkResponse

    @GET("/api/v1/admin/panels")
    suspend fun getAdminPanels(): Map<String, Any>

    @GET("/api/v1/admin/withdrawals")
    suspend fun getAdminWithdrawals(@Query("status_filter") statusFilter: String? = null): Map<String, Any>

    @POST("/api/v1/admin/withdrawals/{id}/{decision}")
    suspend fun decideWithdrawal(
        @Path("id") wdId: Int,
        @Path("decision") decision: String,
        @Body body: Map<String, String>
    ): GenericOkResponse

    @POST("/api/v1/admin/broadcast/start")
    suspend fun sendBroadcast(@Body body: Map<String, String>): Map<String, Any>


    @GET("/api/v1/tempmail/{id}/inbox")
    suspend fun getTempMailInbox(@Path("id") id: Int): Map<String, Any>

    @GET("/api/v1/tempmail/domains")
    suspend fun getTempMailDomains(): Map<String, Any>

    // Extended Master Admin Command Center (All 8 Modules)
    @POST("/api/v1/admin/panels")
    suspend fun saveAdminPanel(@Body body: Map<String, Any>): Map<String, Any>

    @DELETE("/api/v1/admin/panels/{id}")
    suspend fun deleteAdminPanel(@Path("id") id: String): GenericOkResponse

    @POST("/api/v1/admin/panels/{id}/toggle")
    suspend fun toggleAdminPanel(@Path("id") id: String): Map<String, Any>

    @POST("/api/v1/admin/panels/sync-all")
    suspend fun syncAllPanels(): GenericOkResponse

    @POST("/api/v1/admin/panels/harvest-cookies")
    suspend fun harvestPanelCookies(): GenericOkResponse

    @GET("/api/v1/admin/stock/ranges")
    suspend fun getAdminStockRanges(): Map<String, Any>

    @POST("/api/v1/admin/stock/upload")
    suspend fun uploadAdminStock(@Body body: Map<String, Any>): Map<String, Any>

    @DELETE("/api/v1/admin/stock/ranges/{name}")
    suspend fun deleteStockRange(@Path("name") name: String): GenericOkResponse

    @POST("/api/v1/admin/stock/flush")
    suspend fun flushAllStock(): GenericOkResponse

    @POST("/api/v1/admin/stock/cli-restriction")
    suspend fun setCliRestriction(@Body body: Map<String, Any>): Map<String, Any>

    @GET("/api/v1/admin/pricing")
    suspend fun getAdminPricing(): Map<String, Any>

    @POST("/api/v1/admin/pricing")
    suspend fun saveAdminPricing(@Body body: Map<String, Any>): Map<String, Any>

    @POST("/api/v1/admin/users/{id}/balance")
    suspend fun adjustUserBalance(@Path("id") userId: Int, @Body body: Map<String, Any>): Map<String, Any>

    @POST("/api/v1/admin/users/{id}/ban")
    suspend fun toggleBanUser(@Path("id") userId: Int): Map<String, Any>

    @GET("/api/v1/admin/abuse-shield")
    suspend fun getAbuseShield(): Map<String, Any>

    @POST("/api/v1/admin/abuse-shield")
    suspend fun saveAbuseShield(@Body body: Map<String, Any>): Map<String, Any>

    @GET("/api/v1/admin/ecosystem")
    suspend fun getEcosystem(): Map<String, Any>

    @POST("/api/v1/admin/ecosystem")
    suspend fun saveEcosystem(@Body body: Map<String, Any>): Map<String, Any>

    @POST("/api/v1/admin/tv-methods")
    suspend fun publishTvMethod(@Body body: Map<String, Any>): Map<String, Any>

    @GET("/api/v1/admin/tickets")
    suspend fun getAdminTickets(): Map<String, Any>

    @POST("/api/v1/admin/tickets/{id}/reply")
    suspend fun replyAdminTicket(@Path("id") id: Int, @Body body: Map<String, String>): GenericOkResponse

    @GET("/api/v1/admin/audit-logs")
    suspend fun getAuditLogs(): Map<String, Any>
}

class ApiClientFactory(private val tokenManager: TokenManager) {
    private val authInterceptor = Interceptor { chain ->
        val reqBuilder = chain.request().newBuilder()
        tokenManager.getToken()?.let { token ->
            reqBuilder.addHeader("Authorization", "Bearer $token")
        }
        chain.proceed(reqBuilder.build())
    }

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun createService(): TeamLegendApiService {
        val base = tokenManager.getApiBaseUrl().trimEnd('/') + "/"
        return Retrofit.Builder()
            .baseUrl(base)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TeamLegendApiService::class.java)
    }

    /** Real-time Server-Sent Events (SSE) live OTP listener. */
    fun openOtpStream(onOtpJson: (String) -> Unit): EventSource {
        val url = tokenManager.getApiBaseUrl().trimEnd('/') + "/api/v1/otp/stream"
        val request = Request.Builder().url(url).header("Accept", "text/event-stream").build()
        return EventSources.createFactory(okHttpClient).newEventSource(
            request,
            object : EventSourceListener() {
                override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                    if (type == "otp") onOtpJson(data)
                }
                override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) = Unit
            }
        )
    }
}
