package com.teamlegend.app.data.remote

import com.teamlegend.app.BuildConfig
import com.teamlegend.app.data.remote.api.NovaHostNumbersApi
import com.teamlegend.app.data.remote.api.TeamLegendPortalApi
import com.teamlegend.app.security.SessionManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class NetworkClient(private val sessionManager: SessionManager) {

    private val authInterceptor = Interceptor { chain ->
        val token = sessionManager.currentToken()
        val reqBuilder = chain.request().newBuilder()
            .header("Accept", "application/json")
        if (token.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer $token")
        }
        chain.proceed(reqBuilder.build())
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
    }

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    val numbersOkHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    @Volatile private var cachedBaseUrl: String = ""
    @Volatile private var cachedPortalApi: TeamLegendPortalApi? = null

    val portalApi: TeamLegendPortalApi
        get() {
            val currentBase = sessionManager.session.value.baseUrl
                .ifBlank { BuildConfig.BASE_PORTAL_URL }
                .let { if (it.endsWith("/")) it else "$it/" }
            val existing = cachedPortalApi
            if (existing != null && cachedBaseUrl == currentBase) return existing
            return synchronized(this) {
                val created = Retrofit.Builder()
                    .baseUrl(currentBase)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(TeamLegendPortalApi::class.java)
                cachedBaseUrl = currentBase
                cachedPortalApi = created
                created
            }
        }

    val numbersApi: NovaHostNumbersApi by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.NUMBERS_API_URL)
            .client(numbersOkHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NovaHostNumbersApi::class.java)
    }
}
