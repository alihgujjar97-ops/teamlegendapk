package com.teamlegend.app.data.remote

import com.google.gson.Gson
import com.teamlegend.app.BuildConfig
import com.teamlegend.app.data.remote.dto.LiveGroupOtpDto
import com.teamlegend.app.security.SessionManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.util.concurrent.TimeUnit

/**
 * Lifecycle-aware Server-Sent Events (SSE) client for Main.py's GET /api/stream/otp.
 * Automatically closes the socket when the collecting screen leaves composition.
 */
class OtpSseClient(private val sessionManager: SessionManager) {

    private val gson = Gson()
    private val sseClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // Required for persistent SSE stream
        .build()

    fun observeLiveOtpEvents(): Flow<LiveGroupOtpDto> = callbackFlow {
        val token = sessionManager.currentToken()
        if (token.isBlank()) {
            close()
            return@callbackFlow
        }
        val url = "${BuildConfig.BASE_PORTAL_URL.trimEnd('/')}/api/stream/otp"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "text/event-stream")
            .build()

        val factory = EventSources.createFactory(sseClient)
        val listener = object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                runCatching {
                    val map = gson.fromJson(data, Map::class.java)
                    val evtType = map["type"]?.toString() ?: ""
                    if (evtType == "live_otp" || evtType == "inbox_otp") {
                        val dto = gson.fromJson(data, LiveGroupOtpDto::class.java)
                        trySend(dto)
                    }
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                // Close flow cleanly; UI can fall back to manual/periodic refresh
                close()
            }
        }
        val source = factory.newEventSource(request, listener)
        awaitClose { source.cancel() }
    }
}
