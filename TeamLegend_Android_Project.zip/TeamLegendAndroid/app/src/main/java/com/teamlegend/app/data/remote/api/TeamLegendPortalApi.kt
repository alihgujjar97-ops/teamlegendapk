package com.teamlegend.app.data.remote.api

import com.google.gson.JsonElement
import com.teamlegend.app.data.remote.dto.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

/**
 * Verified REST API contract mapped 1-to-1 to Main.py FastAPI routes
 * plus companion android_auth_approval_extension.py routes.
 */
interface TeamLegendPortalApi {

    @GET("health")
    suspend fun getHealth(): Response<HealthResponse>

    // Existing Main.py Portal Auth (Web PIN & Master Admin)
    @POST("api/auth/login")
    suspend fun portalUserLogin(@Body body: LoginRequest): Response<AuthResponse>

    @POST("api/auth/admin-login")
    suspend fun portalAdminLogin(@Body body: LoginRequest): Response<AuthResponse>

    // Companion Android Multi-Device Registration & Approval Routes
    @POST("api/android/auth/signup")
    suspend fun androidSignup(@Body body: SignupRequest): Response<AuthResponse>

    @POST("api/android/auth/login")
    suspend fun androidLogin(@Body body: LoginRequest): Response<AuthResponse>

    @GET("api/android/auth/status")
    suspend fun checkRegistrationStatus(@Query("username") username: String): Response<RegistrationStatusResponse>

    @GET("api/android/admin/registrations")
    suspend fun listRegistrations(
        @Query("status") status: String? = null,
        @Query("q") query: String? = null
    ): Response<AdminRegistrationsResponse>

    @POST("api/android/admin/registrations/decide")
    suspend fun decideRegistration(@Body body: RegistrationDecisionRequest): Response<GenericActionResponse>

    // Verified Main.py Dashboard, Orders, Withdrawals, Portal Actions, Backup
    @GET("api/dashboard")
    suspend fun getDashboard(): Response<DashboardPayload>

    @POST("api/orders/claim")
    suspend fun claimNumber(@Body body: ClaimNumberRequest): Response<GenericActionResponse>

    @POST("api/orders/release")
    suspend fun releaseNumber(): Response<GenericActionResponse>

    @POST("api/withdraw/request")
    suspend fun requestWithdrawal(@Body body: WithdrawRequestBody): Response<GenericActionResponse>

    @POST("api/portal/action")
    suspend fun executePortalAction(@Body body: Map<String, @JvmSuppressWildcards Any>): Response<GenericActionResponse>

    @GET("api/admin/backup-zip")
    @Streaming
    suspend fun downloadServerBackupZip(): Response<ResponseBody>

    @GET("api/admin/export-numbers")
    @Streaming
    suspend fun exportNumbers(@Query("kind") kind: String = "unused"): Response<ResponseBody>
}

/**
 * Verified Numbers Aggregator API: https://all.novahost.xyz/api/all/numbers
 * Uses defensive JsonElement parsing to adapt to the live response schema safely
 * without crashing or inventing fields.
 */
interface NovaHostNumbersApi {
    @GET
    suspend fun fetchAllNumbers(@Url url: String): Response<JsonElement>

    @GET
    suspend fun fetchAllSms(@Url url: String): Response<JsonElement>
}
