package com.teamlegend.app.data.remote.dto

import com.google.gson.annotations.SerializedName

data class HealthResponse(
    val ok: Boolean = false,
    val bot: String = "",
    @SerializedName("bot_username") val botUsername: String = "",
    @SerializedName("web_enabled") val webEnabled: Boolean = false,
    @SerializedName("website_url") val websiteUrl: String = ""
)

data class LoginRequest(
    val username: String,
    val password: String,
    @SerializedName("login_mode") val loginMode: String = "user"
)

data class SignupRequest(
    val username: String,
    val password: String,
    @SerializedName("full_name") val fullName: String,
    val email: String = "",
    @SerializedName("mobile_number") val mobileNumber: String = ""
)

data class AuthResponse(
    val ok: Boolean = false,
    val token: String = "",
    val role: String = "user",
    val status: String = "",
    val username: String = "",
    @SerializedName("full_name") val fullName: String = "",
    @SerializedName("user_id") val userId: Long = 0L,
    @SerializedName("registration_id") val registrationId: Long = 0L,
    val message: String = ""
)

data class RegistrationStatusResponse(
    val ok: Boolean = false,
    val username: String = "",
    val status: String = "",
    @SerializedName("rejection_reason") val rejectionReason: String = "",
    @SerializedName("created_at") val createdAt: Double = 0.0,
    @SerializedName("updated_at") val updatedAt: Double = 0.0,
    val message: String = ""
)

data class RegistrationRecordDto(
    val id: Long = 0L,
    val username: String = "",
    @SerializedName("full_name") val fullName: String = "",
    val email: String = "",
    @SerializedName("mobile_number") val mobileNumber: String = "",
    val status: String = "pending",
    val role: String = "user",
    @SerializedName("linked_uid") val linkedUid: Long = 0L,
    @SerializedName("rejection_reason") val rejectionReason: String = "",
    @SerializedName("created_at") val createdAt: Double = 0.0,
    @SerializedName("updated_at") val updatedAt: Double = 0.0
)

data class AdminRegistrationsResponse(
    val ok: Boolean = false,
    val registrations: List<RegistrationRecordDto> = emptyList(),
    val message: String = ""
)

data class RegistrationDecisionRequest(
    @SerializedName("registration_id") val registrationId: Long,
    val decision: String,
    val reason: String = ""
)

data class GenericActionResponse(
    val ok: Boolean = false,
    val message: String = "",
    @SerializedName("req_id") val reqId: String = "",
    val numbers: List<String> = emptyList(),
    @SerializedName("user_profile") val userProfile: AdminSearchedUserDto? = null
)

data class AdminSearchedUserDto(
    val id: Long = 0L,
    val username: String = "",
    @SerializedName("balance_dual") val balanceDual: String = "",
    @SerializedName("total_otps") val totalOtps: Int = 0,
    @SerializedName("total_refers") val totalRefers: Int = 0,
    val banned: Boolean = false,
    @SerializedName("clean_mode") val cleanMode: Boolean = false
)

data class ClaimNumberRequest(
    @SerializedName("range_name") val rangeName: String = "",
    val service: String = "ALL",
    val country: String = "",
    val prefix: String = ""
)

data class WithdrawRequestBody(
    val method: String,
    val account: String,
    val title: String,
    val amount: Double
)

data class DashboardPayload(
    val ok: Boolean = false,
    @SerializedName("bot_name") val botName: String = "TEAM LEGEND",
    @SerializedName("bot_direct_url") val botDirectUrl: String = "",
    val tagline: String = "",
    val user: DashboardUserDto? = null,
    @SerializedName("global_stats") val globalStats: GlobalStatsDto? = null,
    @SerializedName("active_services_list") val activeServicesList: List<String> = emptyList(),
    val services: List<ServiceStockDto> = emptyList(),
    @SerializedName("active_orders") val activeOrders: List<ActiveOrderDto> = emptyList(),
    @SerializedName("otp_history") val otpHistory: List<OtpHistoryDto> = emptyList(),
    @SerializedName("live_group_otps") val liveGroupOtps: List<LiveGroupOtpDto> = emptyList(),
    val withdrawals: List<WithdrawalRowDto> = emptyList(),
    val tickets: List<SupportTicketDto> = emptyList(),
    val leaderboard: List<LeaderboardRowDto> = emptyList(),
    @SerializedName("admin_pending_wds") val adminPendingWds: List<AdminPendingWdDto> = emptyList(),
    @SerializedName("admin_panels") val adminPanels: List<AdminPanelDto> = emptyList(),
    @SerializedName("admin_stock_batches") val adminStockBatches: List<AdminStockBatchDto> = emptyList(),
    @SerializedName("admin_pricing") val adminPricing: AdminPricingDto? = null,
    @SerializedName("admin_open_tickets") val adminOpenTickets: List<SupportTicketDto> = emptyList(),
    val message: String = ""
)

data class VipTierDto(
    val name: String = "Bronze",
    val badge: String = "",
    val mult: String = "1.00x",
    @SerializedName("progress_pct") val progressPct: Int = 0,
    @SerializedName("next_tier") val nextTier: String = ""
)

data class DashboardUserDto(
    val id: Long = 0L,
    val username: String = "",
    val role: String = "user",
    val currency: String = "PKR",
    val language: String = "en",
    @SerializedName("balance_pkr") val balancePkr: Double = 0.0,
    @SerializedName("balance_usd") val balanceUsd: Double = 0.0,
    @SerializedName("balance_dual") val balanceDual: String = "",
    @SerializedName("pkr_wallet") val pkrWallet: String = "",
    @SerializedName("usdt_wallet") val usdtWallet: String = "",
    @SerializedName("total_otps") val totalOtps: Int = 0,
    @SerializedName("total_refers") val totalRefers: Int = 0,
    @SerializedName("weekly_otps") val weeklyOtps: Int = 0,
    @SerializedName("monthly_otps") val monthlyOtps: Int = 0,
    val streak: String = "",
    @SerializedName("ref_link") val refLink: String = "",
    @SerializedName("share_url") val shareUrl: String = "",
    @SerializedName("otp_alerts") val otpAlerts: Boolean = true,
    @SerializedName("vip_tier") val vipTier: VipTierDto? = null
)

data class GlobalStatsDto(
    @SerializedName("total_users") val totalUsers: Int = 0,
    @SerializedName("available_numbers") val availableNumbers: Int = 0,
    @SerializedName("active_ranges") val activeRanges: Int = 0,
    @SerializedName("active_services_count") val activeServicesCount: Int = 0,
    @SerializedName("today_sms") val todaySms: Int = 0,
    @SerializedName("week_sms") val weekSms: Int = 0,
    @SerializedName("rate_pkr_usd") val ratePkrUsd: Double = 280.0,
    @SerializedName("exchange_rate") val exchangeRate: String = ""
)

data class ServiceStockDto(
    val service: String = "ALL",
    @SerializedName("restricted_cli") val restrictedCli: String = "ALL",
    val country: String = "",
    @SerializedName("raw_country") val rawCountry: String = "",
    val iso: String = "XX",
    val range: String = "",
    val available: Int = 0,
    @SerializedName("rate_pkr") val ratePkr: Double = 0.0,
    @SerializedName("rate_usd") val rateUsd: Double = 0.0,
    @SerializedName("rate_dual") val rateDual: String = ""
)

data class ActiveOrderDto(
    val number: String = "",
    @SerializedName("number_no_cc") val numberNoCc: String = "",
    val service: String = "",
    val country: String = "",
    @SerializedName("raw_country") val rawCountry: String = "",
    val range: String = "",
    @SerializedName("otp_count") val otpCount: Int = 0,
    val origin: String = "WEB",
    @SerializedName("latest_otp") val latestOtp: String = "",
    @SerializedName("latest_sms") val latestSms: String = ""
)

data class OtpHistoryDto(
    val number: String = "",
    @SerializedName("full_number") val fullNumber: String = "",
    @SerializedName("otp_copy") val otpCopy: String = "",
    @SerializedName("full_sms") val fullSms: String = "",
    val service: String = "",
    val country: String = "",
    val time: String = ""
)

data class LiveGroupOtpDto(
    val flag: String = "",
    val iso: String = "",
    val country: String = "",
    val service: String = "",
    val number: String = "",
    val prefix: String = "",
    val range: String = "",
    val otp: String = "",
    val time: String = ""
)

data class WithdrawalRowDto(
    val id: String = "",
    @SerializedName("amount_dual") val amountDual: String = "",
    val method: String = "",
    val status: String = "PENDING",
    val time: String = ""
)

data class SupportTicketDto(
    val id: String = "",
    @SerializedName("user_id") val userId: Long? = null,
    val subject: String = "",
    val status: String = "OPEN",
    val reply: String = ""
)

data class LeaderboardRowDto(
    val rank: Int = 0,
    @SerializedName("rank_medal") val rankMedal: String = "",
    @SerializedName("masked_user") val maskedUser: String = "",
    val otps: Int = 0,
    val tier: String = ""
)

data class AdminPendingWdDto(
    val id: String = "",
    @SerializedName("user_id") val userId: String = "",
    val name: String = "",
    @SerializedName("amount_dual") val amountDual: String = "",
    val method: String = "",
    val address: String = ""
)

data class AdminPanelDto(
    val idx: Int = 0,
    val name: String = "",
    val type: String = "",
    @SerializedName("sms_url") val smsUrl: String = "",
    @SerializedName("numbers_url") val numbersUrl: String = "",
    @SerializedName("allowed_cli") val allowedCli: String = "ALL",
    val status: String = "ON",
    @SerializedName("login_status") val loginStatus: String = "Ready",
    @SerializedName("cookies_count") val cookiesCount: Int = 0
)

data class AdminStockBatchDto(
    val idx: Int = 0,
    @SerializedName("range_name") val rangeName: String = "",
    val country: String = "",
    val service: String = "",
    @SerializedName("total_count") val totalCount: Int = 0,
    @SerializedName("free_count") val freeCount: Int = 0,
    @SerializedName("rate_pkr") val ratePkr: Double = 0.0,
    @SerializedName("source_panel") val sourcePanel: String = ""
)

data class AdminPricingDto(
    @SerializedName("default_pkr") val defaultPkr: Double = 2.0,
    @SerializedName("default_usd") val defaultUsd: Double = 0.01,
    @SerializedName("wd_rate") val wdRate: Double = 280.0,
    @SerializedName("max_otps_per_number") val maxOtpsPerNumber: Int = 3,
    @SerializedName("peak_mult") val peakMult: Double = 1.10,
    @SerializedName("min_withdraw_pkr") val minWithdrawPkr: Double = 100.0,
    @SerializedName("min_withdraw_usdt") val minWithdrawUsdt: Double = 1.0
)
