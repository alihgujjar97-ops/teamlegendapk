package com.teamlegend.app.data.repository

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.teamlegend.app.data.local.entity.CachedNumberEntity

/**
 * Defensive parser for https://all.novahost.xyz/api/all/numbers.
 * Safely extracts available numbers without assuming a rigid undocumented schema
 * and never invents fake numbers or placeholder fields.
 */
object NumbersApiParser {

    fun parse(root: JsonElement?, nowMs: Long = System.currentTimeMillis()): List<CachedNumberEntity> {
        if (root == null || root.isJsonNull) return emptyList()
        val array: JsonArray = when {
            root.isJsonArray -> root.asJsonArray
            root.isJsonObject -> extractArrayFromObject(root.asJsonObject) ?: return emptyList()
            else -> return emptyList()
        }
        val results = mutableListOf<CachedNumberEntity>()
        val seen = mutableSetOf<String>()
        for (el in array) {
            if (el.isJsonPrimitive && el.asJsonPrimitive.isString) {
                val num = el.asString.trim()
                if (num.length >= 6 && seen.add(num)) {
                    results.add(
                        CachedNumberEntity(
                            number = num,
                            country = "Unknown",
                            service = "General",
                            rangeName = "-",
                            status = "Available",
                            sourcePanel = "all.novahost.xyz",
                            updatedAtMs = nowMs
                        )
                    )
                }
            } else if (el.isJsonObject) {
                val obj = el.asJsonObject
                val num = firstNonBlank(obj, listOf("number", "num", "phone", "msisdn", "did"))
                if (num.isNotBlank() && seen.add(num)) {
                    val country = firstNonBlank(obj, listOf("country", "country_name", "iso", "region")).ifBlank { "Global" }
                    val service = firstNonBlank(obj, listOf("service", "cli", "app", "operator")).ifBlank { "ALL" }
                    val rangeName = firstNonBlank(obj, listOf("range", "range_name", "prefix")).ifBlank { "-" }
                    val status = firstNonBlank(obj, listOf("status", "state")).ifBlank { "Available" }
                    val panel = firstNonBlank(obj, listOf("panel", "source", "provider")).ifBlank { "all.novahost.xyz" }
                    results.add(
                        CachedNumberEntity(
                            number = num,
                            country = country,
                            service = service,
                            rangeName = rangeName,
                            status = status,
                            sourcePanel = panel,
                            updatedAtMs = nowMs
                        )
                    )
                }
            }
        }
        return results
    }

    private fun extractArrayFromObject(obj: JsonObject): JsonArray? {
        val candidateKeys = listOf("numbers", "data", "results", "items", "list", "rows")
        for (k in candidateKeys) {
            val v = obj.get(k)
            if (v != null && v.isJsonArray) return v.asJsonArray
        }
        for (entry in obj.entrySet()) {
            if (entry.value.isJsonArray) return entry.value.asJsonArray
        }
        return null
    }

    private fun firstNonBlank(obj: JsonObject, keys: List<String>): String {
        for (k in keys) {
            val v = obj.get(k)
            if (v != null && v.isJsonPrimitive) {
                val s = v.asString.trim()
                if (s.isNotEmpty()) return s
            }
        }
        return ""
    }
}
