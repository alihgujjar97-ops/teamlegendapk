package com.teamlegend.app.data.repository

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.teamlegend.app.data.local.entity.SmsRecordEntity

/**
 * Defensive parser for https://all.novahost.xyz/api/all/sms (and any custom SMS API URL).
 */
object SmsApiParser {
    private val OTP_REGEX = Regex("\b\d{4,8}\b")

    fun parse(root: JsonElement?, nowMs: Long = System.currentTimeMillis()): List<SmsRecordEntity> {
        if (root == null || root.isJsonNull) return emptyList()
        val array: JsonArray = when {
            root.isJsonArray -> root.asJsonArray
            root.isJsonObject -> extractArray(root.asJsonObject) ?: return emptyList()
            else -> return emptyList()
        }
        val out = mutableListOf<SmsRecordEntity>()
        array.forEachIndexed { idx, el ->
            if (el.isJsonObject) {
                val obj = el.asJsonObject
                val num = firstOf(obj, listOf("number", "num", "phone", "to", "msisdn", "did"))
                val smsText = firstOf(obj, listOf("message", "sms", "text", "body", "content", "full_sms"))
                val explicitOtp = firstOf(obj, listOf("otp", "code", "otp_code", "pin"))
                val otp = explicitOtp.ifBlank { OTP_REGEX.find(smsText)?.value ?: "" }
                val service = firstOf(obj, listOf("service", "cli", "sender", "from", "app")).ifBlank { "SMS" }
                val country = firstOf(obj, listOf("country", "country_name", "iso", "range")).ifBlank { "Global" }
                val timeLabel = firstOf(obj, listOf("time", "timestamp", "date", "created_at", "time_str")).ifBlank { "Live" }
                if (num.isNotBlank() || smsText.isNotBlank() || otp.isNotBlank()) {
                    out.add(
                        SmsRecordEntity(
                            recordKey = "api_${num}_${otp}_${timeLabel}_$idx",
                            maskedNumber = num.ifBlank { "Unknown" },
                            fullNumber = num.ifBlank { "Unknown" },
                            otpCode = otp.ifBlank { smsText.take(40) },
                            fullSms = smsText,
                            service = service,
                            country = country,
                            timeLabel = timeLabel,
                            updatedAtMs = nowMs - idx
                        )
                    )
                }
            }
        }
        return out
    }

    private fun extractArray(obj: JsonObject): JsonArray? {
        for (k in listOf("sms", "messages", "data", "results", "items", "otps", "rows", "list")) {
            val v = obj.get(k)
            if (v != null && v.isJsonArray) return v.asJsonArray
        }
        for (entry in obj.entrySet()) {
            if (entry.value.isJsonArray) return entry.value.asJsonArray
        }
        return null
    }

    private fun firstOf(obj: JsonObject, keys: List<String>): String {
        for (k in keys) {
            val v = obj.get(k)
            if (v != null && v.isJsonPrimitive) {
                val s = v.asString.trim()
                if (s.isNotEmpty()) return s
            }
        }
        return ""
    }
}
