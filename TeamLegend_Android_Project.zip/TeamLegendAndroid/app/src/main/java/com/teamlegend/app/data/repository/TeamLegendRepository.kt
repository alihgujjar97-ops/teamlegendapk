package com.teamlegend.app.data.repository

import com.google.gson.Gson
import com.google.gson.JsonParser
import com.teamlegend.app.data.local.dao.TeamLegendDao
import com.teamlegend.app.data.local.entity.*
import com.teamlegend.app.data.remote.NetworkClient
import com.teamlegend.app.data.remote.OtpSseClient
import com.teamlegend.app.data.remote.dto.*
import com.teamlegend.app.security.NetworkMonitor
import com.teamlegend.app.security.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import retrofit2.Response

enum class DataFreshness { LIVE, CACHED, UNAVAILABLE }

sealed class RepoResult<out T> {
    data class Success<T>(val data: T, val freshness: DataFreshness = DataFreshness.LIVE, val message: String = "") : RepoResult<T>()
    data class Error(val message: String, val accountStatus: String? = null) : RepoResult<Nothing>()
}

class TeamLegendRepository(
    private val networkClient: NetworkClient,
    private val dao: TeamLegendDao,
    val sessionManager: SessionManager,
    val networkMonitor: NetworkMonitor,
    private val sseClient: OtpSseClient
) {
    private val gson = Gson()
    private val portalApi get() = networkClient.portalApi
    private val numbersApi get() = networkClient.numbersApi

    // Local Reactive Room Streams
    fun observeUserProfile(): Flow<UserProfileEntity?> = dao.observeUserProfile()
    fun observeStock(): Flow<List<CachedStockEntity>> = dao.observeStock()
    fun observeCachedNumbers(): Flow<List<CachedNumberEntity>> = dao.observeCachedNumbers()
    fun observeAllocations(): Flow<List<AllocationEntity>> = dao.observeAllocations()
    fun observeSmsRecords(): Flow<List<SmsRecordEntity>> = dao.observeSmsRecords()
    fun observeWithdrawals(): Flow<List<WithdrawalEntity>> = dao.observeWithdrawals()
    fun observeLearningProgress(): Flow<List<LearningProgressEntity>> = dao.observeLearningProgress()
    fun observeLiveOtpStream(): Flow<LiveGroupOtpDto> = sseClient.observeLiveOtpEvents()

    // =========================================================================
    // AUTHENTICATION & MULTI-DEVICE REGISTRATION APPROVAL
    // =========================================================================
    suspend fun signup(
        username: String,
        password: String,
        fullName: String,
        email: String,
        mobile: String
    ): RepoResult<AuthResponse> = withContext(Dispatchers.IO) {
        if (!networkMonitor.isOnlineNow()) {
            return@withContext RepoResult.Error("Internet connection is required to create an account.")
        }
        try {
            val resp = portalApi.androidSignup(
                SignupRequest(
                    username = username.trim(),
                    password = password,
                    fullName = fullName.trim(),
                    email = email.trim(),
                    mobileNumber = mobile.trim()
                )
            )
            val body = parseAuthOrError(resp)
            if (resp.isSuccessful && body.ok) {
                sessionManager.savePendingOrRestrictedStatus(username.trim(), "pending")
                RepoResult.Success(body, message = body.message.ifBlank { "Account created! Awaiting admin approval." })
            } else {
                val msg = if (resp.code() == 404) {
                    "Android signup endpoint not yet mounted on server. Deploy backend_extension/android_auth_approval_extension.py to Main.py."
                } else {
                    body.message.ifBlank { "Registration failed (HTTP ${resp.code()})." }
                }
                RepoResult.Error(msg)
            }
        } catch (e: Exception) {
            RepoResult.Error(friendlyNetworkError(e))
        }
    }

    suspend fun login(username: String, password: String, asAdmin: Boolean): RepoResult<AuthResponse> =
        withContext(Dispatchers.IO) {
            if (!networkMonitor.isOnlineNow()) {
                return@withContext RepoResult.Error("Internet connection is required to sign in.")
            }
            try {
                if (asAdmin) {
                    val resp = portalApi.portalAdminLogin(LoginRequest(username.trim(), password, "admin"))
                    val body = parseAuthOrError(resp)
                    if (resp.isSuccessful && body.ok && body.token.isNotBlank()) {
                        sessionManager.saveAuthenticatedSession(
                            token = body.token,
                            username = body.username.ifBlank { username.trim() },
                            fullName = body.username.ifBlank { "Administrator" },
                            role = "admin",
                            userId = body.userId
                        )
                        return@withContext RepoResult.Success(body, message = body.message)
                    }
                    return@withContext RepoResult.Error(body.message.ifBlank { "Invalid administrator credentials." })
                }

                // Try companion Android registration login first (enforces Pending/Rejected/Suspended)
                val androidResp = portalApi.androidLogin(LoginRequest(username.trim(), password, "user"))
                if (androidResp.code() != 404) {
                    val body = parseAuthOrError(androidResp)
                    if (androidResp.isSuccessful && body.ok && body.token.isNotBlank()) {
                        sessionManager.saveAuthenticatedSession(
                            token = body.token,
                            username = body.username.ifBlank { username.trim() },
                            fullName = body.fullName.ifBlank { body.username },
                            role = body.role.ifBlank { "user" },
                            userId = body.userId
                        )
                        return@withContext RepoResult.Success(body, message = body.message)
                    }
                    val st = body.status.lowercase()
                    if (st in listOf("pending", "rejected", "suspended")) {
                        sessionManager.savePendingOrRestrictedStatus(username.trim(), st)
                        return@withContext RepoResult.Error(
                            body.message.ifBlank { "Account status: $st." },
                            accountStatus = st
                        )
                    }
                    // If user is an existing Telegram Web PIN user, fall through to Main.py /api/auth/login
                }

                // Fallback to Main.py existing /api/auth/login (Telegram-linked Web PIN users)
                val portalResp = portalApi.portalUserLogin(LoginRequest(username.trim(), password, "user"))
                val pBody = parseAuthOrError(portalResp)
                if (portalResp.isSuccessful && pBody.ok && pBody.token.isNotBlank()) {
                    sessionManager.saveAuthenticatedSession(
                        token = pBody.token,
                        username = pBody.username.ifBlank { username.trim() },
                        fullName = pBody.username.ifBlank { username.trim() },
                        role = pBody.role.ifBlank { "user" },
                        userId = pBody.userId
                    )
                    RepoResult.Success(pBody, message = pBody.message)
                } else {
                    RepoResult.Error(pBody.message.ifBlank { "Invalid username or password." })
                }
            } catch (e: Exception) {
                RepoResult.Error(friendlyNetworkError(e))
            }
        }

    suspend fun checkRegistrationStatus(username: String): RepoResult<RegistrationStatusResponse> =
        withContext(Dispatchers.IO) {
            if (!networkMonitor.isOnlineNow()) {
                return@withContext RepoResult.Error("Offline — connect to internet to check approval status.")
            }
            try {
                val resp = portalApi.checkRegistrationStatus(username.trim())
                val body = resp.body()
                if (resp.isSuccessful && body != null && body.ok) {
                    if (body.status.lowercase() in listOf("pending", "rejected", "suspended")) {
                        sessionManager.savePendingOrRestrictedStatus(username.trim(), body.status.lowercase())
                    }
                    RepoResult.Success(body)
                } else {
                    RepoResult.Error("Unable to retrieve registration status (HTTP ${resp.code()}).")
                }
            } catch (e: Exception) {
                RepoResult.Error(friendlyNetworkError(e))
            }
        }

    suspend fun logout() = withContext(Dispatchers.IO) {
        sessionManager.clearSession()
        dao.clearUserProfile()
        dao.clearAllocations()
        dao.clearSmsRecords()
        dao.clearWithdrawals()
    }

    // =========================================================================
    // DASHBOARD, STOCK, ALLOCATIONS, SMS/OTP, WALLET, WITHDRAWALS
    // =========================================================================
    suspend fun refreshDashboard(): RepoResult<DashboardPayload> = withContext(Dispatchers.IO) {
        if (!networkMonitor.isOnlineNow()) {
            return@withContext RepoResult.Error("Offline — displaying cached data where available.")
        }
        try {
            val resp = portalApi.getDashboard()
            if (resp.code() == 401) {
                sessionManager.clearSession()
                return@withContext RepoResult.Error("Session expired. Please sign in again.")
            }
            val payload = resp.body()
            if (resp.isSuccessful && payload != null && payload.ok) {
                val now = System.currentTimeMillis()
                payload.user?.let { u ->
                    dao.upsertUserProfile(
                        UserProfileEntity(
                            userId = u.id,
                            username = u.username,
                            role = u.role,
                            accountStatus = "approved",
                            currency = u.currency,
                            language = u.language,
                            balancePkr = u.balancePkr,
                            balanceUsd = u.balanceUsd,
                            balanceDual = u.balanceDual,
                            pkrWallet = u.pkrWallet,
                            usdtWallet = u.usdtWallet,
                            totalOtps = u.totalOtps,
                            totalRefers = u.totalRefers,
                            weeklyOtps = u.weeklyOtps,
                            monthlyOtps = u.monthlyOtps,
                            streakLine = u.streak,
                            refLink = u.refLink,
                            shareUrl = u.shareUrl,
                            vipTierName = u.vipTier?.name ?: "Bronze",
                            vipTierBadge = u.vipTier?.badge ?: "",
                            vipTierMult = u.vipTier?.mult ?: "1.00x",
                            vipProgressPct = u.vipTier?.progressPct ?: 0,
                            vipNextTier = u.vipTier?.nextTier ?: "",
                            updatedAtMs = now
                        )
                    )
                }
                dao.clearStock()
                dao.upsertStock(
                    payload.services.mapIndexed { idx, s ->
                        CachedStockEntity(
                            keyId = "${s.range}_${s.service}_$idx",
                            rangeName = s.range,
                            service = s.service,
                            restrictedCli = s.restrictedCli,
                            country = s.country,
                            rawCountry = s.rawCountry,
                            iso = s.iso,
                            available = s.available,
                            ratePkr = s.ratePkr,
                            rateUsd = s.rateUsd,
                            rateDual = s.rateDual,
                            updatedAtMs = now
                        )
                    }
                )
                dao.clearAllocations()
                dao.upsertAllocations(
                    payload.activeOrders.map { o ->
                        AllocationEntity(
                            number = o.number,
                            numberNoCc = o.numberNoCc,
                            service = o.service,
                            country = o.country,
                            rangeName = o.range,
                            otpCount = o.otpCount,
                            origin = o.origin,
                            latestOtp = o.latestOtp,
                            latestSms = o.latestSms,
                            updatedAtMs = now
                        )
                    }
                )
                dao.upsertSmsRecords(
                    payload.otpHistory.mapIndexed { idx, r ->
                        SmsRecordEntity(
                            recordKey = "${r.fullNumber}_${r.otpCopy}_${r.time}_$idx",
                            maskedNumber = r.number,
                            fullNumber = r.fullNumber,
                            otpCode = r.otpCopy,
                            fullSms = r.fullSms,
                            service = r.service,
                            country = r.country,
                            timeLabel = r.time,
                            updatedAtMs = now - idx
                        )
                    }
                )
                dao.clearWithdrawals()
                dao.upsertWithdrawals(
                    payload.withdrawals.map { w ->
                        WithdrawalEntity(
                            reqId = w.id,
                            amountDual = w.amountDual,
                            method = w.method,
                            status = w.status,
                            timeLabel = w.time,
                            updatedAtMs = now
                        )
                    }
                )
                RepoResult.Success(payload, DataFreshness.LIVE)
            } else {
                RepoResult.Error(payload?.message?.ifBlank { "Dashboard fetch failed (HTTP ${resp.code()})." }
                    ?: "Dashboard fetch failed (HTTP ${resp.code()}).")
            }
        } catch (e: Exception) {
            RepoResult.Error(friendlyNetworkError(e))
        }
    }

    /**
     * Connects directly to https://all.novahost.xyz/api/all/numbers
     */
    suspend fun refreshNovaHostNumbers(): RepoResult<List<CachedNumberEntity>> = withContext(Dispatchers.IO) {
        if (!networkMonitor.isOnlineNow()) {
            val cached = dao.observeCachedNumbers().first()
            return@withContext if (cached.isNotEmpty()) {
                RepoResult.Success(cached, DataFreshness.CACHED, "Offline — showing cached numbers.")
            } else {
                RepoResult.Error("Offline — cannot reach all.novahost.xyz/api/all/numbers.")
            }
        }
        try {
            val resp = numbersApi.fetchAllNumbers()
            if (resp.isSuccessful) {
                val parsed = NumbersApiParser.parse(resp.body())
                dao.clearCachedNumbers()
                if (parsed.isNotEmpty()) {
                    dao.upsertCachedNumbers(parsed)
                }
                RepoResult.Success(parsed, DataFreshness.LIVE)
            } else {
                RepoResult.Error("Numbers API returned HTTP ${resp.code()}.")
            }
        } catch (e: Exception) {
            RepoResult.Error("Numbers API error: ${friendlyNetworkError(e)}")
        }
    }

    suspend fun claimNumber(rangeName: String, service: String, country: String, prefix: String): RepoResult<GenericActionResponse> =
        executeOnlineCall { portalApi.claimNumber(ClaimNumberRequest(rangeName, service, country, prefix)) }

    suspend fun releaseNumber(): RepoResult<GenericActionResponse> =
        executeOnlineCall { portalApi.releaseNumber() }

    suspend fun requestWithdrawal(method: String, account: String, title: String, amount: Double): RepoResult<GenericActionResponse> =
        executeOnlineCall { portalApi.requestWithdrawal(WithdrawRequestBody(method, account, title, amount)) }

    suspend fun portalAction(params: Map<String, Any>): RepoResult<GenericActionResponse> =
        executeOnlineCall { portalApi.executePortalAction(params) }

    // =========================================================================
    // ADMIN REGISTRATION APPROVAL (BACKEND VERIFIED)
    // =========================================================================
    suspend fun fetchAdminRegistrations(status: String? = null, query: String? = null): RepoResult<List<RegistrationRecordDto>> =
        withContext(Dispatchers.IO) {
            if (!sessionManager.session.value.isAdmin) {
                return@withContext RepoResult.Error("Administrator privileges required.")
            }
            if (!networkMonitor.isOnlineNow()) {
                return@withContext RepoResult.Error("Internet required to load registrations.")
            }
            try {
                val resp = portalApi.listRegistrations(status = status, query = query)
                val body = resp.body()
                if (resp.isSuccessful && body != null && body.ok) {
                    RepoResult.Success(body.registrations)
                } else if (resp.code() == 404) {
                    RepoResult.Error("Mount backend_extension/android_auth_approval_extension.py in Main.py to manage Android registrations.")
                } else {
                    RepoResult.Error(body?.message ?: "Failed to load registrations (HTTP ${resp.code()}).")
                }
            } catch (e: Exception) {
                RepoResult.Error(friendlyNetworkError(e))
            }
        }

    suspend fun decideRegistration(regId: Long, decision: String, reason: String = ""): RepoResult<GenericActionResponse> =
        executeOnlineCall {
            if (!sessionManager.session.value.isAdmin) {
                throw SecurityException("Admin role required")
            }
            portalApi.decideRegistration(RegistrationDecisionRequest(regId, decision, reason))
        }

    // =========================================================================
    // ENGLISH LEARNING PROGRESS (LOCAL ROOM DB)
    // =========================================================================
    suspend fun markLessonCompleted(lessonId: String, quizScore: Int) = withContext(Dispatchers.IO) {
        dao.upsertLearningProgress(
            LearningProgressEntity(
                lessonId = lessonId,
                completed = true,
                bestQuizScore = quizScore,
                completedAtMs = System.currentTimeMillis()
            )
        )
    }

    // =========================================================================
    // SAFE LOCAL BACKUP & RESTORE (EXCLUDES PASSWORDS, TOKENS & API SECRETS)
    // =========================================================================
    suspend fun createSafeLocalBackupJson(): String = withContext(Dispatchers.IO) {
        val progress = dao.observeLearningProgress().first()
        val withdrawals = dao.observeWithdrawals().first()
        val stockCount = dao.observeStock().first().size
        val payload = mapOf(
            "schema_version" to 1,
            "app" to "TEAM LEGEND",
            "exported_at_ms" to System.currentTimeMillis(),
            "note" to "Passwords, auth tokens, and API secrets are excluded for security.",
            "learning_progress" to progress,
            "withdrawal_history_snapshot" to withdrawals,
            "cached_stock_count" to stockCount
        )
        gson.toJson(payload)
    }

    suspend fun restoreSafeLocalBackupJson(rawJson: String): RepoResult<String> = withContext(Dispatchers.IO) {
        try {
            val obj = JsonParser.parseString(rawJson).asJsonObject
            if (obj.get("app")?.asString != "TEAM LEGEND" || !obj.has("schema_version")) {
                return@withContext RepoResult.Error("Invalid TEAM LEGEND backup format.")
            }
            var restoredCount = 0
            val arr = obj.getAsJsonArray("learning_progress")
            if (arr != null) {
                for (el in arr) {
                    val item = gson.fromJson(el, LearningProgressEntity::class.java)
                    if (item.lessonId.isNotBlank()) {
                        dao.upsertLearningProgress(item)
                        restoredCount++
                    }
                }
            }
            RepoResult.Success("Restored $restoredCount learning progress record(s) safely.")
        } catch (_: Exception) {
            RepoResult.Error("Backup JSON is corrupted or invalid.")
        }
    }

    private suspend fun executeOnlineCall(
        block: suspend () -> Response<GenericActionResponse>
    ): RepoResult<GenericActionResponse> = withContext(Dispatchers.IO) {
        if (!networkMonitor.isOnlineNow()) {
            return@withContext RepoResult.Error("Internet connection is required for this action.")
        }
        try {
            val resp = block()
            val body = resp.body()
            if (resp.isSuccessful && body != null && body.ok) {
                RepoResult.Success(body, message = body.message)
            } else {
                val errText = body?.message?.ifBlank { null }
                    ?: parseMessageFromErrorBody(resp)
                    ?: "Request failed (HTTP ${resp.code()})."
                RepoResult.Error(errText)
            }
        } catch (e: SecurityException) {
            RepoResult.Error("Unauthorized operation.")
        } catch (e: Exception) {
            RepoResult.Error(friendlyNetworkError(e))
        }
    }

    private fun parseAuthOrError(resp: Response<AuthResponse>): AuthResponse {
        resp.body()?.let { return it }
        val err = resp.errorBody()?.string() ?: return AuthResponse(ok = false)
        return runCatching { gson.fromJson(err, AuthResponse::class.java) }
            .getOrDefault(AuthResponse(ok = false, message = "HTTP ${resp.code()}"))
    }

    private fun parseMessageFromErrorBody(resp: Response<*>): String? {
        val raw = resp.errorBody()?.string() ?: return null
        return runCatching {
            JsonParser.parseString(raw).asJsonObject.get("message")?.asString
        }.getOrNull()
    }

    private fun friendlyNetworkError(e: Throwable): String {
        val msg = e.message?.lowercase() ?: ""
        return when {
            "timeout" in msg -> "Server request timed out. Please try again."
            "unable to resolve host" in msg -> "Unable to reach server. Check your internet connection."
            "ssl" in msg || "cert" in msg -> "Secure HTTPS connection could not be verified."
            else -> "Network error occurred. Please check your connection and retry."
        }
    }
}
