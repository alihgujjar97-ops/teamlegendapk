package com.teamlegend.app.domain

data class VocabItem(val english: String, val urdu: String, val romanUrdu: String, val example: String)
data class SentenceItem(val english: String, val urdu: String, val romanUrdu: String)
data class QuizQuestion(val prompt: String, val options: List<String>, val correctIndex: Int)

data class EnglishLesson(
    val id: String,
    val title: String,
    val level: String,
    val description: String,
    val grammarNote: String,
    val vocabulary: List<VocabItem>,
    val sentences: List<SentenceItem>,
    val quiz: List<QuizQuestion>
)

object EnglishLearningCurriculum {
    val lessons: List<EnglishLesson> = listOf(
        EnglishLesson(
            id = "lesson_greetings",
            title = "1. Everyday Greetings & Introductions",
            level = "Beginner",
            description = "Essential greetings, polite phrases, and introducing yourself clearly.",
            grammarNote = "Use 'I am' (I'm) with your name, profession, or city. Use 'Nice to meet you' only when meeting someone for the first time.",
            vocabulary = listOf(
                VocabItem("Hello / Hi", "سلام", "Salam", "Hello, how are you today?"),
                VocabItem("Thank you", "شکریہ", "Shukriya", "Thank you very much for your help."),
                VocabItem("Please", "براہ کرم", "Barah-e-karam", "Please wait a moment."),
                VocabItem("Excuse me", "معاف کیجیے", "Maaf kijiye", "Excuse me, where is the station?"),
                VocabItem("Welcome", "خوش آمدید", "Khush aamdeed", "You are always welcome here.")
            ),
            sentences = listOf(
                SentenceItem("My name is Ali and I live in Lahore.", "میرا نام علی ہے اور میں لاہور میں رہتا ہوں۔", "Mera naam Ali hai aur main Lahore mein rehta hoon."),
                SentenceItem("How are you doing today?", "آج آپ کیسے ہیں؟", "Aaj aap kaise hain?"),
                SentenceItem("I am fine, thank you.", "میں ٹھیک ہوں، شکریہ۔", "Main theek hoon, shukriya."),
                SentenceItem("Nice to meet you.", "آپ سے مل کر خوشی ہوئی۔", "Aap se mil kar khushi hui.")
            ),
            quiz = listOf(
                QuizQuestion("What is the Urdu meaning of 'Thank you'?", listOf("شکریہ (Shukriya)", "معاف کیجیے (Maaf kijiye)", "سلام (Salam)"), 0),
                QuizQuestion("Which sentence is grammatically correct?", listOf("I is Ali.", "I am Ali.", "I are Ali."), 1)
            )
        ),
        EnglishLesson(
            id = "lesson_daily_routine",
            title = "2. Daily Routine & Present Simple",
            level = "Beginner",
            description = "Talk about daily habits, work, and schedules using Present Simple tense.",
            grammarNote = "Present Simple: Subject + Base Verb (add -s/-es for he, she, it). Example: 'I work' vs 'He works'.",
            vocabulary = listOf(
                VocabItem("Wake up", "جاگنا", "Jaagna", "I wake up at 6 AM every day."),
                VocabItem("Work", "کام کرنا", "Kaam karna", "She works from home."),
                VocabItem("Study", "پڑھنا", "Parhna", "We study English every evening."),
                VocabItem("Breakfast", "ناشتہ", "Nashta", "I eat breakfast at 7:30 AM."),
                VocabItem("Schedule", "نظام الاوقات", "Nizam-ul-auqaat", "My daily schedule is very organized.")
            ),
            sentences = listOf(
                SentenceItem("I wake up early in the morning.", "میں صبح سویرے جاگتا ہوں۔", "Main subah sawere jaagta hoon."),
                SentenceItem("He goes to the office at nine o'clock.", "وہ نو بجے دفتر جاتا ہے۔", "Woh nau baje daftar jata hai."),
                SentenceItem("We practice English every night.", "ہم ہر رات انگریزی کی مشق کرتے ہیں۔", "Hum har raat Angrezi ki mashq karte hain.")
            ),
            quiz = listOf(
                QuizQuestion("Choose the correct Present Simple verb: 'She ___ English every day.'", listOf("study", "studies", "studying"), 1),
                QuizQuestion("What does 'Wake up' mean in Urdu?", listOf("سونا (Sona)", "جاگنا (Jaagna)", "کھانا (Khana)"), 1)
            )
        ),
        EnglishLesson(
            id = "lesson_work_tech",
            title = "3. Work, Online Communication & Support",
            level = "Elementary",
            description = "Practical English for professional chats, client messages, and technical support.",
            grammarNote = "Use 'Could you please...' or 'Would you mind...' to make polite professional requests.",
            vocabulary = listOf(
                VocabItem("Verify", "تصدیق کرنا", "Tasdeeq karna", "Please verify your account status."),
                VocabItem("Confirm", "پکا کرنا / تصدیق کرنا", "Pakka karna", "Could you confirm the payment details?"),
                VocabItem("Available", "دستیاب", "Dastiyab", "I am available to discuss this now."),
                VocabItem("Pending", "زیر التواء", "Zair-e-iltawa", "Your request is currently pending."),
                VocabItem("Update", "تازہ کاری / اپ ڈیٹ", "Taza kari", "Please send me an update soon.")
            ),
            sentences = listOf(
                SentenceItem("Could you please check my request?", "کیا آپ براہ کرم میری درخواست چیک کر سکتے ہیں؟", "Kya aap barah-e-karam meri darkhwast check kar sakte hain?"),
                SentenceItem("I will reply as soon as possible.", "میں جلد از جلد جواب دوں گا۔", "Main jald az jald jawab doon ga."),
                SentenceItem("Thank you for your patience.", "آپ کے صبر کا شکریہ۔", "Aap ke sabar ka shukriya.")
            ),
            quiz = listOf(
                QuizQuestion("What does 'Available' mean?", listOf("دستیاب (Dastiyab)", "زیر التواء (Zair-e-iltawa)", "بند (Band)"), 0),
                QuizQuestion("Which phrase is the most polite for a work message?", listOf("Check it now.", "Could you please check this?", "You check this."), 1)
            )
        ),
        EnglishLesson(
            id = "lesson_grammar_tenses",
            title = "4. Basic Grammar: Past, Present & Future",
            level = "Elementary",
            description = "Build clear sentences across yesterday, today, and tomorrow.",
            grammarNote = "Past Simple uses verb-2 (worked/went). Present Continuous uses am/is/are + verb-ing. Future Simple uses will + base verb.",
            vocabulary = listOf(
                VocabItem("Yesterday", "کل (گزرا ہوا)", "Kal (guzra hua)", "I completed the task yesterday."),
                VocabItem("Today", "آج", "Aaj", "I am learning new words today."),
                VocabItem("Tomorrow", "کل (آنے والا)", "Kal (aanay wala)", "We will start a new project tomorrow."),
                VocabItem("Improve", "بہتر بنانا", "Behtar banana", "Reading daily will improve your vocabulary."),
                VocabItem("Confidence", "اعتماد", "Aitemad", "Practice builds confidence.")
            ),
            sentences = listOf(
                SentenceItem("I finished my work yesterday.", "میں نے اپنا کام کل مکمل کیا۔", "Main ne apna kaam kal mukammal kiya."),
                SentenceItem("I am speaking English with confidence.", "میں اعتماد کے ساتھ انگریزی بول رہا ہوں۔", "Main aitemad ke saath Angrezi bol raha hoon."),
                SentenceItem("I will practice for twenty minutes tomorrow.", "میں کل بیس منٹ مشق کروں گا۔", "Main kal bees minute mashq karoon ga.")
            ),
            quiz = listOf(
                QuizQuestion("Which sentence is in Future Simple tense?", listOf("I worked yesterday.", "I am working now.", "I will work tomorrow."), 2),
                QuizQuestion("What is the Urdu meaning of 'Confidence'?", listOf("اعتماد (Aitemad)", "وقت (Waqt)", "مشکل (Mushkil)"), 0)
            )
        )
    )
}
