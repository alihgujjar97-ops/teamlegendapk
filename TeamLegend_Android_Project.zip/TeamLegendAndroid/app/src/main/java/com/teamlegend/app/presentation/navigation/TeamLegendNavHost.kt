package com.teamlegend.app.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.teamlegend.app.presentation.screens.*
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamLegendRoot(vm: TeamLegendViewModel) {
    val navController = rememberNavController()
    val session by vm.session.collectAsState()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "splash"

    val authRoutes = setOf("splash", "login", "signup", "pending_approval")
    val showChrome = currentRoute !in authRoutes && session.isAuthenticated

    Scaffold(
        topBar = {
            if (showChrome) {
                TopAppBar(
                    title = { Text(if (session.isAdmin) "TEAM LEGEND • ADMIN" else "TEAM LEGEND") },
                    navigationIcon = {
                        if (navController.previousBackStackEntry != null && currentRoute != "user_dashboard" && currentRoute != "admin_dashboard") {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.refreshDashboard() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (showChrome && !session.isAdmin) {
                NavigationBar {
                    val tabs = listOf(
                        Triple("Home", "user_dashboard", Icons.Default.Dashboard),
                        Triple("Numbers", "get_number", Icons.Default.Dialpad),
                        Triple("Inbox", "sms_inbox", Icons.Default.MarkEmailRead),
                        Triple("Wallet", "wallet", Icons.Default.AccountBalanceWallet),
                        Triple("Learn", "english_learning", Icons.Default.School)
                    )
                    tabs.forEach { (label, route, icon) ->
                        NavigationBarItem(
                            selected = currentRoute == route,
                            onClick = {
                                if (currentRoute != route) {
                                    navController.navigate(route) {
                                        popUpTo("user_dashboard") { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier.padding(padding)
        ) {
            composable("splash") {
                SplashScreen(vm) { dest ->
                    navController.navigate(dest) { popUpTo("splash") { inclusive = true } }
                }
            }
            composable("login") {
                LoginScreen(
                    vm = vm,
                    onNavigateSignup = { navController.navigate("signup") },
                    onLoginSuccess = { isAdmin ->
                        val dest = if (isAdmin) "admin_dashboard" else "user_dashboard"
                        navController.navigate(dest) { popUpTo("login") { inclusive = true } }
                    },
                    onRestrictedAccount = { navController.navigate("pending_approval") }
                )
            }
            composable("signup") {
                SignupScreen(
                    vm = vm,
                    onNavigateLogin = { navController.popBackStack() },
                    onRegistrationPending = {
                        navController.navigate("pending_approval") { popUpTo("signup") { inclusive = true } }
                    }
                )
            }
            composable("pending_approval") {
                PendingApprovalScreen(vm) {
                    navController.navigate("login") { popUpTo(0) { inclusive = true } }
                }
            }

            // User Screens
            composable("user_dashboard") { UserDashboardScreen(vm) { navController.navigate(it) } }
            composable("profile") {
                ProfileScreen(vm) { navController.navigate("login") { popUpTo(0) { inclusive = true } } }
            }
            composable("get_number") {
                GetNumberScreen(
                    vm = vm,
                    onSelectCountry = { navController.navigate("country_selection") },
                    onSelectService = { navController.navigate("service_selection") },
                    onOpenAllocations = { navController.navigate("number_allocation") }
                )
            }
            composable("country_selection") { CountrySelectionScreen(vm) { navController.popBackStack() } }
            composable("service_selection") { ServiceSelectionScreen(vm) { navController.popBackStack() } }
            composable("number_allocation") { NumberAllocationScreen(vm) { navController.navigate("sms_inbox") } }
            composable("live_stock") { LiveStockScreen(vm) }
            composable("sms_inbox") { SmsInboxScreen(vm) }
            composable("wallet") {
                WalletScreen(
                    vm = vm,
                    onOpenWithdraw = { navController.navigate("withdraw") },
                    onOpenTransactions = { navController.navigate("transactions") }
                )
            }
            composable("transactions") { TransactionsScreen(vm) }
            composable("invite_earn") { InviteEarnScreen(vm) }
            composable("daily_bonus") { DailyBonusScreen(vm) }
            composable("withdraw") { WithdrawScreen(vm) }
            composable("english_learning") { EnglishLearningScreen(vm) }
            composable("support") { SupportScreen(vm) }
            composable("settings") {
                SettingsScreen(
                    vm = vm,
                    onOpenBackup = { navController.navigate("backup_restore") },
                    onLogout = { navController.navigate("login") { popUpTo(0) { inclusive = true } } }
                )
            }
            composable("backup_restore") { BackupRestoreScreen(vm) }

            // Admin Screens (RBAC-enforced)
            composable("admin_dashboard") {
                AdminDashboardScreen(
                    vm = vm,
                    onNavigate = { navController.navigate(it) },
                    onLogout = { navController.navigate("login") { popUpTo(0) { inclusive = true } } }
                )
            }
            composable("admin_registrations") { AdminRegistrationManagementScreen(vm) }
            composable("admin_users") { AdminUserManagementScreen(vm) }
            composable("admin_stock") { AdminStockManagementScreen(vm) }
            composable("admin_panels") { AdminPanelConfigurationScreen(vm) }
            composable("admin_wallet") { AdminWalletManagementScreen(vm) }
            composable("admin_withdrawals") { AdminWithdrawalManagementScreen(vm) }
        }
    }
}
