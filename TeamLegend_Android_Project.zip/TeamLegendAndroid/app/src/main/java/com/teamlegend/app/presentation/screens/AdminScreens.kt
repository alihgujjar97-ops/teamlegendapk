package com.teamlegend.app.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.teamlegend.app.presentation.components.*
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel

@Composable
private fun AdminGuard(vm: TeamLegendViewModel, content: @Composable () -> Unit) {
    val session by vm.session.collectAsState()
    if (!session.isAdmin) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard("Access Denied", "Administrator authorization is required for this screen.", Icons.Default.Lock)
        }
    } else {
        content()
    }
}

@Composable
fun AdminDashboardScreen(vm: TeamLegendViewModel, onNavigate: (String) -> Unit, onLogout: () -> Unit) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val stats = ui.dashboardPayload?.globalStats

    LaunchedEffect(Unit) { vm.refreshDashboard(); vm.loadAdminRegistrations() }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ConnectivityFreshnessBanner(isOnline, ui.dashboardFreshness, ui.lastDashboardSyncMs) { vm.refreshDashboard() } }
        item { Text("Admin Command Center", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Total Users", "${stats?.totalUsers ?: 0}", "Platform total", Icons.Default.People, Modifier.weight(1f))
                MetricCard("Pending Regs", "${ui.adminRegistrations.count { it.status == "pending" }}", "Need review", Icons.Default.HowToReg, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Pending WDs", "${ui.dashboardPayload?.adminPendingWds?.size ?: 0}", "Withdrawals", Icons.Default.Payments, Modifier.weight(1f))
                MetricCard("Active Panels", "${ui.dashboardPayload?.adminPanels?.size ?: 0}", "SMS/Number APIs", Icons.Default.Dns, Modifier.weight(1f))
            }
        }
        val adminMenuItems = listOf(
            Triple("Registration Approval Queue", "admin_registrations", Icons.Default.HowToReg),
            Triple("User Management", "admin_users", Icons.Default.ManageAccounts),
            Triple("Stock Management", "admin_stock", Icons.Default.Inventory),
            Triple("API & Panel Configuration", "admin_panels", Icons.Default.SettingsEthernet),
            Triple("Wallet Management", "admin_wallet", Icons.Default.AccountBalanceWallet),
            Triple("Withdrawal Management", "admin_withdrawals", Icons.Default.Payments),
            Triple("Backup & Restore", "backup_restore", Icons.Default.Backup)
        )
        items(adminMenuItems) { (title, route, icon) ->
            Card(Modifier.fillMaxWidth().clickable { onNavigate(route) }, shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item {
            OutlinedButton(onClick = { vm.logout(onLogout) }, modifier = Modifier.fillMaxWidth()) { Text("Sign Out Admin") }
        }
    }
}

@Composable
fun AdminRegistrationManagementScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    var filter by remember { mutableStateOf("pending") }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(filter) { vm.loadAdminRegistrations(if (filter == "all") null else filter, search.ifBlank { null }) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Registration Approval", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("pending", "approved", "rejected", "suspended", "all").forEach { st ->
                    FilterChip(selected = filter == st, onClick = { filter = st }, label = { Text(st.replaceFirstChar { it.uppercase() }) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search username/name") }, modifier = Modifier.weight(1f))
                Button(onClick = { vm.loadAdminRegistrations(if (filter == "all") null else filter, search.ifBlank { null }) }) { Text("Search") }
            }
        }
        if (ui.adminRegistrations.isEmpty()) {
            item { EmptyStateCard("No Registrations Found", "No records match the selected filter.") }
        } else {
            items(ui.adminRegistrations) { r ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${r.fullName} (@${r.username})", fontWeight = FontWeight.Bold)
                        Text("Status: ${r.status.uppercase()} • Email: ${r.email.ifBlank { "-" }} • Mobile: ${r.mobileNumber.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (r.status != "approved") {
                                Button(onClick = { vm.decideRegistration(r.id, "approve") }) { Text("Approve") }
                            }
                            if (r.status == "pending") {
                                OutlinedButton(onClick = { vm.decideRegistration(r.id, "reject", "Rejected by Admin") }) { Text("Reject") }
                            }
                            if (r.status == "approved") {
                                OutlinedButton(onClick = { vm.decideRegistration(r.id, "suspend") }) { Text("Suspend") }
                            }
                            if (r.status == "suspended") {
                                Button(onClick = { vm.decideRegistration(r.id, "restore") }) { Text("Restore") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUserManagementScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Admin User Management", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("User ID or @username") }, modifier = Modifier.weight(1f))
            Button(onClick = { vm.adminSearchUser(query) }, enabled = query.isNotBlank()) { Text("Find") }
        }
        ui.adminSearchedUser?.let { u ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${u.username} (ID: ${u.id})", fontWeight = FontWeight.Bold)
                    Text("Balance: ${u.balanceDual} • OTPs: ${u.totalOtps} • Refers: ${u.totalRefers}")
                    Text("Status: ${if (u.banned) "SUSPENDED/BANNED" else "ACTIVE"}")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.adminManageUser(u.id.toString(), if (u.banned) "unban" else "ban") }) {
                            Text(if (u.banned) "Restore User" else "Suspend User")
                        }
                        OutlinedButton(onClick = { vm.adminManageUser(u.id.toString(), "reset_abuse") }) {
                            Text("Reset Cooldown")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStockManagementScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    var rangeName by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("WhatsApp") }
    var country by remember { mutableStateOf("") }
    var ratePkr by remember { mutableStateOf("2.0") }
    var numbersRaw by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Admin Stock Management", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Upload Stock Batch", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = rangeName, onValueChange = { rangeName = it }, label = { Text("Range Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = service, onValueChange = { service = it }, label = { Text("Service") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = country, onValueChange = { country = it }, label = { Text("Country") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = ratePkr, onValueChange = { ratePkr = it }, label = { Text("Rate (PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = numbersRaw, onValueChange = { numbersRaw = it }, label = { Text("Numbers (one per line)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        vm.adminUploadStock(rangeName, service, country, ratePkr.toDoubleOrNull() ?: 2.0, numbersRaw)
                        numbersRaw = ""
                    }, enabled = rangeName.isNotBlank() && numbersRaw.isNotBlank()) { Text("Upload Stock") }
                }
            }
        }
        items(ui.dashboardPayload?.adminStockBatches.orEmpty()) { b ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${b.rangeName} (${b.country})", fontWeight = FontWeight.Bold)
                        Text("${b.service} • Free: ${b.freeCount}/${b.totalCount} • ${b.ratePkr} PKR", style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { vm.adminDeleteRange(b.rangeName) }) {
                        Icon(Icons.Default.Delete, "Delete range", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPanelConfigurationScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    val session by vm.session.collectAsState()
    var portalUrlInput by remember(session.baseUrl) { mutableStateOf(session.baseUrl) }
    var numbersApiInput by remember(session.numbersApiUrl) { mutableStateOf(session.numbersApiUrl) }
    var smsApiInput by remember(session.smsApiUrl) { mutableStateOf(session.smsApiUrl) }
    var name by remember { mutableStateOf("") }
    var smsUrl by remember { mutableStateOf("") }
    var numbersUrl by remember { mutableStateOf("") }
    var allowedCli by remember { mutableStateOf("ALL") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("API & Panel Configuration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("App Live API Endpoints (Editable Anytime)", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = portalUrlInput, onValueChange = { portalUrlInput = it }, label = { Text("Portal Backend Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = numbersApiInput, onValueChange = { numbersApiInput = it }, label = { Text("Numbers API URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = smsApiInput, onValueChange = { smsApiInput = it }, label = { Text("SMS API URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { vm.saveInAppApiEndpoints(portalUrlInput, numbersApiInput, smsApiInput) }) {
                        Text("Save Live API URLs")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Add / Update Unified Panel", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Panel Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = smsUrl, onValueChange = { smsUrl = it }, label = { Text("SMS Endpoint URL") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = numbersUrl, onValueChange = { numbersUrl = it }, label = { Text("Numbers Endpoint URL") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = allowedCli, onValueChange = { allowedCli = it }, label = { Text("Allowed CLI / Service") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { vm.adminSavePanel(name, "API Panel", smsUrl, numbersUrl, allowedCli) }, enabled = name.isNotBlank()) {
                        Text("Save Panel Configuration")
                    }
                }
            }
        }
        items(ui.dashboardPayload?.adminPanels.orEmpty()) { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("${p.name} [${p.status}]", fontWeight = FontWeight.Bold)
                    Text("Type: ${p.type} • CLI: ${p.allowedCli} • Login: ${p.loginStatus}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun AdminWalletManagementScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    var targetUid by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("add_pkr") }
    var confirm by remember { mutableStateOf(false) }

    if (confirm) {
        ConfirmActionDialog(
            title = "Confirm Wallet Adjustment",
            message = "Apply $amount (${if (currency == "add_pkr") "PKR" else "USDT"}) to user ID $targetUid?",
            onConfirm = {
                confirm = false
                vm.adminManageUser(targetUid.trim(), currency, amount.toDoubleOrNull() ?: 0.0)
            },
            onDismiss = { confirm = false }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Admin Wallet Management", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() }
        OutlinedTextField(value = targetUid, onValueChange = { targetUid = it }, label = { Text("Target User ID") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = currency == "add_pkr", onClick = { currency = "add_pkr" }, label = { Text("Credit PKR") })
            FilterChip(selected = currency == "add_usdt", onClick = { currency = "add_usdt" }, label = { Text("Credit USDT") })
        }
        OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount (use negative to debit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        Button(onClick = { confirm = true }, enabled = targetUid.isNotBlank() && amount.toDoubleOrNull() != null) {
            Text("Apply Server-Validated Adjustment")
        }
    }
}

@Composable
fun AdminWithdrawalManagementScreen(vm: TeamLegendViewModel) = AdminGuard(vm) {
    val ui by vm.uiState.collectAsState()
    val pending = ui.dashboardPayload?.adminPendingWds.orEmpty()

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Pending Withdrawals (${pending.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        if (pending.isEmpty()) {
            item { EmptyStateCard("No Pending Withdrawals", "All withdrawal requests are up to date.") }
        } else {
            items(pending) { w ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("#${w.id} • ${w.name} (UID ${w.userId})", fontWeight = FontWeight.Bold)
                        Text("${w.amountDual} via ${w.method}", color = MaterialTheme.colorScheme.primary)
                        Text("Account: ${w.address}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.adminDecideWithdrawal(w.id, "approve") }) { Text("Approve") }
                            OutlinedButton(onClick = { vm.adminDecideWithdrawal(w.id, "reject") }) { Text("Reject & Refund") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BackupRestoreScreen(vm: TeamLegendViewModel) {
    val ui by vm.uiState.collectAsState()
    val session by vm.session.collectAsState()
    val clipboard = LocalClipboardManager.current
    var restoreInput by remember { mutableStateOf("") }
    var confirmRestore by remember { mutableStateOf(false) }

    if (confirmRestore) {
        ConfirmActionDialog(
            title = "Confirm Local Restore",
            message = "Restore validated learning progress from backup JSON?",
            onConfirm = { confirmRestore = false; vm.restoreSafeLocalBackup(restoreInput) },
            onDismiss = { confirmRestore = false }
        )
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Backup & Restore", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        if (session.isAdmin) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Server Full Backup (Admin)", fontWeight = FontWeight.Bold)
                        Text("Triggers Main.py's official server snapshot dispatch to Owner.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { vm.adminTriggerServerBackup() }) { Text("Trigger Server Backup") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Safe Local Backup (Credentials Excluded)", fontWeight = FontWeight.Bold)
                    Button(onClick = { vm.exportSafeLocalBackup() }) { Text("Generate Safe Backup JSON") }
                    ui.exportedBackupJson?.let { json ->
                        Text(json.take(300) + if (json.length > 300) "..." else "", style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(json)) }) { Text("Copy Backup JSON") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Restore Safe Local Backup", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = restoreInput, onValueChange = { restoreInput = it }, label = { Text("Paste validated backup JSON") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { confirmRestore = true }, enabled = restoreInput.isNotBlank()) { Text("Validate & Restore") }
                }
            }
        }
    }
}
