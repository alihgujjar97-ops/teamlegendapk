package com.teamlegend.app.presentation.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.teamlegend.app.R
import com.teamlegend.app.presentation.components.MessageBanners
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel
import com.teamlegend.app.security.InputValidator
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    vm: TeamLegendViewModel,
    onRouteResolved: (String) -> Unit
) {
    val session by vm.session.collectAsState()
    LaunchedEffect(Unit) {
        delay(900)
        when {
            session.isAuthenticated && session.isAdmin -> onRouteResolved("admin_dashboard")
            session.isAuthenticated -> onRouteResolved("user_dashboard")
            session.accountStatus in listOf("pending", "rejected", "suspended") && session.username.isNotBlank() ->
                onRouteResolved("pending_approval")
            else -> onRouteResolved("login")
        }
    }
    Box(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Image(
                painter = painterResource(id = R.drawable.team_legend_logo),
                contentDescription = "TEAM LEGEND Logo",
                modifier = Modifier.size(112.dp).clip(CircleShape)
            )
            Spacer(Modifier.height(16.dp))
            Text("TEAM LEGEND", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(
                "Instant Virtual Numbers & Real-Time OTP Delivery",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, strokeWidth = 3.dp)
        }
    }
}

@Composable
fun LoginScreen(
    vm: TeamLegendViewModel,
    onNavigateSignup: () -> Unit,
    onLoginSuccess: (isAdmin: Boolean) -> Unit,
    onRestrictedAccount: () -> Unit
) {
    val ui by vm.uiState.collectAsState()
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var isAdminMode by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Image(
            painter = painterResource(id = R.drawable.team_legend_logo),
            contentDescription = "TEAM LEGEND Logo",
            modifier = Modifier.size(84.dp).clip(CircleShape)
        )
        Spacer(Modifier.height(12.dp))
        Text("TEAM LEGEND", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text("Sign in to your account", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !isAdminMode,
                onClick = { isAdminMode = false },
                label = { Text("User Login") },
                leadingIcon = { Icon(Icons.Default.Person, null, Modifier.size(18.dp)) },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = isAdminMode,
                onClick = { isAdminMode = true },
                label = { Text("Admin Login") },
                leadingIcon = { Icon(Icons.Default.AdminPanelSettings, null, Modifier.size(18.dp)) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(12.dp))
        MessageBanners(ui.bannerMessage, localError ?: ui.errorMessage) {
            localError = null
            vm.clearMessages()
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it; localError = null },
            label = { Text(if (isAdminMode) "Admin Username" else "Username or Telegram ID") },
            leadingIcon = { Icon(Icons.Default.AccountCircle, null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; localError = null },
            label = { Text("Password") },
            leadingIcon = { Icon(Icons.Default.Lock, null) },
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle password")
                }
            },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val uErr = if (username.isBlank()) "Username is required." else null
                val pErr = InputValidator.validateLoginPassword(password)
                if (uErr != null || pErr != null) {
                    localError = uErr ?: pErr
                } else {
                    vm.login(
                        username = username,
                        password = password,
                        asAdmin = isAdminMode,
                        onAuthenticated = onLoginSuccess,
                        onRestrictedStatus = { onRestrictedAccount() }
                    )
                }
            },
            enabled = !ui.isLoading,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (ui.isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text(if (isAdminMode) "Sign In to Admin Center" else "Sign In", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(14.dp))
        if (!isAdminMode) {
            TextButton(onClick = onNavigateSignup) {
                Text("New to TEAM LEGEND? Create Account")
            }
        }
    }
}

@Composable
fun SignupScreen(
    vm: TeamLegendViewModel,
    onNavigateLogin: () -> Unit,
    onRegistrationPending: () -> Unit
) {
    val ui by vm.uiState.collectAsState()
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Create Account", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(
            "All new accounts require Administrator approval before accessing protected features.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))

        MessageBanners(ui.bannerMessage, localError ?: ui.errorMessage) {
            localError = null
            vm.clearMessages()
        }

        OutlinedTextField(
            value = username,
            onValueChange = { username = it; localError = null },
            label = { Text("Username *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; localError = null },
            label = { Text("Password * (min 8 chars, letters + numbers)") },
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Toggle password")
                }
            },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it; localError = null },
            label = { Text("Full Name *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; localError = null },
            label = { Text("Email (Optional)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = mobile,
            onValueChange = { mobile = it; localError = null },
            label = { Text("Mobile Number (Optional)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val err = InputValidator.validateUsername(username)
                    ?: InputValidator.validatePassword(password)
                    ?: InputValidator.validateFullName(fullName)
                    ?: InputValidator.validateOptionalEmail(email)
                    ?: InputValidator.validateOptionalMobile(mobile)
                if (err != null) {
                    localError = err
                } else {
                    vm.signup(username, password, fullName, email, mobile, onPendingCreated = onRegistrationPending)
                }
            },
            enabled = !ui.isLoading,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (ui.isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Create Account", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onNavigateLogin) {
            Text("Already have an account? Sign In")
        }
    }
}

@Composable
fun PendingApprovalScreen(
    vm: TeamLegendViewModel,
    onBackToLogin: () -> Unit
) {
    val session by vm.session.collectAsState()
    val ui by vm.uiState.collectAsState()
    val status = session.accountStatus.lowercase()

    val (icon, title, subtitle) = when (status) {
        "rejected" -> Triple(
            Icons.Default.Cancel,
            "Registration Rejected",
            "Your registration for '${session.username}' was not approved. Please contact TEAM LEGEND Support."
        )
        "suspended" -> Triple(
            Icons.Default.Block,
            "Account Suspended",
            "Your account '${session.username}' has been suspended by an Administrator. Protected features are locked."
        )
        else -> Triple(
            Icons.Default.HourglassTop,
            "Pending Administrator Approval",
            "Your account '${session.username}' is registered and waiting for Administrator review. You will be able to sign in once approved."
        )
    }

    Box(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        vm.checkApprovalStatus(session.username) { onBackToLogin() }
                    },
                    enabled = !ui.isLoading && session.username.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Check Approval Status")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { vm.logout(onBackToLogin) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Back to Login")
                }
            }
        }
    }
}
