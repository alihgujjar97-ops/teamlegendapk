package com.teamlegend.app.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teamlegend.app.presentation.components.*
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel

@Composable
fun UserDashboardScreen(
    vm: TeamLegendViewModel,
    onNavigate: (String) -> Unit
) {
    val ui by vm.uiState.collectAsState()
    val profile by vm.userProfile.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val stock by vm.stockItems.collectAsState()
    val allocations by vm.allocations.collectAsState()

    LaunchedEffect(Unit) {
        if (ui.dashboardPayload == null) vm.refreshDashboard()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            ConnectivityFreshnessBanner(isOnline, ui.dashboardFreshness, ui.lastDashboardSyncMs) {
                vm.refreshDashboard()
            }
        }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(profile?.username ?: "Loading...", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(
                                "Status: ${profile?.accountStatus?.uppercase() ?: "PENDING SYNC"} • ${profile?.vipTierName ?: "Bronze"} (${profile?.vipTierMult ?: "1.00x"})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { onNavigate("profile") }) {
                            Icon(Icons.Default.Person, contentDescription = "Profile")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Wallet Balance", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        profile?.balanceDual?.ifBlank { "Unavailable" } ?: "Sync to load balance",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Total OTPs", "${profile?.totalOtps ?: 0}", "Weekly: ${profile?.weeklyOtps ?: 0}", Icons.Default.Sms, Modifier.weight(1f))
                MetricCard("Available Stock", "${stock.sumOf { it.available }}", "${stock.size} ranges", Icons.Default.Inventory2, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Referrals", "${profile?.totalRefers ?: 0}", "Invite & Earn", Icons.Default.GroupAdd, Modifier.weight(1f))
                MetricCard("Active Numbers", "${allocations.size}", "Allocated now", Icons.Default.SimCard, Modifier.weight(1f))
            }
        }
        item {
            Text("Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        val actions = listOf(
            Triple("Get Number", "get_number", Icons.Default.Dialpad),
            Triple("Live Stock", "live_stock", Icons.Default.Storage),
            Triple("SMS / OTP Inbox", "sms_inbox", Icons.Default.MarkEmailRead),
            Triple("Active Allocations", "number_allocation", Icons.Default.PhonelinkSetup),
            Triple("Wallet & Exchange", "wallet", Icons.Default.AccountBalanceWallet),
            Triple("Withdraw Funds", "withdraw", Icons.Default.Payments),
            Triple("Daily Bonus", "daily_bonus", Icons.Default.CardGiftcard),
            Triple("Invite & Earn", "invite_earn", Icons.Default.Share),
            Triple("English Learning", "english_learning", Icons.Default.School),
            Triple("Support", "support", Icons.Default.SupportAgent),
            Triple("Settings", "settings", Icons.Default.Settings)
        )
        items(actions.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for ((title, route, icon) in row) {
                    Card(
                        modifier = Modifier.weight(1f).clickable { onNavigate(route) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ProfileScreen(vm: TeamLegendViewModel, onLogout: () -> Unit) {
    val profile by vm.userProfile.collectAsState()
    val session by vm.session.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("User Profile", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Username: ${profile?.username ?: session.username}", fontWeight = FontWeight.SemiBold)
                Text("User ID: ${profile?.userId ?: session.userId}")
                Text("Role: ${session.role.uppercase()}")
                Text("Account Status: ${session.accountStatus.uppercase()}")
                Text("VIP Tier: ${profile?.vipTierName ?: "Bronze"} (${profile?.vipTierMult ?: "1.00x"})")
                Text("Total OTPs: ${profile?.totalOtps ?: 0} • Monthly: ${profile?.monthlyOtps ?: 0}")
                Text("Preferred Currency: ${profile?.currency ?: "PKR"}")
                Text("Language: ${profile?.language ?: session.language}")
            }
        }
        Button(onClick = { vm.logout(onLogout) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
            Icon(Icons.Default.Logout, null)
            Spacer(Modifier.width(8.dp))
            Text("Sign Out")
        }
    }
}

@Composable
fun GetNumberScreen(
    vm: TeamLegendViewModel,
    onSelectCountry: () -> Unit,
    onSelectService: () -> Unit,
    onOpenAllocations: () -> Unit
) {
    val ui by vm.uiState.collectAsState()
    val stock by vm.stockItems.collectAsState()
    val apiNumbers by vm.novaHostNumbers.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    var prefixInput by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        if (apiNumbers.isEmpty()) vm.refreshNovaHostNumbers()
    }

    val filteredStock = stock.filter {
        (ui.selectedCountryFilter == "ALL" || it.country.contains(ui.selectedCountryFilter, true)) &&
            (ui.selectedServiceFilter == "ALL" || it.service.equals(ui.selectedServiceFilter, true))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            ConnectivityFreshnessBanner(isOnline, ui.numbersFreshness, ui.lastNumbersSyncMs) {
                vm.refreshDashboard()
                vm.refreshNovaHostNumbers()
            }
        }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSelectCountry, modifier = Modifier.weight(1f)) {
                    Text("Country: ${ui.selectedCountryFilter}")
                }
                OutlinedButton(onClick = onSelectService, modifier = Modifier.weight(1f)) {
                    Text("Service: ${ui.selectedServiceFilter}")
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = prefixInput,
                    onValueChange = { prefixInput = it },
                    label = { Text("Optional Prefix (e.g. 92, 44)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        vm.claimNumber("", ui.selectedServiceFilter, if (ui.selectedCountryFilter == "ALL") "" else ui.selectedCountryFilter, prefixInput)
                    },
                    enabled = isOnline && !ui.isLoading
                ) {
                    Text("Claim")
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Available Ranges (${filteredStock.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = onOpenAllocations) { Text("My Allocations") }
            }
        }
        if (filteredStock.isEmpty()) {
            item { EmptyStateCard("No Matching Ranges", "Adjust country/service filters or refresh stock.") }
        } else {
            items(filteredStock) { s ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${s.country} • ${s.service}", fontWeight = FontWeight.Bold)
                            Text("Range: ${s.rangeName} | Free: ${s.available} | Rate: ${s.rateDual}", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            onClick = { vm.claimNumber(s.rangeName, s.service, s.rawCountry, "") },
                            enabled = isOnline && !ui.isLoading && s.available > 0
                        ) { Text("Allocate") }
                    }
                }
            }
        }
        item {
            Text("Live Numbers API (all.novahost.xyz) — ${apiNumbers.size} loaded", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (apiNumbers.isEmpty()) {
            item { EmptyStateCard("No External API Numbers", "Tap refresh to fetch from https://all.novahost.xyz/api/all/numbers.") }
        } else {
            items(apiNumbers.take(50)) { n ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(n.number, fontWeight = FontWeight.Bold)
                            Text("${n.country} • ${n.service} • ${n.rangeName}", style = MaterialTheme.typography.bodySmall)
                        }
                        AssistChip(onClick = {}, label = { Text(n.status) })
                    }
                }
            }
        }
    }
}

@Composable
fun CountrySelectionScreen(vm: TeamLegendViewModel, onBack: () -> Unit) {
    val stock by vm.stockItems.collectAsState()
    val countries = remember(stock) { listOf("ALL") + stock.map { it.country }.distinct().sorted() }
    var search by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Select Country", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search country") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(countries.filter { it.contains(search, true) }) { c ->
                Card(Modifier.fillMaxWidth().clickable { vm.setCountryFilter(c); onBack() }) {
                    Text(c, modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun ServiceSelectionScreen(vm: TeamLegendViewModel, onBack: () -> Unit) {
    val stock by vm.stockItems.collectAsState()
    val services = remember(stock) { listOf("ALL") + stock.map { it.service }.distinct().sorted() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Select Service", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(services) { s ->
                Card(Modifier.fillMaxWidth().clickable { vm.setServiceFilter(s); onBack() }) {
                    Text(s, modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun NumberAllocationScreen(vm: TeamLegendViewModel, onOpenInbox: () -> Unit) {
    val allocations by vm.allocations.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val clipboard = LocalClipboardManager.current
    var showReleaseDialog by remember { mutableStateOf(false) }

    if (showReleaseDialog) {
        ConfirmActionDialog(
            title = "Release Active Numbers?",
            message = "This will release your currently allocated web/app number(s).",
            confirmLabel = "Release",
            onConfirm = { showReleaseDialog = false; vm.releaseNumber() },
            onDismiss = { showReleaseDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Active Number Allocations", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        if (allocations.isEmpty()) {
            item { EmptyStateCard("No Active Allocations", "Allocate a number from Get Number to receive OTPs.") }
        } else {
            items(allocations) { a ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(a.number, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        Text("${a.country} • ${a.service} • Range: ${a.rangeName}", style = MaterialTheme.typography.bodySmall)
                        Text("Origin: ${a.origin} • OTPs Received: ${a.otpCount}", style = MaterialTheme.typography.bodySmall)
                        if (a.latestOtp.isNotBlank()) {
                            Text("Latest OTP: ${a.latestOtp}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(a.number)) }) { Text("Copy") }
                            OutlinedButton(onClick = onOpenInbox) { Text("SMS Inbox") }
                            OutlinedButton(onClick = { vm.swapDeadNumber() }, enabled = isOnline) { Text("Replace") }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = { showReleaseDialog = true },
                    enabled = isOnline,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Release Active Number(s)") }
            }
        }
    }
}

@Composable
fun LiveStockScreen(vm: TeamLegendViewModel) {
    val stock by vm.stockItems.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    var query by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ConnectivityFreshnessBanner(isOnline, ui.dashboardFreshness, ui.lastDashboardSyncMs) { vm.refreshDashboard(); vm.refreshNovaHostSms() } }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Filter by country, service, or range") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        val filtered = stock.filter {
            query.isBlank() || it.country.contains(query, true) || it.service.contains(query, true) || it.rangeName.contains(query, true)
        }
        if (filtered.isEmpty()) {
            item { EmptyStateCard("No Stock Available", "Refresh to load live stock from server.") }
        } else {
            items(filtered) { item ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${item.country} • ${item.service}", fontWeight = FontWeight.Bold)
                            Text("Range: ${item.rangeName} | Rate: ${item.rateDual}", style = MaterialTheme.typography.bodySmall)
                        }
                        Badge { Text("${item.available} free", modifier = Modifier.padding(4.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun SmsInboxScreen(vm: TeamLegendViewModel) {
    val smsList by vm.smsRecords.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val clipboard = LocalClipboardManager.current

    // Lifecycle-aware SSE stream: starts only while this screen is active, stops on dispose!
    LaunchedEffect(isOnline) {
        if (isOnline) vm.refreshNovaHostSms()
    }
    DisposableEffect(isOnline) {
        if (isOnline) vm.startLiveOtpStream()
        onDispose { vm.stopLiveOtpStream() }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ConnectivityFreshnessBanner(isOnline, ui.dashboardFreshness, ui.lastDashboardSyncMs) { vm.refreshDashboard(); vm.refreshNovaHostSms() } }
        item { Text("Your Allocated Number SMS & OTP Inbox", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (smsList.isEmpty()) {
            item { EmptyStateCard("No SMS Messages Yet", "Received OTPs for your allocated numbers will appear here automatically.") }
        } else {
            items(smsList) { sms ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${sms.country} • ${sms.service}", fontWeight = FontWeight.Bold)
                            Text(sms.timeLabel, style = MaterialTheme.typography.labelSmall)
                        }
                        Text("Number: ${sms.fullNumber}", style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("OTP: ${sms.otpCode}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = { clipboard.setText(AnnotatedString(sms.otpCode)) }) { Text("Copy OTP") }
                        }
                        if (sms.fullSms.isNotBlank()) {
                            Text(sms.fullSms, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
