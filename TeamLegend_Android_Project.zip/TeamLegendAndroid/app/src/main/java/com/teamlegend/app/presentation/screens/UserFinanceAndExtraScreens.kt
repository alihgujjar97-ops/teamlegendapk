package com.teamlegend.app.presentation.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.teamlegend.app.BuildConfig
import com.teamlegend.app.domain.EnglishLearningCurriculum
import com.teamlegend.app.domain.EnglishLesson
import com.teamlegend.app.presentation.components.*
import com.teamlegend.app.presentation.viewmodel.TeamLegendViewModel
import com.teamlegend.app.security.InputValidator

@Composable
fun WalletScreen(vm: TeamLegendViewModel, onOpenWithdraw: () -> Unit, onOpenTransactions: () -> Unit) {
    val profile by vm.userProfile.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    var exAmount by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("PKR_TO_USDT") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Wallet & Earnings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Combined Balance", style = MaterialTheme.typography.labelMedium)
                Text(profile?.balanceDual?.ifBlank { "Unavailable" } ?: "Not loaded", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                Text("PKR Wallet: ${profile?.pkrWallet ?: "-"} | USDT Wallet: ${profile?.usdtWallet ?: "-"}", style = MaterialTheme.typography.bodySmall)
                Text("Exchange Rate: ${ui.dashboardPayload?.globalStats?.exchangeRate ?: "Server-defined"}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onOpenWithdraw, modifier = Modifier.weight(1f)) { Text("Withdraw") }
            OutlinedButton(onClick = onOpenTransactions, modifier = Modifier.weight(1f)) { Text("History") }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Currency Exchange (Server-Validated)", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = direction == "PKR_TO_USDT", onClick = { direction = "PKR_TO_USDT" }, label = { Text("PKR → USDT") })
                    FilterChip(selected = direction == "USDT_TO_PKR", onClick = { direction = "USDT_TO_PKR" }, label = { Text("USDT → PKR") })
                }
                OutlinedTextField(
                    value = exAmount,
                    onValueChange = { exAmount = it },
                    label = { Text("Amount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { exAmount.toDoubleOrNull()?.let { vm.exchangeCurrency(direction, it) } },
                    enabled = isOnline && !ui.isLoading && (exAmount.toDoubleOrNull() ?: 0.0) > 0.0
                ) { Text("Convert Currency") }
            }
        }
    }
}

@Composable
fun TransactionsScreen(vm: TeamLegendViewModel) {
    val withdrawals by vm.withdrawals.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Withdrawal & Transaction History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (withdrawals.isEmpty()) {
            item { EmptyStateCard("No Transactions Yet", "Your verified withdrawal requests and status updates appear here.") }
        } else {
            items(withdrawals) { w ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("#${w.reqId} • ${w.method}", fontWeight = FontWeight.Bold)
                            Text("${w.amountDual} • ${w.timeLabel}", style = MaterialTheme.typography.bodySmall)
                        }
                        AssistChip(onClick = {}, label = { Text(w.status) })
                    }
                }
            }
        }
    }
}

@Composable
fun InviteEarnScreen(vm: TeamLegendViewModel) {
    val profile by vm.userProfile.collectAsState()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val refLink = profile?.refLink ?: ""

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Invite & Earn", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        MetricCard("Total Referrals", "${profile?.totalRefers ?: 0}", "Validated on server", Icons.Default.GroupAdd, Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your Referral Link", fontWeight = FontWeight.Bold)
                Text(refLink.ifBlank { "Sign in and refresh dashboard to load your official referral link." }, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { clipboard.setText(AnnotatedString(refLink)) },
                        enabled = refLink.isNotBlank()
                    ) { Text("Copy Link") }
                    OutlinedButton(
                        onClick = {
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                putExtra(Intent.EXTRA_TEXT, "Join TEAM LEGEND: $refLink")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Referral Link"))
                        },
                        enabled = refLink.isNotBlank()
                    ) { Text("Share") }
                }
            }
        }
    }
}

@Composable
fun DailyBonusScreen(vm: TeamLegendViewModel) {
    val profile by vm.userProfile.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Daily Streak Bonus", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CardGiftcard, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                Text(profile?.streakLine?.ifBlank { "Server-validated daily streak reward" } ?: "Connect to load streak status", fontWeight = FontWeight.SemiBold)
                Text("Eligibility and daily reset are strictly enforced by the server clock.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = { vm.claimDailyBonus() },
                    enabled = isOnline && !ui.isLoading,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Claim Daily Bonus") }
            }
        }
    }
}

@Composable
fun WithdrawScreen(vm: TeamLegendViewModel) {
    val profile by vm.userProfile.collectAsState()
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val methods = listOf("EasyPaisa", "JazzCash", "SadaPay", "NayaPay", "Bank Transfer", "USDT TRC20", "Binance Pay")
    var selectedMethod by remember { mutableStateOf(methods.first()) }
    var amount by remember { mutableStateOf("") }
    var account by remember { mutableStateOf("") }
    var title by remember { mutableStateOf(profile?.username ?: "") }
    var localErr by remember { mutableStateOf<String?>(null) }
    var confirmOpen by remember { mutableStateOf(false) }

    val isUsdt = selectedMethod.contains("USDT", true) || selectedMethod.contains("Binance", true)
    val avail = if (isUsdt) (profile?.balanceUsd ?: 0.0) else (profile?.balancePkr ?: 0.0)
    val minAmt = if (isUsdt) 1.0 else 100.0

    if (confirmOpen) {
        ConfirmActionDialog(
            title = "Confirm Withdrawal Request",
            message = "Submit withdrawal of $amount ${if (isUsdt) "USDT" else "PKR"} via $selectedMethod to $account? Administrator approval is required.",
            onConfirm = {
                confirmOpen = false
                vm.submitWithdrawal(selectedMethod, account.trim(), title.trim(), amount.toDouble())
            },
            onDismiss = { confirmOpen = false }
        )
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Withdraw Earnings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Available: ${profile?.balanceDual ?: "Sync dashboard first"}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
        item { MessageBanners(ui.bannerMessage, localErr ?: ui.errorMessage) { localErr = null; vm.clearMessages() } }
        item {
            Text("Select Payment Method", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                methods.take(4).forEach { m ->
                    FilterChip(selected = selectedMethod == m, onClick = { selectedMethod = m }, label = { Text(m) })
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                methods.drop(4).forEach { m ->
                    FilterChip(selected = selectedMethod == m, onClick = { selectedMethod = m }, label = { Text(m) })
                }
            }
        }
        item {
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it; localErr = null },
                label = { Text("Amount (${if (isUsdt) "USDT, min $minAmt" else "PKR, min $minAmt"})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = account,
                onValueChange = { account = it; localErr = null },
                label = { Text("Account Number / Wallet Address") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Account Holder Title") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    val err = InputValidator.validateWithdrawal(amount, account, avail, minAmt)
                    if (err != null) localErr = err else confirmOpen = true
                },
                enabled = isOnline && !ui.isLoading,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text("Submit Withdrawal Request") }
        }
    }
}

@Composable
fun EnglishLearningScreen(vm: TeamLegendViewModel) {
    val progressList by vm.learningProgress.collectAsState()
    val completedIds = remember(progressList) { progressList.filter { it.completed }.map { it.lessonId }.toSet() }
    var activeLesson by remember { mutableStateOf<EnglishLesson?>(null) }

    if (activeLesson != null) {
        val lesson = activeLesson!!
        var selectedAnswers by remember(lesson.id) { mutableStateOf(mapOf<Int, Int>()) }
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { activeLesson = null }) { Icon(Icons.Default.ArrowBack, "Back") }
                    Text(lesson.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Grammar Note", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(4.dp))
                        Text(lesson.grammarNote, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item { Text("Vocabulary (English → Urdu)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(lesson.vocabulary) { v ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${v.english}  —  ${v.urdu} (${v.romanUrdu})", fontWeight = FontWeight.Bold)
                        Text("Example: ${v.example}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { Text("Everyday Sentences & Urdu Translations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(lesson.sentences) { s ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(s.english, fontWeight = FontWeight.SemiBold)
                        Text(s.urdu, color = MaterialTheme.colorScheme.primary)
                        Text(s.romanUrdu, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { Text("Practice Exercise", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(lesson.quiz.indices.toList()) { qIdx ->
                val q = lesson.quiz[qIdx]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${qIdx + 1}. ${q.prompt}", fontWeight = FontWeight.SemiBold)
                        q.options.forEachIndexed { oIdx, opt ->
                            val picked = selectedAnswers[qIdx] == oIdx
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedAnswers = selectedAnswers + (qIdx to oIdx)
                                }
                            ) {
                                RadioButton(selected = picked, onClick = { selectedAnswers = selectedAnswers + (qIdx to oIdx) })
                                Text(opt)
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        val score = lesson.quiz.indices.count { selectedAnswers[it] == lesson.quiz[it].correctIndex }
                        vm.completeEnglishLesson(lesson.id, score)
                        activeLesson = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Mark Lesson Completed") }
            }
        }
        return
    }

    val pct = if (EnglishLearningCurriculum.lessons.isEmpty()) 0f
    else completedIds.size.toFloat() / EnglishLearningCurriculum.lessons.size.toFloat()

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("English Learning (Offline)", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("English vocabulary, Urdu meanings, everyday sentences & grammar.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text("Progress: ${completedIds.size} / ${EnglishLearningCurriculum.lessons.size} lessons completed", style = MaterialTheme.typography.labelMedium)
        }
        items(EnglishLearningCurriculum.lessons) { lesson ->
            val done = lesson.id in completedIds
            Card(Modifier.fillMaxWidth().clickable { activeLesson = lesson }, shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(lesson.title, fontWeight = FontWeight.Bold)
                        Text("${lesson.level} • ${lesson.vocabulary.size} words • ${lesson.sentences.size} sentences", style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(
                        if (done) Icons.Default.CheckCircle else Icons.Default.PlayCircleOutline,
                        contentDescription = null,
                        tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SupportScreen(vm: TeamLegendViewModel) {
    val ui by vm.uiState.collectAsState()
    val isOnline by vm.isOnline.collectAsState()
    val tickets = ui.dashboardPayload?.tickets.orEmpty()
    var ticketText by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("TEAM LEGEND Support", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { MessageBanners(ui.bannerMessage, ui.errorMessage) { vm.clearMessages() } }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Official Channels (from Main.py)", fontWeight = FontWeight.Bold)
                    Text("Support: https://t.me/legendspot01", style = MaterialTheme.typography.bodySmall)
                    Text("OTP Group: https://t.me/teamallnumbers", style = MaterialTheme.typography.bodySmall)
                    Text("Backup Channel: https://t.me/teamlegendnumber", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            OutlinedTextField(
                value = ticketText,
                onValueChange = { ticketText = it },
                label = { Text("Describe your issue (min 4 characters)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { vm.submitSupportTicket(ticketText); ticketText = "" },
                enabled = isOnline && ticketText.trim().length >= 4 && !ui.isLoading,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Submit Support Ticket") }
        }
        items(tickets) { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Ticket #${t.id} (${t.status})", fontWeight = FontWeight.Bold)
                    Text(t.subject, style = MaterialTheme.typography.bodySmall)
                    if (t.reply.isNotBlank()) Text("Admin Reply: ${t.reply}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: TeamLegendViewModel, onOpenBackup: () -> Unit, onLogout: () -> Unit) {
    val session by vm.session.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Application Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Obsidian Dark Theme")
                    Switch(checked = session.darkTheme, onCheckedChange = { vm.updateAppSettings(darkTheme = it) })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("OTP Alert Preferences")
                    Switch(checked = session.notificationsEnabled, onCheckedChange = { vm.updateAppSettings(notifications = it) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = session.language == "en", onClick = { vm.updateAppSettings(language = "en") }, label = { Text("English") })
                    FilterChip(selected = session.language == "ur", onClick = { vm.updateAppSettings(language = "ur") }, label = { Text("Urdu") })
                }
            }
        }
        OutlinedButton(onClick = onOpenBackup, modifier = Modifier.fillMaxWidth()) { Text("Backup & Restore") }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("About TEAM LEGEND", fontWeight = FontWeight.Bold)
                Text("Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.bodySmall)
                Text("Package: ${BuildConfig.APPLICATION_ID}", style = MaterialTheme.typography.bodySmall)
                Text("Privacy: Passwords are never stored locally; HTTPS is enforced.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Button(onClick = { vm.logout(onLogout) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error), modifier = Modifier.fillMaxWidth()) {
            Text("Logout")
        }
    }
}
