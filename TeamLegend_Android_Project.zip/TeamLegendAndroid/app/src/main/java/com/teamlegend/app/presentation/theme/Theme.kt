package com.teamlegend.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Official TEAM LEGEND colors extracted from Main.py
val ObsidianBg = Color(0xFF090A0F)
val ObsidianDeep = Color(0xFF0B0B14)
val ObsidianCard = Color(0xFF121222)
val ObsidianCardAlt = Color(0xFF16172B)
val GoldMain = Color(0xFFFACC15)
val GoldDeep = Color(0xFFD97706)
val CyanAccent = Color(0xFF22D3EE)
val EmeraldSuccess = Color(0xFF10B981)
val CrimsonError = Color(0xFFEF4444)

private val TeamLegendDarkColors = darkColorScheme(
    primary = GoldMain,
    onPrimary = ObsidianBg,
    primaryContainer = Color(0xFF3A2F08),
    onPrimaryContainer = GoldMain,
    secondary = CyanAccent,
    onSecondary = ObsidianBg,
    tertiary = GoldDeep,
    background = ObsidianBg,
    onBackground = Color(0xFFF8FAFC),
    surface = ObsidianCard,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = ObsidianCardAlt,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = CrimsonError,
    onError = Color.White,
    outline = Color(0xFF2E324D)
)

private val TeamLegendLightColors = lightColorScheme(
    primary = Color(0xFFB45309),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = Color(0xFF0E7490),
    onSecondary = Color.White,
    background = Color(0xFFF1F5F9),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF334155),
    error = Color(0xFFDC2626),
    onError = Color.White,
    outline = Color(0xFFCBD5E1)
)

@Composable
fun TeamLegendTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) TeamLegendDarkColors else TeamLegendLightColors,
        content = content
    )
}
