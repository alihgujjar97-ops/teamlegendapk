package com.teamlegend.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.teamlegend.app.data.local.entity.*
import com.teamlegend.app.data.remote.dto.*
import com.teamlegend.app.data.repository.DataFreshness
import com.teamlegend.app.data.repository.RepoResult
import com.teamlegend.app.data.repository.TeamLegendRepository
import com.teamlegend.app.security.UserSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AppUiState(
    val isLoading: Boolean = false,
    val bannerMessage: String? = null,
    val errorMessage: String? = null,
    val dashboardFreshness: DataFreshness = DataFreshness.UNAVAILABLE,
    val numbersFreshness: DataFreshness = DataFreshness.UNAVAILABLE,
    val lastDashboardSyncMs: Long = 0L,
    val lastNumbersSyncMs: Long = 0L,
    val dashboardPayload: DashboardPayload? = null,
    val liveSseEvents: List<LiveGroupOtpDto> = emptyList(),
    val adminRegistrations: List<RegistrationRecordDto> = emptyList(),
    val adminSearchedUser: AdminSearchedUserDto? = null,
    val selectedCountryFilter: String = "ALL",
    val selectedServiceFilter: String = "ALL",
    val exportedBackupJson: String? = null
)

class TeamLegendViewModel(private val repo: TeamLegendRepository) : ViewModel() {

    val session: StateFlow<UserSession> = repo.sessionManager.session
    val isOnline: StateFlow<Boolean> = repo.networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repo.networkMonitor.isOnlineNow())

    val userProfile: StateFlow<UserProfileEntity?> = repo.observeUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val stockItems: StateFlow<List<CachedStockEntity>> = repo.observeStock()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val novaHostNumbers: StateFlow<List<CachedNumberEntity>> = repo.observeCachedNumbers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allocations: StateFlow<List<AllocationEntity>> = repo.observeAllocations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val smsRecords: StateFlow<List<SmsRecordEntity>> = repo.observeSmsRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val withdrawals: StateFlow<List<WithdrawalEntity>> = repo.observeWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val learningProgress: StateFlow<List<LearningProgressEntity>> = repo.observeLearningProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var sseJob: Job? = null

    fun clearMessages() {
        _uiState.update { it.copy(bannerMessage = null, errorMessage = null) }
    }

    fun setCountryFilter(country: String) {
        _uiState.update { it.copy(selectedCountryFilter = country) }
    }

    fun setServiceFilter(service: String) {
        _uiState.update { it.copy(selectedServiceFilter = service) }
    }

    fun signup(
        username: String,
        password: String,
        fullName: String,
        email: String,
        mobile: String,
        onPendingCreated: () -> Unit
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            when (val res = repo.signup(username, password, fullName, email, mobile)) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    onPendingCreated()
                }
                is RepoResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun login(
        username: String,
        password: String,
        asAdmin: Boolean,
        onAuthenticated: (isAdmin: Boolean) -> Unit,
        onRestrictedStatus: (status: String) -> Unit
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            when (val res = repo.login(username, password, asAdmin)) {
                is RepoResult.Success -> {
                    val adminRole = res.data.role.equals("admin", ignoreCase = true) || asAdmin
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message.ifBlank { "Signed in successfully." }) }
                    refreshDashboard()
                    onAuthenticated(adminRole)
                }
                is RepoResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                    if (res.accountStatus != null) {
                        onRestrictedStatus(res.accountStatus)
                    }
                }
            }
        }
    }

    fun checkApprovalStatus(username: String, onApproved: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.checkRegistrationStatus(username)) {
                is RepoResult.Success -> {
                    val st = res.data.status.lowercase()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            bannerMessage = "Current status: ${st.uppercase()}" +
                                if (res.data.rejectionReason.isNotBlank()) " — ${res.data.rejectionReason}" else ""
                        )
                    }
                    if (st == "approved") onApproved()
                }
                is RepoResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun refreshDashboard() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.refreshDashboard()) {
                is RepoResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            dashboardPayload = res.data,
                            dashboardFreshness = DataFreshness.LIVE,
                            lastDashboardSyncMs = System.currentTimeMillis()
                        )
                    }
                }
                is RepoResult.Error -> {
                    val hasCache = userProfile.value != null || stockItems.value.isNotEmpty()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            dashboardFreshness = if (hasCache) DataFreshness.CACHED else DataFreshness.UNAVAILABLE,
                            errorMessage = res.message
                        )
                    }
                }
            }
        }
    }

    fun refreshNovaHostNumbers() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.refreshNovaHostNumbers()) {
                is RepoResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            numbersFreshness = res.freshness,
                            lastNumbersSyncMs = System.currentTimeMillis(),
                            bannerMessage = if (res.message.isNotBlank()) res.message else "Loaded ${res.data.size} numbers from all.novahost.xyz."
                        )
                    }
                }
                is RepoResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            numbersFreshness = if (novaHostNumbers.value.isNotEmpty()) DataFreshness.CACHED else DataFreshness.UNAVAILABLE,
                            errorMessage = res.message
                        )
                    }
                }
            }
        }
    }


    fun refreshNovaHostSms() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.refreshNovaHostSms()) {
                is RepoResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            dashboardFreshness = res.freshness,
                            lastDashboardSyncMs = System.currentTimeMillis(),
                            bannerMessage = if (res.message.isNotBlank()) res.message else "Loaded ${res.data.size} SMS records from SMS API."
                        )
                    }
                }
                is RepoResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun saveInAppApiEndpoints(portalBaseUrl: String, numbersApiUrl: String, smsApiUrl: String) {
        if (!session.value.isAdmin) return
        if (!portalBaseUrl.startsWith("https://") || !numbersApiUrl.startsWith("https://") || !smsApiUrl.startsWith("https://")) {
            _uiState.update { it.copy(errorMessage = "All API URLs must start with https://") }
            return
        }
        repo.sessionManager.updateApiEndpoints(portalBaseUrl, numbersApiUrl, smsApiUrl)
        _uiState.update { it.copy(bannerMessage = "API endpoints updated inside the app! New URLs are active immediately.") }
    }

    fun startLiveOtpStream() {
        if (sseJob?.isActive == true) return
        sseJob = viewModelScope.launch {
            repo.observeLiveOtpStream().collect { evt ->
                _uiState.update { st ->
                    st.copy(liveSseEvents = (listOf(evt) + st.liveSseEvents).take(40))
                }
            }
        }
    }

    fun stopLiveOtpStream() {
        sseJob?.cancel()
        sseJob = null
    }

    fun claimNumber(rangeName: String, service: String, country: String, prefix: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            when (val res = repo.claimNumber(rangeName, service, country, prefix)) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    refreshDashboard()
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun releaseNumber() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.releaseNumber()) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    refreshDashboard()
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun swapDeadNumber() = runPortalAction(mapOf("action" to "swap_dead_number"))
    fun claimDailyBonus() = runPortalAction(mapOf("action" to "claim_streak"))

    fun submitWithdrawal(method: String, account: String, title: String, amount: Double) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.requestWithdrawal(method, account, title, amount)) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    refreshDashboard()
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun submitSupportTicket(text: String) = runPortalAction(mapOf("action" to "submit_ticket", "text" to text))

    fun exchangeCurrency(direction: String, amount: Double) =
        runPortalAction(mapOf("action" to "exchange_currency", "direction" to direction, "amount" to amount))

    // Admin Actions (server also enforces admin token)
    fun loadAdminRegistrations(statusFilter: String? = null, query: String? = null) {
        if (!session.value.isAdmin) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.fetchAdminRegistrations(statusFilter, query)) {
                is RepoResult.Success -> _uiState.update { it.copy(isLoading = false, adminRegistrations = res.data) }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun decideRegistration(regId: Long, decision: String, reason: String = "") {
        if (!session.value.isAdmin) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.decideRegistration(regId, decision, reason)) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    loadAdminRegistrations()
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun adminSearchUser(query: String) {
        if (!session.value.isAdmin) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repo.portalAction(mapOf("action" to "admin_search_user", "query" to query))) {
                is RepoResult.Success -> _uiState.update {
                    it.copy(isLoading = false, adminSearchedUser = res.data.userProfile)
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    fun adminManageUser(targetUid: String, subAction: String, amount: Double = 0.0) {
        if (!session.value.isAdmin) return
        runPortalAction(
            mapOf(
                "action" to "admin_manage_user",
                "target_uid" to targetUid,
                "sub_action" to subAction,
                "amount" to amount
            )
        )
    }

    fun adminDecideWithdrawal(reqId: String, decision: String) {
        if (!session.value.isAdmin) return
        runPortalAction(mapOf("action" to "admin_decide_wd", "req_id" to reqId, "decision" to decision))
    }

    fun adminUploadStock(rangeName: String, service: String, country: String, ratePkr: Double, numbersRaw: String) {
        if (!session.value.isAdmin) return
        runPortalAction(
            mapOf(
                "action" to "admin_upload_stock",
                "range_name" to rangeName,
                "service" to service,
                "country" to country,
                "rate_pkr" to ratePkr,
                "numbers" to numbersRaw
            )
        )
    }

    fun adminDeleteRange(rangeName: String) {
        if (!session.value.isAdmin) return
        runPortalAction(mapOf("action" to "admin_delete_range", "range_name" to rangeName))
    }

    fun adminSavePanel(name: String, type: String, smsUrl: String, numbersUrl: String, allowedCli: String) {
        if (!session.value.isAdmin) return
        runPortalAction(
            mapOf(
                "action" to "admin_save_unified_panel",
                "name" to name,
                "type" to type,
                "msg_link" to smsUrl,
                "numbers_url" to numbersUrl,
                "allowed_cli" to allowedCli
            )
        )
    }

    fun adminTriggerServerBackup() {
        if (!session.value.isAdmin) return
        runPortalAction(mapOf("action" to "admin_trigger_tg_backup"))
    }

    fun exportSafeLocalBackup() {
        viewModelScope.launch {
            val json = repo.createSafeLocalBackupJson()
            _uiState.update { it.copy(exportedBackupJson = json, bannerMessage = "Safe local backup generated (credentials excluded).") }
        }
    }

    fun restoreSafeLocalBackup(rawJson: String) {
        viewModelScope.launch {
            when (val res = repo.restoreSafeLocalBackupJson(rawJson)) {
                is RepoResult.Success -> _uiState.update { it.copy(bannerMessage = res.data) }
                is RepoResult.Error -> _uiState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun completeEnglishLesson(lessonId: String, score: Int) {
        viewModelScope.launch {
            repo.markLessonCompleted(lessonId, score)
            _uiState.update { it.copy(bannerMessage = "Lesson completed! Progress saved locally.") }
        }
    }

    fun updateAppSettings(darkTheme: Boolean? = null, notifications: Boolean? = null, language: String? = null) {
        repo.sessionManager.updatePreferences(darkTheme, notifications, language)
        if (language != null && session.value.isAuthenticated && isOnline.value) {
            runPortalAction(mapOf("action" to "update_prefs", "language" to language))
        }
    }

    fun logout(onDone: () -> Unit) {
        stopLiveOtpStream()
        viewModelScope.launch {
            repo.logout()
            _uiState.value = AppUiState()
            onDone()
        }
    }

    private fun runPortalAction(params: Map<String, Any>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            when (val res = repo.portalAction(params)) {
                is RepoResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, bannerMessage = res.message) }
                    refreshDashboard()
                }
                is RepoResult.Error -> _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopLiveOtpStream()
    }

    class Factory(private val repo: TeamLegendRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = TeamLegendViewModel(repo) as T
    }
}
