package com.teamlegend.app.security

object InputValidator {
    private val USERNAME_REGEX = Regex("^[A-Za-z0-9_.-]{3,32}$")
    private val EMAIL_REGEX = Regex("^[^@\s]+@[^@\s]+\.[^@\s]+$")
    private val MOBILE_REGEX = Regex("^\+?[0-9\-\s]{7,20}$")

    fun validateUsername(username: String): String? {
        val trimmed = username.trim()
        return when {
            trimmed.isEmpty() -> "Username is required."
            !USERNAME_REGEX.matches(trimmed) -> "Username must be 3–32 characters (letters, numbers, _, ., -)."
            else -> null
        }
    }

    fun validatePassword(password: String): String? {
        return when {
            password.isEmpty() -> "Password is required."
            password.length < 8 -> "Password must be at least 8 characters."
            !password.any { it.isDigit() } || !password.any { it.isLetter() } ->
                "Password must include both letters and numbers."
            else -> null
        }
    }

    fun validateLoginPassword(password: String): String? {
        return if (password.isBlank()) "Password is required." else null
    }

    fun validateFullName(fullName: String): String? {
        val trimmed = fullName.trim()
        return when {
            trimmed.isEmpty() -> "Full Name is required."
            trimmed.length < 2 -> "Full Name must be at least 2 characters."
            trimmed.length > 80 -> "Full Name cannot exceed 80 characters."
            else -> null
        }
    }

    /** Optional field: only validates format when non-blank. */
    fun validateOptionalEmail(email: String): String? {
        val trimmed = email.trim()
        if (trimmed.isEmpty()) return null
        return if (EMAIL_REGEX.matches(trimmed)) null else "Enter a valid email address or leave blank."
    }

    /** Optional field: only validates format when non-blank. */
    fun validateOptionalMobile(mobile: String): String? {
        val trimmed = mobile.trim()
        if (trimmed.isEmpty()) return null
        return if (MOBILE_REGEX.matches(trimmed)) null else "Enter a valid mobile number or leave blank."
    }

    fun validateWithdrawal(amountStr: String, account: String, availableBalance: Double, minAmount: Double): String? {
        val amt = amountStr.toDoubleOrNull() ?: return "Enter a valid numeric withdrawal amount."
        if (amt <= 0.0) return "Withdrawal amount must be greater than zero."
        if (amt < minAmount) return "Minimum withdrawal is $minAmount."
        if (amt > availableBalance + 1e-6) return "Amount exceeds your available balance."
        if (account.trim().length < 4) return "Enter a valid account number or wallet address."
        return null
    }
}
