package com.teamlegend.app.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.teamlegend.app.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSession(
    val token: String = "",
    val username: String = "",
    val fullName: String = "",
    val role: String = "user",
    val accountStatus: String = "unknown",
    val userId: Long = 0L,
    val baseUrl: String = BuildConfig.BASE_PORTAL_URL,
    val numbersApiUrl: String = BuildConfig.NUMBERS_API_FULL_URL,
    val smsApiUrl: String = BuildConfig.SMS_API_URL,
    val darkTheme: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val language: String = "en"
) {
    val isAuthenticated: Boolean get() = token.isNotBlank() && accountStatus == "approved"
    val isAdmin: Boolean get() = isAuthenticated && role.equals("admin", ignoreCase = true)
}

class SessionManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "team_legend_secure_session",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("team_legend_session_fallback", Context.MODE_PRIVATE)
    }

    private val _session = MutableStateFlow(loadSession())
    val session: StateFlow<UserSession> = _session.asStateFlow()

    private fun loadSession(): UserSession = UserSession(
        token = prefs.getString(KEY_TOKEN, "") ?: "",
        username = prefs.getString(KEY_USERNAME, "") ?: "",
        fullName = prefs.getString(KEY_FULL_NAME, "") ?: "",
        role = prefs.getString(KEY_ROLE, "user") ?: "user",
        accountStatus = prefs.getString(KEY_STATUS, "unknown") ?: "unknown",
        userId = prefs.getLong(KEY_USER_ID, 0L),
        baseUrl = prefs.getString(KEY_BASE_URL, BuildConfig.BASE_PORTAL_URL) ?: BuildConfig.BASE_PORTAL_URL,
        numbersApiUrl = prefs.getString(KEY_NUMBERS_URL, BuildConfig.NUMBERS_API_FULL_URL) ?: BuildConfig.NUMBERS_API_FULL_URL,
        smsApiUrl = prefs.getString(KEY_SMS_URL, BuildConfig.SMS_API_URL) ?: BuildConfig.SMS_API_URL,
        darkTheme = prefs.getBoolean(KEY_DARK_THEME, true),
        notificationsEnabled = prefs.getBoolean(KEY_NOTIFICATIONS, true),
        language = prefs.getString(KEY_LANGUAGE, "en") ?: "en"
    )

    fun saveAuthenticatedSession(
        token: String,
        username: String,
        fullName: String,
        role: String,
        userId: Long = 0L
    ) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USERNAME, username)
            .putString(KEY_FULL_NAME, fullName)
            .putString(KEY_ROLE, role)
            .putString(KEY_STATUS, "approved")
            .putLong(KEY_USER_ID, userId)
            .apply()
        _session.value = loadSession()
    }

    fun savePendingOrRestrictedStatus(username: String, status: String) {
        prefs.edit()
            .remove(KEY_TOKEN)
            .putString(KEY_USERNAME, username)
            .putString(KEY_ROLE, "user")
            .putString(KEY_STATUS, status.lowercase())
            .apply()
        _session.value = loadSession()
    }

    fun updateApiEndpoints(portalBaseUrl: String, numbersApiUrl: String, smsApiUrl: String) {
        val cleanPortal = portalBaseUrl.trim().let { if (it.endsWith("/")) it else "$it/" }
        prefs.edit()
            .putString(KEY_BASE_URL, cleanPortal)
            .putString(KEY_NUMBERS_URL, numbersApiUrl.trim())
            .putString(KEY_SMS_URL, smsApiUrl.trim())
            .apply()
        _session.value = loadSession()
    }

    fun updatePreferences(darkTheme: Boolean? = null, notificationsEnabled: Boolean? = null, language: String? = null) {
        prefs.edit().apply {
            darkTheme?.let { putBoolean(KEY_DARK_THEME, it) }
            notificationsEnabled?.let { putBoolean(KEY_NOTIFICATIONS, it) }
            language?.let { putString(KEY_LANGUAGE, it) }
        }.apply()
        _session.value = loadSession()
    }

    fun clearSession() {
        val keepDark = prefs.getBoolean(KEY_DARK_THEME, true)
        val keepLang = prefs.getString(KEY_LANGUAGE, "en") ?: "en"
        val keepBase = prefs.getString(KEY_BASE_URL, BuildConfig.BASE_PORTAL_URL) ?: BuildConfig.BASE_PORTAL_URL
        val keepNum = prefs.getString(KEY_NUMBERS_URL, BuildConfig.NUMBERS_API_FULL_URL) ?: BuildConfig.NUMBERS_API_FULL_URL
        val keepSms = prefs.getString(KEY_SMS_URL, BuildConfig.SMS_API_URL) ?: BuildConfig.SMS_API_URL
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_USERNAME)
            .remove(KEY_FULL_NAME)
            .remove(KEY_ROLE)
            .remove(KEY_STATUS)
            .remove(KEY_USER_ID)
            .putBoolean(KEY_DARK_THEME, keepDark)
            .putString(KEY_LANGUAGE, keepLang)
            .putString(KEY_BASE_URL, keepBase)
            .putString(KEY_NUMBERS_URL, keepNum)
            .putString(KEY_SMS_URL, keepSms)
            .apply()
        _session.value = loadSession()
    }

    fun currentToken(): String = _session.value.token

    companion object {
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_USERNAME = "username"
        private const val KEY_FULL_NAME = "full_name"
        private const val KEY_ROLE = "role"
        private const val KEY_STATUS = "account_status"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_NUMBERS_URL = "numbers_api_url"
        private const val KEY_SMS_URL = "sms_api_url"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_NOTIFICATIONS = "notifications_enabled"
        private const val KEY_LANGUAGE = "language"
    }
}
