@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.teamlegend.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.model.AdminUserRowDto
import com.teamlegend.app.data.remote.ApiClientFactory
import com.teamlegend.app.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Master Admin Command Center — strictly gated to single Master Admin (`teamlegend_admin`).
 * Never accessible or visible to regular users.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminConsoleShell(
    tokenManager: TokenManager,
    onLogout: () -> Unit
) {
    var tab by remember { mutableStateOf("overview") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val tabs = listOf(
        Triple("overview", "Overview", Icons.Outlined.Analytics),
        Triple("approvals", "Users", Icons.Outlined.HowToReg),
        Triple("withdraws", "Payouts", Icons.Outlined.Payments),
        Triple("panels", "Panels", Icons.Outlined.Hub),
        Triple("broadcast", "System", Icons.Outlined.Campaign),
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("MASTER ADMIN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        TlStatusBadge("SINGLE ADMIN", TlColors.ChampagneGold)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().logout() }
                            tokenManager.clearSession()
                            onLogout()
                        }
                    }) { Icon(Icons.Outlined.Logout, "Sign Out") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { (id, label, icon) ->
                    NavigationBarItem(selected = tab == id, onClick = { tab = id }, icon = { Icon(icon, label) }, label = { Text(label) })
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(padding)) {
            when (tab) {
                "overview" -> AdminOverviewTab(tokenManager)
                "approvals" -> AdminApprovalsTab(tokenManager, onMsg = { m -> scope.launch { snackbarHostState.showSnackbar(m) } })
                "withdraws" -> AdminWithdrawalsTab(tokenManager, onMsg = { m -> scope.launch { snackbarHostState.showSnackbar(m) } })
                "panels" -> AdminPanelsTab(tokenManager)
                else -> AdminBroadcastAndSystemTab(tokenManager, onMsg = { m -> scope.launch { snackbarHostState.showSnackbar(m) } })
            }
        }
    }
}

@Composable
private fun AdminOverviewTab(tokenManager: TokenManager) {
    var overview by remember { mutableStateOf<Map<String, Any>>(emptyMap()) }
    LaunchedEffect(Unit) {
        runCatching { ApiClientFactory(tokenManager).createService().getAdminOverview() }
            .onSuccess { overview = it }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TlSectionHeader("Admin Overview", "Live system health, user queues, stock, and audit logs") }
        item {
            TlSurfaceCard {
                Text("System Snapshot", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Total OTPs Logged: ${overview["total_otps"] ?: 0}")
                Text("Database Engine: SQLite WAL (Active)")
                Text("Single Master Admin Guard: Enforced")
            }
        }
    }
}

@Composable
private fun AdminApprovalsTab(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<AdminUserRowDto>>(emptyList()) }
    var filter by remember { mutableStateOf("PENDING") }

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminUsers(filter) }
                .onSuccess { users = it.users }
        }
    }
    LaunchedEffect(filter) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TlSectionHeader("User Approvals & Management", "Approve or reject pending signups")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("PENDING", "APPROVED", "REJECTED").forEach { st ->
                FilterChip(selected = filter == st, onClick = { filter = st }, label = { Text(st) })
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(users) { u ->
                TlSurfaceCard {
                    Text("${u.fullName} (@${u.username})", fontWeight = FontWeight.SemiBold)
                    Text(u.email, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (u.status == "PENDING") {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    runCatching { ApiClientFactory(tokenManager).createService().approveUser(u.id) }
                                        .onSuccess { onMsg("Approved @${u.username}"); load() }
                                }
                            }, modifier = Modifier.weight(1f)) { Text("Approve") }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    runCatching { ApiClientFactory(tokenManager).createService().rejectUser(u.id, mapOf("reason" to "Declined by Admin")) }
                                        .onSuccess { onMsg("Rejected @${u.username}"); load() }
                                }
                            }, modifier = Modifier.weight(1f)) { Text("Reject") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminWithdrawalsTab(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminWithdrawals("PENDING") }
                .onSuccess {
                    @Suppress("UNCHECKED_CAST")
                    list = (it["withdrawals"] as? List<Map<String, Any>>).orEmpty()
                }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TlSectionHeader("Withdrawal Queue", "Approve with TX proof or reject with automatic balance refund")
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { w ->
                val wid = (w["id"] as? Number)?.toInt() ?: 0
                TlSurfaceCard {
                    Text("${w["method"]} • ${w["amount"]} ${w["currency"]}", fontWeight = FontWeight.SemiBold)
                    Text("User: @${w["username"]} • Dest: ${w["destination"]}", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch {
                                runCatching { ApiClientFactory(tokenManager).createService().decideWithdrawal(wid, "approve", mapOf("tx_reference" to "PAID-OK")) }
                                    .onSuccess { onMsg("Withdrawal #$wid approved"); load() }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Approve") }
                        OutlinedButton(onClick = {
                            scope.launch {
                                runCatching { ApiClientFactory(tokenManager).createService().decideWithdrawal(wid, "reject", mapOf("reason" to "Refunded by Admin")) }
                                    .onSuccess { onMsg("Withdrawal #$wid rejected & refunded"); load() }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Reject & Refund") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminPanelsTab(tokenManager: TokenManager) {
    var panels by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    LaunchedEffect(Unit) {
        runCatching { ApiClientFactory(tokenManager).createService().getAdminPanels() }
            .onSuccess {
                @Suppress("UNCHECKED_CAST")
                panels = (it["panels"] as? List<Map<String, Any>>).orEmpty()
            }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TlSectionHeader("Multi-Panel & API Studio", "REST CDR, WebSocket /livesms, Auto-Captcha & CLI Restricted Panels")
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(panels) { p ->
                TlSurfaceCard {
                    Text("${p["name"]} (${p["panel_type"]})", fontWeight = FontWeight.SemiBold)
                    Text("${p["base_url"]}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AdminBroadcastAndSystemTab(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TlSectionHeader("Broadcast & System Controls", "Send notifications to all approved users and manage system settings")
        TlSurfaceCard {
            OutlinedTextField(title, { title = it }, label = { Text("Broadcast Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(body, { body = it }, label = { Text("Message") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    scope.launch {
                        runCatching {
                            ApiClientFactory(tokenManager).createService().sendBroadcast(mapOf("title" to title, "message" to body))
                        }.onSuccess {
                            onMsg("Broadcast delivered!")
                            title = ""
                            body = ""
                        }.onFailure { onMsg(it.localizedMessage ?: "Broadcast failed") }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) { Text("Send Broadcast") }
        }
    }
}
