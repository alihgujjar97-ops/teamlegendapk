package com.teamlegend.app.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.model.AdminUserRowDto
import com.teamlegend.app.data.remote.ApiClientFactory
import com.teamlegend.app.ui.theme.*
import com.teamlegend.app.ui.user.UserVaultShell
import kotlinx.coroutines.launch

/**
 * Master Admin Shell:
 * - Toggle seamlessly between FULL User FinTech Vault (all 10 user modules + games)
 *   and FULL 8-Module Admin Command Center (Panels, Stock, 3-Tier Pricing, Withdrawals,
 *   Users/Credit/Ban/Shield, Broadcast, Ecosystem/TV/Tickets, System/APIs/Audit).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminConsoleShell(
    tokenManager: TokenManager,
    onLogout: () -> Unit
) {
    var viewUserVault by remember { mutableStateOf(false) }
    var darkTheme by remember { mutableStateOf(tokenManager.isDarkTheme()) }

    if (viewUserVault) {
        Box(Modifier.fillMaxSize()) {
            UserVaultShell(
                tokenManager = tokenManager,
                isDark = darkTheme,
                onToggleTheme = { darkTheme = !darkTheme; tokenManager.setDarkTheme(darkTheme) },
                onLogout = onLogout
            )
            ExtendedFloatingActionButton(
                onClick = { viewUserVault = false },
                containerColor = TlGold,
                contentColor = TlObsidian,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 84.dp),
                icon = { Icon(Icons.Outlined.AdminPanelSettings, contentDescription = null) },
                text = { Text("Admin Center", fontWeight = FontWeight.Bold) }
            )
        }
        return
    }

    var tab by remember { mutableStateOf("panels") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val adminTabs = listOf(
        "panels" to "1. Panels",
        "stock" to "2. Stock",
        "pricing" to "3. Pricing",
        "withdraws" to "4. Payouts",
        "users" to "5. Users",
        "broadcast" to "6. Broadcast",
        "ecosystem" to "7. TV & Links",
        "system" to "8. System"
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MASTER ADMIN CENTER", fontWeight = FontWeight.ExtraBold, color = TlGold)
                        Text("All 8 Admin Modules • apk.novahost.xyz", style = MaterialTheme.typography.labelSmall, color = TlMuted)
                    }
                },
                actions = {
                    TextButton(onClick = { viewUserVault = true }) {
                        Icon(Icons.Outlined.AccountBalanceWallet, contentDescription = null, tint = TlGold)
                        Spacer(Modifier.width(4.dp))
                        Text("User Vault", color = TlGold, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { tokenManager.clearSession(); onLogout() }) {
                        Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = "Sign Out", tint = TlRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(adminTabs) { (id, label) ->
                    FilterChip(
                        selected = tab == id,
                        onClick = { tab = id },
                        label = { Text(label, fontWeight = if (tab == id) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val notify: (String) -> Unit = { m -> scope.launch { snackbarHostState.showSnackbar(m) } }
                when (tab) {
                    "panels" -> AdminPanelsModule(tokenManager, notify)
                    "stock" -> AdminStockModule(tokenManager, notify)
                    "pricing" -> AdminPricingModule(tokenManager, notify)
                    "withdraws" -> AdminWithdrawalsModule(tokenManager, notify)
                    "users" -> AdminUsersModule(tokenManager, notify)
                    "broadcast" -> AdminBroadcastModule(tokenManager, notify)
                    "ecosystem" -> AdminEcosystemModule(tokenManager, notify)
                    else -> AdminSystemModule(tokenManager, notify)
                }
            }
        }
    }
}

@Composable
private fun AdminPanelsModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var panels by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var panelType by remember { mutableStateOf("REST_CDR") }

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminPanels() }
                .onSuccess {
                    @Suppress("UNCHECKED_CAST")
                    panels = (it["panels"] as? List<Map<String, Any>>).orEmpty()
                }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TlSectionHeader("1. Multi-Panel & Range Studio", "Add, Toggle, Delete Panels, Sync All & Harvest Cookies")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                scope.launch {
                    runCatching { ApiClientFactory(tokenManager).createService().syncAllPanels() }
                        .onSuccess { onMsg("Synced all panels!"); load() }
                        .onFailure { onMsg(it.localizedMessage ?: "Sync failed") }
                }
            }, modifier = Modifier.weight(1f)) { Text("Sync All") }
            OutlinedButton(onClick = {
                scope.launch {
                    runCatching { ApiClientFactory(tokenManager).createService().harvestPanelCookies() }
                        .onSuccess { onMsg("Cookies harvest triggered!") }
                }
            }, modifier = Modifier.weight(1f)) { Text("Harvest Cookies") }
        }
        TlCard {
            OutlinedTextField(name, { name = it }, label = { Text("Panel Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(url, { url = it }, label = { Text("Panel Base URL (https://...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(panelType, { panelType = it }, label = { Text("Type (REST_CDR / SOCKET / CF_BYPASS)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Save / Add Panel", onClick = {
                if (name.isBlank() || url.isBlank()) { onMsg("Enter name and URL"); return@TlGoldButton }
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().saveAdminPanel(
                            mapOf("name" to name.trim(), "base_url" to url.trim(), "panel_type" to panelType.trim(), "enabled" to true)
                        )
                    }.onSuccess { name = ""; url = ""; onMsg("Panel saved!"); load() }
                        .onFailure { onMsg(it.localizedMessage ?: "Save failed") }
                }
            })
        }
        panels.forEach { p ->
            val pid = p["id"]?.toString().orEmpty()
            val en = p["enabled"] == true || p["enabled"].toString() == "1" || p["enabled"].toString() == "1.0"
            TlCard {
                Text(p["name"]?.toString().orEmpty(), fontWeight = FontWeight.Bold)
                Text("${p["panel_type"]} • ${p["base_url"]}", style = MaterialTheme.typography.bodySmall, color = TlMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().toggleAdminPanel(pid) }
                                .onSuccess { onMsg("Toggled panel"); load() }
                        }
                    }) { Text(if (en) "Status: ON" else "Status: OFF") }
                    TextButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().deleteAdminPanel(pid) }
                                .onSuccess { onMsg("Deleted panel"); load() }
                        }
                    }) { Text("Delete", color = TlRed) }
                }
            }
        }
    }
}

@Composable
private fun AdminStockModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var ranges by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var cliRestricted by remember { mutableStateOf(false) }
    var rangeName by remember { mutableStateOf("Pakistan1-3") }
    var countryName by remember { mutableStateOf("Pakistan") }
    var serviceName by remember { mutableStateOf("WhatsApp") }
    var rawNums by remember { mutableStateOf("") }

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminStockRanges() }
                .onSuccess {
                    @Suppress("UNCHECKED_CAST")
                    ranges = (it["ranges"] as? List<Map<String, Any>>).orEmpty()
                    cliRestricted = it["cli_restricted"] == true
                }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TlSectionHeader("2. Stock & .TXT Batch Manager", "Paste/.TXT Upload, CLI Restriction, Active Ranges & Flush")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                scope.launch {
                    runCatching { ApiClientFactory(tokenManager).createService().setCliRestriction(mapOf("enabled" to !cliRestricted)) }
                        .onSuccess { cliRestricted = !cliRestricted; onMsg("CLI Restriction updated") }
                }
            }, modifier = Modifier.weight(1f)) { Text("CLI: ${if (cliRestricted) "ON" else "OFF"}") }
            OutlinedButton(onClick = {
                scope.launch {
                    runCatching { ApiClientFactory(tokenManager).createService().flushAllStock() }
                        .onSuccess { onMsg("All available stock flushed!"); load() }
                }
            }, modifier = Modifier.weight(1f)) { Text("Flush All", color = TlRed) }
        }
        TlCard {
            OutlinedTextField(rangeName, { rangeName = it }, label = { Text("Range Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(countryName, { countryName = it }, label = { Text("Country Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(serviceName, { serviceName = it }, label = { Text("Service Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(rawNums, { rawNums = it }, label = { Text("Paste Numbers (one per line)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Upload Stock Batch", onClick = {
                val list = rawNums.lines().map { it.trim() }.filter { it.isNotBlank() }
                if (list.isEmpty()) { onMsg("Paste at least one number"); return@TlGoldButton }
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().uploadAdminStock(
                            mapOf("country_name" to countryName, "country_code" to "+92", "service_name" to serviceName, "range_name" to rangeName, "numbers" to list)
                        )
                    }.onSuccess { rawNums = ""; onMsg("Uploaded ${list.size} numbers!"); load() }
                        .onFailure { onMsg(it.localizedMessage ?: "Upload failed") }
                }
            })
        }
        ranges.forEach { r ->
            val rn = r["range_name"]?.toString().orEmpty()
            TlCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(rn, fontWeight = FontWeight.Bold)
                        Text("${r["country_name"]} • ${r["service_name"]} • Free: ${r["free_count"]}", style = MaterialTheme.typography.bodySmall, color = TlMuted)
                    }
                    TextButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().deleteStockRange(rn) }
                                .onSuccess { onMsg("Deleted range $rn"); load() }
                        }
                    }) { Text("Delete", color = TlRed) }
                }
            }
        }
    }
}

@Composable
private fun AdminPricingModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var globalUsd by remember { mutableStateOf("0.007") }
    var fxRate by remember { mutableStateOf("280") }
    var maxQuota by remember { mutableStateOf("3") }
    var peakBoost by remember { mutableStateOf("1.1") }
    var minPkr by remember { mutableStateOf("300") }
    var minUsd by remember { mutableStateOf("1.0") }

    LaunchedEffect(Unit) {
        runCatching { ApiClientFactory(tokenManager).createService().getAdminPricing() }
            .onSuccess { resp ->
                @Suppress("UNCHECKED_CAST")
                val p = resp["pricing"] as? Map<String, Any> ?: return@onSuccess
                p["global_rate_usd"]?.let { globalUsd = it.toString() }
                p["fx_usd_to_pkr"]?.let { fxRate = it.toString() }
                p["max_otp_quota"]?.let { maxQuota = it.toString().substringBefore(".") }
                p["peak_boost_multiplier"]?.let { peakBoost = it.toString() }
                p["min_withdraw_pkr"]?.let { minPkr = it.toString() }
                p["min_withdraw_usdt"]?.let { minUsd = it.toString() }
            }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TlSectionHeader("3. 3-Tier Pricing & Quotas", "Global USD/PKR Rates, Live FX, OTP Quota & Min Withdrawals")
        TlCard {
            OutlinedTextField(globalUsd, { globalUsd = it }, label = { Text("Global Default Rate (USD)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(fxRate, { fxRate = it }, label = { Text("Live FX Rate (1 USD = PKR)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(maxQuota, { maxQuota = it }, label = { Text("Per-Number Max OTP Quota") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(peakBoost, { peakBoost = it }, label = { Text("Peak-Hour Boost Multiplier") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(minPkr, { minPkr = it }, label = { Text("Min Withdrawal (PKR)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(minUsd, { minUsd = it }, label = { Text("Min Withdrawal (USDT)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            TlGoldButton("Save Pricing Globally", onClick = {
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().saveAdminPricing(
                            mapOf(
                                "global_rate_usd" to (globalUsd.toDoubleOrNull() ?: 0.007),
                                "fx_usd_to_pkr" to (fxRate.toDoubleOrNull() ?: 280.0),
                                "max_otp_quota" to (maxQuota.toIntOrNull() ?: 3),
                                "peak_boost_multiplier" to (peakBoost.toDoubleOrNull() ?: 1.1),
                                "min_withdraw_pkr" to (minPkr.toDoubleOrNull() ?: 300.0),
                                "min_withdraw_usdt" to (minUsd.toDoubleOrNull() ?: 1.0)
                            )
                        )
                    }.onSuccess { onMsg("Pricing saved globally!") }
                        .onFailure { onMsg(it.localizedMessage ?: "Failed") }
                }
            })
        }
    }
}

@Composable
private fun AdminWithdrawalsModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminWithdrawals("PENDING") }
                .onSuccess {
                    @Suppress("UNCHECKED_CAST")
                    rows = (it["withdrawals"] as? List<Map<String, Any>>).orEmpty()
                }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TlSectionHeader("4. Withdrawals & Gateways", "Approve with TX proof or reject with automatic balance refund")
        if (rows.isEmpty()) TlCard { Text("No pending withdrawal requests.", color = TlMuted) }
        rows.forEach { w ->
            val id = (w["id"] as? Number)?.toInt() ?: 0
            TlCard {
                Text("@${w["username"]} • ${w["method"]}", fontWeight = FontWeight.Bold)
                Text("${w["amount"]} ${w["currency"]} -> ${w["destination"]}", color = TlGold, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().decideWithdrawal(id, "approve", mapOf("tx_reference" to "TL-TX-$id")) }
                                .onSuccess { onMsg("Approved withdrawal #$id"); load() }
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Approve") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().decideWithdrawal(id, "reject", mapOf("reason" to "Rejected by Master Admin")) }
                                .onSuccess { onMsg("Rejected & refunded #$id"); load() }
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Reject", color = TlRed) }
                }
            }
        }
    }
}

@Composable
private fun AdminUsersModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<AdminUserRowDto>>(emptyList()) }
    var maxCancels by remember { mutableStateOf("5") }
    var cooldown by remember { mutableStateOf("10") }
    var watchdog by remember { mutableStateOf("90") }

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getAdminUsers() }.onSuccess { users = it.users }
            runCatching { ApiClientFactory(tokenManager).createService().getAbuseShield() }.onSuccess { resp ->
                @Suppress("UNCHECKED_CAST")
                val s = resp["shield"] as? Map<String, Any> ?: return@onSuccess
                s["max_cancels"]?.let { maxCancels = it.toString().substringBefore(".") }
                s["cooldown_min"]?.let { cooldown = it.toString().substringBefore(".") }
                s["dead_watchdog_sec"]?.let { watchdog = it.toString().substringBefore(".") }
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TlSectionHeader("5. Users, Approvals, Credit/Debit & Shield", "Manage pending accounts, balances, bans & anti-abuse")
        users.forEach { u ->
            TlCard {
                Text("${u.fullName} (@${u.username}) • ${u.status}", fontWeight = FontWeight.Bold)
                Text("${u.email} • $${"%.2f".format(u.balanceUsd)} USD | Rs ${"%.0f".format(u.balancePkr)}", style = MaterialTheme.typography.bodySmall, color = TlMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                    if (u.status == "PENDING") {
                        Button(onClick = {
                            scope.launch {
                                runCatching { ApiClientFactory(tokenManager).createService().approveUser(u.id) }
                                    .onSuccess { onMsg("Approved @${u.username}"); load() }
                            }
                        }) { Text("Approve") }
                    }
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                ApiClientFactory(tokenManager).createService().adjustUserBalance(
                                    u.id, mapOf("currency" to "USD", "delta" to 1.0, "note" to "Admin Credit")
                                )
                            }.onSuccess { onMsg("Credited +$1 USD to @${u.username}"); load() }
                        }
                    }) { Text("+$1") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().toggleBanUser(u.id) }
                                .onSuccess { onMsg("Updated ban status for @${u.username}"); load() }
                        }
                    }) { Text(if (u.status == "BANNED") "Unban" else "Ban", color = TlRed) }
                }
            }
        }
        TlCard {
            Text("Anti-Abuse Shield", fontWeight = FontWeight.Bold, color = TlGold)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(maxCancels, { maxCancels = it }, label = { Text("Max Number Cancels") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(cooldown, { cooldown = it }, label = { Text("Cooldown (Minutes)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(watchdog, { watchdog = it }, label = { Text("Dead Watchdog (Seconds)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Save Abuse Shield", onClick = {
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().saveAbuseShield(
                            mapOf("max_cancels" to (maxCancels.toIntOrNull() ?: 5), "cooldown_min" to (cooldown.toIntOrNull() ?: 10), "dead_watchdog_sec" to (watchdog.toIntOrNull() ?: 90))
                        )
                    }.onSuccess { onMsg("Anti-Abuse Shield saved!") }
                }
            })
        }
    }
}

@Composable
private fun AdminBroadcastModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TlSectionHeader("6. Broadcast Studio", "Deliver instant announcements to all approved app users")
        TlCard {
            OutlinedTextField(title, { title = it }, label = { Text("Broadcast Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(body, { body = it }, label = { Text("Broadcast Message") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            TlGoldButton("Launch Broadcast", onClick = {
                if (title.isBlank() || body.isBlank()) { onMsg("Enter title and message"); return@TlGoldButton }
                scope.launch {
                    runCatching { ApiClientFactory(tokenManager).createService().sendBroadcast(mapOf("title" to title.trim(), "message" to body.trim())) }
                        .onSuccess { title = ""; body = ""; onMsg("Broadcast delivered!") }
                        .onFailure { onMsg(it.localizedMessage ?: "Broadcast failed") }
                }
            })
        }
    }
}

@Composable
private fun AdminEcosystemModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var forceJoin by remember { mutableStateOf(true) }
    var mainLink by remember { mutableStateOf("https://t.me/+t0CAPbyw77kzYzU0") }
    var otpLink by remember { mutableStateOf("https://t.me/teamallnumbers") }
    var tvTitle by remember { mutableStateOf("") }
    var tvUrl by remember { mutableStateOf("") }
    var tickets by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var replyText by remember { mutableStateOf("") }

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().getEcosystem() }.onSuccess { resp ->
                @Suppress("UNCHECKED_CAST")
                val eco = resp["ecosystem"] as? Map<String, Any> ?: return@onSuccess
                forceJoin = eco["force_join"] == true
                eco["main_channel_link"]?.let { mainLink = it.toString() }
                eco["otp_group_link"]?.let { otpLink = it.toString() }
            }
            runCatching { ApiClientFactory(tokenManager).createService().getAdminTickets() }.onSuccess { resp ->
                @Suppress("UNCHECKED_CAST")
                tickets = (resp["tickets"] as? List<Map<String, Any>>).orEmpty()
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TlSectionHeader("7. Force-Join, TV Methods & Support Tickets", "Manage channels, publish guides & reply to user tickets")
        TlCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Force-Join Verification", fontWeight = FontWeight.Bold)
                Switch(checked = forceJoin, onCheckedChange = { forceJoin = it })
            }
            OutlinedTextField(mainLink, { mainLink = it }, label = { Text("Main Channel Link") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(otpLink, { otpLink = it }, label = { Text("Live OTP Group Link") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Save Ecosystem Links", onClick = {
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().saveEcosystem(
                            mapOf("force_join" to forceJoin, "main_channel_link" to mainLink, "otp_group_link" to otpLink)
                        )
                    }.onSuccess { onMsg("Ecosystem links saved!") }
                }
            })
        }
        TlCard {
            Text("Publish TV Video Method", fontWeight = FontWeight.Bold, color = TlGold)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(tvTitle, { tvTitle = it }, label = { Text("Method Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(tvUrl, { tvUrl = it }, label = { Text("Video / Guide URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Publish TV Method", onClick = {
                if (tvTitle.isBlank()) { onMsg("Enter title"); return@TlGoldButton }
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().publishTvMethod(
                            mapOf("title" to tvTitle.trim(), "description" to "Official Admin Guide", "video_url" to tvUrl.trim())
                        )
                    }.onSuccess { tvTitle = ""; tvUrl = ""; onMsg("TV Method published!") }
                }
            })
        }
        if (tickets.isNotEmpty()) {
            TlCard {
                Text("Support Tickets (${tickets.size})", fontWeight = FontWeight.Bold, color = TlGold)
                OutlinedTextField(replyText, { replyText = it }, label = { Text("Reply message") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                tickets.take(5).forEach { tk ->
                    val tid = (tk["id"] as? Number)?.toInt() ?: 0
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("@${tk["username"]}: ${tk["subject"]}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            Text("Status: ${tk["status"]}", color = TlMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(onClick = {
                            if (replyText.isBlank()) { onMsg("Type reply first"); return@TextButton }
                            scope.launch {
                                runCatching { ApiClientFactory(tokenManager).createService().replyAdminTicket(tid, mapOf("message" to replyText.trim())) }
                                    .onSuccess { replyText = ""; onMsg("Replied to ticket #$tid"); load() }
                            }
                        }) { Text("Reply") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminSystemModule(tokenManager: TokenManager, onMsg: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var maintenance by remember { mutableStateOf(false) }
    var numbersApi by remember { mutableStateOf("https://all.novahost.xyz/api/all/numbers") }
    var smsApi by remember { mutableStateOf("https://all.novahost.xyz/api/all/sms") }
    var logs by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }

    LaunchedEffect(Unit) {
        runCatching { ApiClientFactory(tokenManager).createService().getEcosystem() }.onSuccess { resp ->
            @Suppress("UNCHECKED_CAST")
            val eco = resp["ecosystem"] as? Map<String, Any> ?: return@onSuccess
            maintenance = eco["maintenance_mode"] == true
            eco["numbers_api_url"]?.let { numbersApi = it.toString() }
            eco["sms_api_url"]?.let { smsApi = it.toString() }
        }
        runCatching { ApiClientFactory(tokenManager).createService().getAuditLogs() }.onSuccess { resp ->
            @Suppress("UNCHECKED_CAST")
            logs = (resp["logs"] as? List<Map<String, Any>>).orEmpty()
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TlSectionHeader("8. System, Live APIs & Audit Logs", "Maintenance Mode, Aggregator Endpoints & Immutable Logs")
        TlCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Maintenance Mode", fontWeight = FontWeight.Bold)
                Switch(checked = maintenance, onCheckedChange = { maintenance = it })
            }
            OutlinedTextField(numbersApi, { numbersApi = it }, label = { Text("Numbers API URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(smsApi, { smsApi = it }, label = { Text("SMS API URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            TlGoldButton("Save System & API Settings", onClick = {
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().saveEcosystem(
                            mapOf("maintenance_mode" to maintenance, "numbers_api_url" to numbersApi, "sms_api_url" to smsApi)
                        )
                    }.onSuccess { onMsg("System & API URLs saved!") }
                }
            })
        }
        TlCard {
            Text("Recent Admin Audit Logs", fontWeight = FontWeight.Bold, color = TlGold)
            logs.take(12).forEach { l ->
                Text("• ${l["action"]} (${l["target_type"]}:${l["target_id"]})", style = MaterialTheme.typography.bodySmall, color = TlMuted)
            }
        }
    }
}
