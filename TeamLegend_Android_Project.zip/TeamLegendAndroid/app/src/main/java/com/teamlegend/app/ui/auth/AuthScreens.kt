@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.teamlegend.app.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.teamlegend.app.R
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.model.ChangePasswordRequest
import com.teamlegend.app.data.model.LoginRequest
import com.teamlegend.app.data.model.SignupRequest
import com.teamlegend.app.data.remote.ApiClientFactory
import com.teamlegend.app.ui.theme.TlColors
import com.teamlegend.app.ui.theme.TlStatusBadge
import com.teamlegend.app.ui.theme.TlSurfaceCard
import kotlinx.coroutines.launch

@Composable
fun AuthFlowScreen(
    tokenManager: TokenManager,
    onAuthenticated: (role: String, mustChangePassword: Boolean) -> Unit
) {
    var mode by remember { mutableStateOf("LOGIN") } // LOGIN | SIGNUP | PENDING
    var pendingUsername by remember { mutableStateOf("") }

    when (mode) {
        "PENDING" -> PendingApprovalScreen(
            username = pendingUsername,
            onBackToLogin = { mode = "LOGIN" }
        )
        "SIGNUP" -> SignupScreen(
            tokenManager = tokenManager,
            onRegistered = { uname ->
                pendingUsername = uname
                mode = "PENDING"
            },
            onSwitchToLogin = { mode = "LOGIN" }
        )
        else -> LoginScreen(
            tokenManager = tokenManager,
            onSwitchToSignup = { mode = "SIGNUP" },
            onAuthenticated = onAuthenticated
        )
    }
}

/**
 * Unified Stealth Login Screen:
 * Shows a single clean Sign In form with zero mention of Admin.
 * Backend automatically detects whether credentials belong to a regular User
 * or the Admin account and returns the appropriate role.
 */
@Composable
private fun LoginScreen(
    tokenManager: TokenManager,
    onSwitchToSignup: () -> Unit,
    onAuthenticated: (role: String, mustChangePassword: Boolean) -> Unit
) {
    val scope = rememberCoroutineScope()
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(36.dp))
        Image(
            painter = painterResource(id = R.drawable.ic_team_legend_logo),
            contentDescription = "Team Legend Logo",
            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(16.dp))
        )
        Spacer(Modifier.height(14.dp))
        Text("TEAM LEGEND", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(6.dp))
        Text(
            "Sign in to your account",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(26.dp))

        TlSurfaceCard {
            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it; errorMsg = null },
                label = { Text("Username or Email") },
                leadingIcon = { Icon(Icons.Outlined.AlternateEmail, null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; errorMsg = null },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Outlined.Lock, null) },
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(if (showPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, null)
                    }
                },
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Spacer(Modifier.height(10.dp))
                Text(errorMsg!!, color = TlColors.RoseError, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    if (identifier.isBlank() || password.isBlank()) {
                        errorMsg = "Please enter your username and password."
                        return@Button
                    }
                    loading = true
                    errorMsg = null
                    scope.launch {
                        try {
                            val api = ApiClientFactory(tokenManager).createService()
                            val req = LoginRequest(identifier.trim(), password, "TeamLegend Android")
                            val res = api.userLogin(req)
                            tokenManager.saveSession(
                                token = res.accessToken,
                                role = res.user.role,
                                username = res.user.username,
                                mustChangePassword = res.user.mustChangePassword
                            )
                            onAuthenticated(res.user.role, res.user.mustChangePassword)
                        } catch (e: Exception) {
                            errorMsg = e.localizedMessage ?: "Sign in failed. Check credentials or approval status."
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Text("Sign In", fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = onSwitchToSignup,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("New here? Create Account")
            }
        }
    }
}

@Composable
private fun SignupScreen(
    tokenManager: TokenManager,
    onRegistered: (String) -> Unit,
    onSwitchToLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var whatsapp by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(22.dp)
    ) {
        Text("Create Account", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(4.dp))
        Text(
            "New accounts require approval before accessing numbers, OTPs, and withdrawals.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        TlSurfaceCard {
            OutlinedTextField(fullName, { fullName = it }, label = { Text("Full Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(username, { username = it }, label = { Text("Username *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(email, { email = it }, label = { Text("Email Address *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Password (min 8 chars) *") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("Confirm Password *") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(phone, { phone = it }, label = { Text("Phone Number (Optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(whatsapp, { whatsapp = it }, label = { Text("WhatsApp Number (Optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(referralCode, { referralCode = it }, label = { Text("Referral Code (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            if (errorMsg != null) {
                Spacer(Modifier.height(10.dp))
                Text(errorMsg!!, color = TlColors.RoseError, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (fullName.isBlank() || username.isBlank() || email.isBlank() || password.length < 8) {
                        errorMsg = "Fill all required fields (password must be at least 8 characters)."
                        return@Button
                    }
                    if (password != confirmPassword) {
                        errorMsg = "Passwords do not match."
                        return@Button
                    }
                    loading = true
                    errorMsg = null
                    scope.launch {
                        try {
                            val api = ApiClientFactory(tokenManager).createService()
                            api.signup(
                                SignupRequest(
                                    fullName = fullName.trim(),
                                    username = username.trim(),
                                    email = email.trim(),
                                    password = password,
                                    confirmPassword = confirmPassword,
                                    phone = phone.trim(),
                                    whatsapp = whatsapp.trim(),
                                    referralCode = referralCode.trim()
                                )
                            )
                            onRegistered(username.trim())
                        } catch (e: Exception) {
                            errorMsg = e.localizedMessage ?: "Registration failed."
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("Create Account", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onSwitchToLogin, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Already have an account? Sign In")
            }
        }
    }
}

@Composable
private fun PendingApprovalScreen(username: String, onBackToLogin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TlSurfaceCard {
            Icon(Icons.Outlined.HourglassTop, null, tint = TlColors.ChampagneGold, modifier = Modifier.size(44.dp))
            Spacer(Modifier.height(12.dp))
            Text("Approval Pending", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Account @$username has been created and is awaiting review. Once approved, you can sign in to Team Legend.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(18.dp))
            Button(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text("Return to Sign In")
            }
        }
    }
}

@Composable
fun ForceAdminPasswordChangeScreen(
    tokenManager: TokenManager,
    onPasswordUpdated: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var currentPwd by remember { mutableStateOf("") }
    var newPwd by remember { mutableStateOf("") }
    var confirmPwd by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(22.dp),
        verticalArrangement = Arrangement.Center
    ) {
        TlSurfaceCard {
            TlStatusBadge("SECURITY UPDATE", TlColors.AmberWarn)
            Spacer(Modifier.height(12.dp))
            Text("Update Password", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "First login detected. Set a permanent strong password to continue.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(currentPwd, { currentPwd = it }, label = { Text("Temporary Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(newPwd, { newPwd = it }, label = { Text("New Strong Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirmPwd, { confirmPwd = it }, label = { Text("Confirm New Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())

            if (errorMsg != null) {
                Spacer(Modifier.height(8.dp))
                Text(errorMsg!!, color = TlColors.RoseError)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (newPwd != confirmPwd || newPwd.length < 8) {
                        errorMsg = "Passwords must match and be at least 8 characters."
                        return@Button
                    }
                    loading = true
                    errorMsg = null
                    scope.launch {
                        try {
                            ApiClientFactory(tokenManager).createService().adminChangePassword(
                                ChangePasswordRequest(currentPwd, newPwd, confirmPwd)
                            )
                            tokenManager.clearForcePasswordChange()
                            onPasswordUpdated()
                        } catch (e: Exception) {
                            errorMsg = e.localizedMessage ?: "Password update failed."
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("Update Password")
            }
        }
    }
}
