package com.teamlegend.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Team Legend Unslopped Design System:
 * Obsidian Slate neutrals, crisp 1px hairlines, restrained Champagne Gold primary accent,
 * and Slate Sky secondary accent. Zero neon glows, zero purple gradients, tabular numbers.
 */
object TlColors {
    // Dark Obsidian Neutral Ramp
    val BgCanvas = Color(0xFF0D0F13)
    val BgSurface = Color(0xFF151821)
    val BgElevated = Color(0xFF1D212D)
    val Hairline = Color(0xFF2A2F3D)
    val TextPrimary = Color(0xFFF3F5F8)
    val TextSecondary = Color(0xFF9AA3B5)
    val TextMuted = Color(0xFF6B7487)

    // Restrained Brand Accents
    val ChampagneGold = Color(0xFFE5B84B)
    val ChampagneGoldDim = Color(0x24E5B84B)
    val SlateSky = Color(0xFF38BDF8)
    val EmeraldOk = Color(0xFF22C55E)
    val RoseError = Color(0xFFF43F5E)
    val AmberWarn = Color(0xFFF59E0B)

    // Light Neutral Ramp
    val LightCanvas = Color(0xFFF6F7F9)
    val LightSurface = Color(0xFFFFFFFF)
    val LightElevated = Color(0xFFEEF1F6)
    val LightHairline = Color(0xFFDCE1EC)
    val LightTextPrimary = Color(0xFF11141C)
    val LightTextSecondary = Color(0xFF535D70)
}

private val DarkScheme = darkColorScheme(
    primary = TlColors.ChampagneGold,
    onPrimary = Color(0xFF14110A),
    secondary = TlColors.SlateSky,
    onSecondary = Color(0xFF08141B),
    background = TlColors.BgCanvas,
    onBackground = TlColors.TextPrimary,
    surface = TlColors.BgSurface,
    onSurface = TlColors.TextPrimary,
    surfaceVariant = TlColors.BgElevated,
    onSurfaceVariant = TlColors.TextSecondary,
    outline = TlColors.Hairline,
    error = TlColors.RoseError,
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFFB58619),
    onPrimary = Color.White,
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    background = TlColors.LightCanvas,
    onBackground = TlColors.LightTextPrimary,
    surface = TlColors.LightSurface,
    onSurface = TlColors.LightTextPrimary,
    surfaceVariant = TlColors.LightElevated,
    onSurfaceVariant = TlColors.LightTextSecondary,
    outline = TlColors.LightHairline,
    error = Color(0xFFDC2626),
)

val TlTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 26.sp, letterSpacing = (-0.4).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 15.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium, fontSize = 11.sp),
)

@Composable
fun TeamLegendTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = TlTypography,
        content = content
    )
}
