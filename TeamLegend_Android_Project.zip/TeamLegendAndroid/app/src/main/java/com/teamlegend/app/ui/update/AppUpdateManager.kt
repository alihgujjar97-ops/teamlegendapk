package com.teamlegend.app.ui.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.SystemUpdate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.teamlegend.app.BuildConfig
import com.teamlegend.app.ui.theme.TlColors
import com.teamlegend.app.ui.theme.TlStatusBadge
import com.teamlegend.app.ui.theme.TlSurfaceCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class UpdateManifest(
    @SerializedName("latest_version_code") val latestVersionCode: Int = 0,
    @SerializedName("latest_version_name") val latestVersionName: String = "",
    @SerializedName("force_update") val forceUpdate: Boolean = true,
    @SerializedName("apk_url") val apkUrl: String = "",
    @SerializedName("release_notes") val releaseNotes: String = "New features, speed improvements, and bug fixes."
)

object GitHubAppUpdater {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun checkForUpdate(): UpdateManifest? = withContext(Dispatchers.IO) {
        val repo = BuildConfig.GITHUB_REPO.trim()
        if (repo.isBlank()) return@withContext null

        val manifestUrl = "https://raw.githubusercontent.com/$repo/main/update-manifest.json?t=${System.currentTimeMillis()}"
        runCatching {
            val req = Request.Builder().url(manifestUrl).header("Cache-Control", "no-cache").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val body = resp.body?.string() ?: return@withContext null
                val parsed = Gson().fromJson(body, UpdateManifest::class.java)
                if (parsed != null && parsed.latestVersionCode > BuildConfig.VERSION_CODE && parsed.apkUrl.isNotBlank()) {
                    parsed
                } else null
            }
        }.getOrNull()
    }

    suspend fun downloadApk(
        context: Context,
        apkUrl: String,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
        val outFile = File(updatesDir, "TeamLegend-latest.apk")
        val req = Request.Builder().url(apkUrl).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("Download failed (HTTP ${resp.code})")
            val body = resp.body ?: error("Empty APK response")
            val total = body.contentLength().coerceAtLeast(1L)
            var downloaded = 0L
            body.byteStream().use { input ->
                FileOutputStream(outFile).use { output ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloaded += read
                        onProgress((downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                    }
                    output.flush()
                }
            }
        }
        outFile
    }

    fun installApk(context: Context, apkFile: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            val permIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(permIntent)
            return
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apkFile)
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(installIntent)
    }
}

/**
 * Mandatory In-App Update Gate:
 * Automatically checks GitHub on launch. Whenever a newer release is built on GitHub,
 * shows a blocking popup requiring the user to download & install the new APK.
 */
@Composable
fun MandatoryUpdateGate() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingUpdate by remember { mutableStateOf<UpdateManifest?>(null) }
    var downloading by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        pendingUpdate = GitHubAppUpdater.checkForUpdate()
    }

    val update = pendingUpdate ?: return

    Dialog(
        onDismissRequest = { if (!update.forceUpdate) pendingUpdate = null },
        properties = DialogProperties(
            dismissOnBackPress = !update.forceUpdate,
            dismissOnClickOutside = !update.forceUpdate
        )
    ) {
        TlSurfaceCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Outlined.SystemUpdate, contentDescription = "Update", tint = TlColors.ChampagneGold, modifier = Modifier.size(28.dp))
                Column {
                    Text("Update Required", style = MaterialTheme.typography.headlineMedium)
                    TlStatusBadge("v${update.latestVersionName} (Build ${update.latestVersionCode})", TlColors.ChampagneGold)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "TEAM LEGEND ki nayi update aa gayi hai. App ko continue karne ke liye pehle update download aur install karein.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Text(update.releaseNotes, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)

            if (downloading) {
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text(
                    "Downloading APK... ${(progress * 100).toInt()}%",
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.labelSmall,
                    color = TlColors.ChampagneGold
                )
            }

            if (errorMsg != null) {
                Spacer(Modifier.height(8.dp))
                Text(errorMsg!!, color = TlColors.RoseError, style = MaterialTheme.typography.labelMedium)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    downloading = true
                    errorMsg = null
                    scope.launch {
                        runCatching {
                            val apkFile = GitHubAppUpdater.downloadApk(context, update.apkUrl) { p ->
                                progress = p
                            }
                            GitHubAppUpdater.installApk(context, apkFile)
                        }.onFailure {
                            errorMsg = it.localizedMessage ?: "Download failed. Try again."
                        }
                        downloading = false
                    }
                },
                enabled = !downloading,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (downloading) "Downloading..." else "Update & Install Now", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
