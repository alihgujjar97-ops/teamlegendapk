@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.teamlegend.app.ui.user

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.model.*
import com.teamlegend.app.data.remote.ApiClientFactory
import com.teamlegend.app.ui.games.MiniArcadeScreen
import com.teamlegend.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserVaultShell(
    tokenManager: TokenManager,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onLogout: () -> Unit
) {
    var activeTab by remember { mutableStateOf("overview") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val navItems = listOf(
        Triple("overview", "Vault", Icons.Outlined.SpaceDashboard),
        Triple("numbers", "Numbers", Icons.Outlined.Dialpad),
        Triple("otp", "Live OTP", Icons.Outlined.MarkEmailRead),
        Triple("wallet", "Wallet", Icons.Outlined.AccountBalanceWallet),
        Triple("more", "Tools", Icons.Outlined.GridView),
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TEAM LEGEND", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("@${tokenManager.getUsername()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Icon(if (isDark) Icons.Outlined.LightMode else Icons.Outlined.DarkMode, "Toggle Theme")
                    }
                    IconButton(onClick = {
                        scope.launch {
                            runCatching { ApiClientFactory(tokenManager).createService().logout() }
                            tokenManager.clearSession()
                            onLogout()
                        }
                    }) {
                        Icon(Icons.Outlined.Logout, "Sign Out")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                navItems.forEach { (id, label, icon) ->
                    NavigationBarItem(
                        selected = activeTab == id || (id == "more" && activeTab in listOf("tempmail", "refer", "tv", "leaderboard", "support", "arcade", "prefs")),
                        onClick = { activeTab = id },
                        icon = { Icon(icon, label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            when (activeTab) {
                "overview" -> UserOverviewTab(tokenManager, onNavigate = { activeTab = it })
                "numbers" -> GetNumberTab(tokenManager, onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } })
                "otp" -> LiveOtpInboxTab(tokenManager, onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } })
                "wallet" -> WalletTab(tokenManager, onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } })
                "tempmail" -> TempMailTab(tokenManager, onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } })
                "arcade" -> MiniArcadeScreen(onBack = { activeTab = "more" })
                else -> MoreToolsHubTab(
                    tokenManager = tokenManager,
                    subTab = activeTab,
                    onSelectSubTab = { activeTab = it },
                    onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                )
            }
        }
    }
}

@Composable
private fun UserOverviewTab(tokenManager: TokenManager, onNavigate: (String) -> Unit) {
    var dash by remember { mutableStateOf<DashboardResponse?>(null) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        runCatching { ApiClientFactory(tokenManager).createService().getUserDashboard() }
            .onSuccess { dash = it }
        loading = false
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            TlSectionHeader("User Vault", "Real-time balances, active numbers, and VIP status")
        }
        if (loading) {
            item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TlMetricTile(
                    label = "USD Balance",
                    value = "$${"%.4f".format(dash?.wallet?.balanceUsd ?: 0.0)}",
                    icon = Icons.Outlined.AttachMoney,
                    accent = TlColors.ChampagneGold,
                    modifier = Modifier.weight(1f)
                )
                TlMetricTile(
                    label = "PKR Balance",
                    value = "Rs ${"%.0f".format(dash?.wallet?.balancePkr ?: 0.0)}",
                    icon = Icons.Outlined.CurrencyRupee,
                    accent = TlColors.EmeraldOk,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TlMetricTile(
                    label = "Active Numbers",
                    value = "${dash?.stats?.activeNumbers ?: 0}",
                    icon = Icons.Outlined.SimCard,
                    accent = TlColors.SlateSky,
                    modifier = Modifier.weight(1f)
                )
                TlMetricTile(
                    label = "VIP Tier",
                    value = "${dash?.vip?.rank ?: "Bronze"} (${dash?.vip?.multiplier ?: 1.0}x)",
                    icon = Icons.Outlined.WorkspacePremium,
                    accent = TlColors.ChampagneGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            TlSurfaceCard {
                Text("Quick Actions", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { onNavigate("numbers") }, modifier = Modifier.weight(1f)) { Text("Get Number") }
                    FilledTonalButton(onClick = { onNavigate("tempmail") }, modifier = Modifier.weight(1f)) { Text("Temp Mail") }
                    FilledTonalButton(onClick = { onNavigate("arcade") }, modifier = Modifier.weight(1f)) { Text("10 Games") }
                }
            }
        }
        item {
            TlSurfaceCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Recent OTP Activity", style = MaterialTheme.typography.titleMedium)
                    TlStatusBadge("LIVE SSE", TlColors.EmeraldOk)
                }
                Spacer(Modifier.height(10.dp))
                val items = dash?.recentActivity.orEmpty()
                if (items.isEmpty()) {
                    Text("No OTPs received yet. Claim a number to start receiving real-time codes.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    items.forEach { otp ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(otp.serviceName, fontWeight = FontWeight.Medium)
                                Text(otp.phoneNumber, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(otp.otpCode, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TlColors.ChampagneGold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GetNumberTab(tokenManager: TokenManager, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var mode by remember { mutableStateOf("all") }
    var prefixQuery by remember { mutableStateOf("") }
    var countryQuery by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf<List<StockItemDto>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    fun refresh() {
        loading = true
        scope.launch {
            runCatching {
                ApiClientFactory(tokenManager).createService().getLiveStock(
                    mode = mode,
                    country = countryQuery.ifBlank { null },
                    prefix = if (mode == "prefix" && prefixQuery.length >= 3) prefixQuery else null
                )
            }.onSuccess { stock = it.items }
                .onFailure { onMessage(it.localizedMessage ?: "Failed to load live stock") }
            loading = false
        }
    }

    LaunchedEffect(mode) { refresh() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TlSectionHeader("Get Number", "5 allocation modes • 30-minute exclusive lock")
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val modes = listOf("all" to "All Stock", "live24h" to "24h Active", "country" to "Country", "range" to "Hot Ranges", "prefix" to "Prefix 3-9")
            items(modes) { (id, label) ->
                FilterChip(selected = mode == id, onClick = { mode = id }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (mode == "prefix") {
            OutlinedTextField(
                value = prefixQuery,
                onValueChange = { if (it.length <= 9) prefixQuery = it.filter(Char::isDigit) },
                label = { Text("Enter 3–9 digit prefix (e.g. 4474)") },
                trailingIcon = { IconButton(onClick = { refresh() }) { Icon(Icons.Outlined.Search, "Search") } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
        } else {
            OutlinedTextField(
                value = countryQuery,
                onValueChange = { countryQuery = it },
                label = { Text("Filter by country or service") },
                trailingIcon = { IconButton(onClick = { refresh() }) { Icon(Icons.Outlined.Refresh, "Refresh") } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
        }

        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(stock) { item ->
                TlSurfaceCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(item.phoneNumber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                            Text("${item.countryName} • ${item.serviceName}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching {
                                        ApiClientFactory(tokenManager).createService().claimNumber(ClaimNumberRequest(numberId = item.id))
                                    }.onSuccess {
                                        clipboard.setText(AnnotatedString(item.phoneNumber))
                                        onMessage("Allocated & copied ${item.phoneNumber} (30-min lock)")
                                        refresh()
                                    }.onFailure { onMessage(it.localizedMessage ?: "Allocation failed") }
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("Claim") }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveOtpInboxTab(tokenManager: TokenManager, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var liveEvents by remember { mutableStateOf<List<String>>(emptyList()) }

    DisposableEffect(Unit) {
        val es = ApiClientFactory(tokenManager).openOtpStream { payload ->
            liveEvents = listOf(payload) + liveEvents.take(25)
        }
        onDispose { es.cancel() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TlSectionHeader("Live OTP Inbox", "Real-time SSE stream with Prefix-Minus-One feed")
            TlStatusBadge("STREAMING", TlColors.EmeraldOk)
        }
        Spacer(Modifier.height(12.dp))
        TlSurfaceCard {
            Text(
                if (liveEvents.isEmpty()) "Listening for incoming SMS/OTP codes on your active numbers..."
                else "${liveEvents.size} real-time OTP events received in this session.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            liveEvents.forEach { raw ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        clipboard.setText(AnnotatedString(raw))
                        onMessage("Copied OTP payload")
                    }.padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(raw, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    scope.launch {
                        runCatching { ApiClientFactory(tokenManager).createService().getOtpInbox() }
                            .onSuccess { onMessage("OTP Inbox synced with server") }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Manual Refresh SMS") }
        }
    }
}

@Composable
private fun WalletTab(tokenManager: TokenManager, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var swapAmount by remember { mutableStateOf("1.0") }
    var wdMethod by remember { mutableStateOf("USDT_POLYGON") }
    var wdAmount by remember { mutableStateOf("1.0") }
    var wdDest by remember { mutableStateOf("") }
    val methods = listOf("USDT_POLYGON", "BINANCE_PAY", "USDT_TRC20", "EASYPAISA", "JAZZCASH", "PK_BANK")

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { TlSectionHeader("Wallet & Payouts", "Dual USD/PKR sub-wallets, atomic FX swap, and verified withdrawals") }
        item {
            TlSurfaceCard {
                Text("Atomic USD ⇄ PKR Exchange", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(swapAmount, { swapAmount = it }, label = { Text("Amount") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                ApiClientFactory(tokenManager).createService().exchangeCurrency(ExchangeRequest("USD_TO_PKR", swapAmount.toDoubleOrNull() ?: 0.0))
                            }.onSuccess { onMessage("Converted USD → PKR successfully") }
                                .onFailure { onMessage(it.localizedMessage ?: "Exchange failed") }
                        }
                    }, modifier = Modifier.weight(1f)) { Text("USD → PKR") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                ApiClientFactory(tokenManager).createService().exchangeCurrency(ExchangeRequest("PKR_TO_USD", swapAmount.toDoubleOrNull() ?: 0.0))
                            }.onSuccess { onMessage("Converted PKR → USD successfully") }
                                .onFailure { onMessage(it.localizedMessage ?: "Exchange failed") }
                        }
                    }, modifier = Modifier.weight(1f)) { Text("PKR → USD") }
                }
            }
        }
        item {
            TlSurfaceCard {
                Text("Request Withdrawal", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(methods) { m ->
                        FilterChip(selected = wdMethod == m, onClick = { wdMethod = m }, label = { Text(m.replace("_", " ")) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(wdAmount, { wdAmount = it }, label = { Text("Withdrawal Amount") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(wdDest, { wdDest = it }, label = { Text("Wallet Address / Binance UID / Account No.") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        scope.launch {
                            runCatching {
                                ApiClientFactory(tokenManager).createService().requestWithdrawal(
                                    WithdrawalCreateRequest(method = wdMethod, amount = wdAmount.toDoubleOrNull() ?: 0.0, destination = wdDest.trim())
                                )
                            }.onSuccess { onMessage("Withdrawal submitted for Admin review") }
                                .onFailure { onMessage(it.localizedMessage ?: "Withdrawal failed") }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) { Text("Submit Withdrawal Request") }
            }
        }
    }
}

@Composable
private fun TempMailTab(tokenManager: TokenManager, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var boxes by remember { mutableStateOf<List<TempMailBoxDto>>(emptyList()) }
    var customUser by remember { mutableStateOf("") }
    var selectedEngine by remember { mutableStateOf("mailtm") }
    val engines = listOf("mailtm", "mailgw", "dropmail", "tempmail_lol", "guerrilla", "tempmailplus", "maildrop", "1secmail")

    fun load() {
        scope.launch {
            runCatching { ApiClientFactory(tokenManager).createService().listTempMail() }
                .onSuccess { boxes = it["mailboxes"].orEmpty() }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TlSectionHeader("Free Human-Style Temp Mail", "8 independent engines • auto OTP & clean link extraction")
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(engines) { eng ->
                FilterChip(selected = selectedEngine == eng, onClick = { selectedEngine = eng }, label = { Text(eng) })
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(customUser, { customUser = it }, label = { Text("Custom username (leave blank for random)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                scope.launch {
                    runCatching {
                        ApiClientFactory(tokenManager).createService().createTempMail(TempMailCreateRequest(selectedEngine, customUser))
                    }.onSuccess {
                        clipboard.setText(AnnotatedString(it.address))
                        onMessage("Created & copied ${it.address}")
                        customUser = ""
                        load()
                    }.onFailure { onMessage(it.localizedMessage ?: "Failed to create mailbox") }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Generate Mailbox") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(boxes) { b ->
                TlSurfaceCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(b.address, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium)
                            Text("Engine: ${b.engine}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            clipboard.setText(AnnotatedString(b.address))
                            onMessage("Copied ${b.address}")
                        }) { Icon(Icons.Outlined.ContentCopy, "Copy") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MoreToolsHubTab(
    tokenManager: TokenManager,
    subTab: String,
    onSelectSubTab: (String) -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val tools = listOf(
        Triple("tempmail", "Temp Mail (8 Engines)", Icons.Outlined.AlternateEmail),
        Triple("arcade", "10-in-1 Mini Arcade", Icons.Outlined.SportsEsports),
        Triple("refer", "Refer & Earn (5%) + Daily Streak", Icons.Outlined.CardGiftcard),
        Triple("tv", "TV Video Methods & Guides", Icons.Outlined.OndemandVideo),
        Triple("leaderboard", "Privacy-Masked Leaderboard", Icons.Outlined.Leaderboard),
        Triple("support", "24/7 Support Tickets", Icons.Outlined.SupportAgent),
    )

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TlSectionHeader("Tools & Ecosystem", "All Team Legend modules native in Kotlin + Compose") }
        items(tools) { (id, title, icon) ->
            TlSurfaceCard(modifier = Modifier.clickable {
                if (id == "refer") {
                    scope.launch {
                        runCatching { ApiClientFactory(tokenManager).createService().claimStreak() }
                            .onSuccess { onMessage("Daily streak bonus claimed!") }
                            .onFailure { onMessage(it.localizedMessage ?: "Streak already claimed today") }
                    }
                } else {
                    onSelectSubTab(id)
                }
            }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(icon, title, tint = TlColors.ChampagneGold)
                    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
