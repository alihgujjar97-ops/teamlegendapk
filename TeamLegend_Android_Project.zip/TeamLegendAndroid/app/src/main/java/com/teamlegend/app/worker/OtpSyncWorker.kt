package com.teamlegend.app.worker

import android.content.Context
import androidx.work.*
import com.teamlegend.app.data.local.TokenManager
import com.teamlegend.app.data.remote.ApiClientFactory
import java.util.concurrent.TimeUnit

class OtpSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val tm = TokenManager(applicationContext)
        if (tm.getToken().isNullOrBlank()) return Result.success()
        return try {
            ApiClientFactory(tm).createService().getOtpInbox()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedulePeriodicSync(context: Context) {
            val req = PeriodicWorkRequestBuilder<OtpSyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "tl_otp_sync",
                ExistingPeriodicWorkPolicy.KEEP,
                req
            )
        }
    }
}
