package com.teamlegend.app

import com.teamlegend.app.security.InputValidator
import org.junit.Assert.*
import org.junit.Test

class InputValidatorTest {
    @Test
    fun validUsernameAndPasswordPass() {
        assertNull(InputValidator.validateUsername("legend_user01"))
        assertNull(InputValidator.validatePassword("LegendPass123"))
        assertNull(InputValidator.validateFullName("Ali Hassan"))
    }

    @Test
    fun optionalEmailAndMobileAllowBlank() {
        assertNull(InputValidator.validateOptionalEmail(""))
        assertNull(InputValidator.validateOptionalMobile(""))
        assertNull(InputValidator.validateOptionalEmail("user@example.com"))
        assertNull(InputValidator.validateOptionalMobile("+923001234567"))
        assertNotNull(InputValidator.validateOptionalEmail("invalid-email"))
        assertNotNull(InputValidator.validateOptionalMobile("abc"))
    }

    @Test
    fun withdrawalValidationBlocksOverdraftAndBelowMin() {
        assertNotNull(InputValidator.validateWithdrawal("50", "03001234567", 500.0, 100.0))
        assertNotNull(InputValidator.validateWithdrawal("600", "03001234567", 500.0, 100.0))
        assertNull(InputValidator.validateWithdrawal("250", "03001234567", 500.0, 100.0))
    }
}
