package com.teamlegend.app

import com.google.gson.JsonParser
import com.teamlegend.app.data.repository.NumbersApiParser
import org.junit.Assert.*
import org.junit.Test

class NumbersApiParserTest {
    @Test
    fun parsesObjectWrappedNumbersSafely() {
        val json = JsonParser.parseString(
            """{"numbers":[{"number":"+923001112233","country":"Pakistan","service":"WhatsApp","range":"PK-WA"}]}"""
        )
        val parsed = NumbersApiParser.parse(json, 1000L)
        assertEquals(1, parsed.size)
        assertEquals("+923001112233", parsed[0].number)
        assertEquals("Pakistan", parsed[0].country)
    }

    @Test
    fun handlesEmptyOrMalformedJsonWithoutCrash() {
        assertTrue(NumbersApiParser.parse(null).isEmpty())
        assertTrue(NumbersApiParser.parse(JsonParser.parseString("{}")).isEmpty())
    }
}
