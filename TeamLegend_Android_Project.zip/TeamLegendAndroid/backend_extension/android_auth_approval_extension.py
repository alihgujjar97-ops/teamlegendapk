"""
TEAM LEGEND — Companion FastAPI Extension for Native Android Registration & Approval
------------------------------------------------------------------------------------
Mounts directly onto Main.py's existing FastAPI `app` without replacing or breaking
any existing Telegram Bot, Web Portal, Wallet, Stock, or Panel routes.

How to mount in Main.py (2 lines inside `create_fastapi_web_app()` before `return app`):
    from android_auth_approval_extension import register_android_auth_routes
    register_android_auth_routes(
        app=app,
        db_path="team_legend_android_auth.sqlite3",
        extract_token_fn=_extract_token,
        get_session_fn=get_web_session_from_token,
        persist_token_fn=_persist_web_token,
        web_auth_tokens_dict=web_auth_tokens,
        secret_key=SECRET_KEY,
    )
"""

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
import uuid
from typing import Callable, Optional

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

PBKDF2_ITERATIONS = 210_000
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MOBILE_RE = re.compile(r"^\+?[0-9\-\s]{7,20}$")


def _hash_password(password: str, salt_hex: Optional[str] = None) -> str:
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt.hex()}${dk.hex()}"


def _verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters_s, salt_hex, hash_hex = stored.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters_s)
        )
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def _init_db(db_path: str) -> None:
    conn = sqlite3.connect(db_path)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS android_registrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL,
                email TEXT DEFAULT '',
                mobile_number TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'pending',
                role TEXT NOT NULL DEFAULT 'user',
                linked_uid INTEGER NOT NULL,
                rejection_reason TEXT DEFAULT '',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_android_reg_status ON android_registrations(status)"
        )
        conn.commit()
    finally:
        conn.close()


def _allocate_android_uid(conn: sqlite3.Connection) -> int:
    # Deterministic non-colliding positive ID range for Android-registered users (>= 9_000_000_001)
    row = conn.execute("SELECT COALESCE(MAX(linked_uid), 9000000000) FROM android_registrations").fetchone()
    return int(row[0]) + 1


def register_android_auth_routes(
    app: FastAPI,
    db_path: str,
    extract_token_fn: Callable[[Request], str],
    get_session_fn: Callable[[str], Optional[dict]],
    persist_token_fn: Callable[[str, dict], None],
    web_auth_tokens_dict: dict,
    secret_key: str,
) -> None:
    _init_db(db_path)

    def _require_admin(req: Request) -> Optional[dict]:
        tok = extract_token_fn(req)
        sess = get_session_fn(tok) if tok else None
        if not sess or sess.get("role") != "admin":
            return None
        return sess

    @app.post("/api/android/auth/signup")
    async def android_signup(req: Request):
        body = await req.json()
        username = str(body.get("username") or "").strip()
        password = str(body.get("password") or "")
        full_name = str(body.get("full_name") or "").strip()
        email = str(body.get("email") or "").strip()
        mobile = str(body.get("mobile_number") or "").strip()

        if not USERNAME_RE.match(username):
            return JSONResponse(
                {"ok": False, "message": "Username must be 3-32 characters (letters, numbers, _, ., -)."},
                status_code=400,
            )
        if len(password) < 8:
            return JSONResponse(
                {"ok": False, "message": "Password must be at least 8 characters long."},
                status_code=400,
            )
        if len(full_name) < 2 or len(full_name) > 80:
            return JSONResponse(
                {"ok": False, "message": "Full Name is required (2-80 characters)."},
                status_code=400,
            )
        if email and not EMAIL_RE.match(email):
            return JSONResponse({"ok": False, "message": "Invalid email format."}, status_code=400)
        if mobile and not MOBILE_RE.match(mobile):
            return JSONResponse({"ok": False, "message": "Invalid mobile number format."}, status_code=400)

        now = time.time()
        pw_hash = _hash_password(password)
        conn = sqlite3.connect(db_path)
        try:
            existing = conn.execute(
                "SELECT id FROM android_registrations WHERE LOWER(username) = LOWER(?)", (username,)
            ).fetchone()
            if existing:
                return JSONResponse(
                    {"ok": False, "message": "This username is already taken. Please choose another."},
                    status_code=409,
                )
            linked_uid = _allocate_android_uid(conn)
            cur = conn.execute(
                """
                INSERT INTO android_registrations
                (username, password_hash, full_name, email, mobile_number, status, role, linked_uid, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'pending', 'user', ?, ?, ?)
                """,
                (username, pw_hash, full_name, email, mobile, linked_uid, now, now),
            )
            conn.commit()
            reg_id = cur.lastrowid
        finally:
            conn.close()

        return JSONResponse(
            {
                "ok": True,
                "registration_id": reg_id,
                "username": username,
                "status": "pending",
                "message": "Account created! Your registration is pending Administrator approval.",
            },
            status_code=201,
        )

    @app.post("/api/android/auth/login")
    async def android_login(req: Request):
        body = await req.json()
        username = str(body.get("username") or "").strip()
        password = str(body.get("password") or "")
        if not username or not password:
            return JSONResponse({"ok": False, "message": "Username and password are required."}, status_code=400)

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT * FROM android_registrations WHERE LOWER(username) = LOWER(?)", (username,)
            ).fetchone()
        finally:
            conn.close()

        if not row or not _verify_password(password, row["password_hash"]):
            return JSONResponse(
                {"ok": False, "status": "invalid", "message": "Invalid username or password."},
                status_code=401,
            )

        status = str(row["status"]).lower()
        if status == "pending":
            return JSONResponse(
                {
                    "ok": False,
                    "status": "pending",
                    "username": row["username"],
                    "message": "Your account is still pending Administrator approval.",
                },
                status_code=403,
            )
        if status == "rejected":
            reason = row["rejection_reason"] or "Contact support for details."
            return JSONResponse(
                {
                    "ok": False,
                    "status": "rejected",
                    "username": row["username"],
                    "message": f"Your registration was rejected. {reason}",
                },
                status_code=403,
            )
        if status == "suspended":
            return JSONResponse(
                {
                    "ok": False,
                    "status": "suspended",
                    "username": row["username"],
                    "message": "Your account has been suspended by an Administrator.",
                },
                status_code=403,
            )

        now = time.time()
        raw_token = hashlib.sha256(
            f"android:{row['linked_uid']}:{now}:{secret_key}:{uuid.uuid4().hex}".encode()
        ).hexdigest()
        sess_obj = {
            "user_id": int(row["linked_uid"]),
            "username": row["username"],
            "full_name": row["full_name"],
            "role": str(row["role"] or "user"),
            "status": "approved",
            "created": now,
        }
        web_auth_tokens_dict[raw_token] = sess_obj
        persist_token_fn(raw_token, sess_obj)

        return JSONResponse(
            {
                "ok": True,
                "token": raw_token,
                "role": sess_obj["role"],
                "status": "approved",
                "username": row["username"],
                "full_name": row["full_name"],
                "user_id": int(row["linked_uid"]),
                "message": "Login successful.",
            }
        )

    @app.get("/api/android/auth/status")
    async def android_status(req: Request):
        username = str(req.query_params.get("username") or "").strip()
        if not username:
            return JSONResponse({"ok": False, "message": "Username parameter is required."}, status_code=400)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT username, status, rejection_reason, created_at, updated_at FROM android_registrations WHERE LOWER(username) = LOWER(?)",
                (username,),
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return JSONResponse({"ok": False, "status": "not_found", "message": "Registration not found."}, status_code=404)
        return JSONResponse(
            {
                "ok": True,
                "username": row["username"],
                "status": row["status"],
                "rejection_reason": row["rejection_reason"] or "",
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
        )

    @app.get("/api/android/admin/registrations")
    async def admin_list_registrations(req: Request):
        if not _require_admin(req):
            return JSONResponse({"ok": False, "message": "Admin privileges required."}, status_code=403)
        status_filter = str(req.query_params.get("status") or "").strip().lower()
        q = str(req.query_params.get("q") or "").strip().lower()

        sql = "SELECT id, username, full_name, email, mobile_number, status, role, linked_uid, rejection_reason, created_at, updated_at FROM android_registrations WHERE 1=1"
        params = []
        if status_filter in ("pending", "approved", "rejected", "suspended"):
            sql += " AND status = ?"
            params.append(status_filter)
        if q:
            sql += " AND (LOWER(username) LIKE ? OR LOWER(full_name) LIKE ? OR LOWER(email) LIKE ?)"
            like = f"%{q}%"
            params.extend([like, like, like])
        sql += " ORDER BY created_at DESC LIMIT 200"

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        finally:
            conn.close()
        return JSONResponse({"ok": True, "registrations": rows})

    @app.post("/api/android/admin/registrations/decide")
    async def admin_decide_registration(req: Request):
        if not _require_admin(req):
            return JSONResponse({"ok": False, "message": "Admin privileges required."}, status_code=403)
        body = await req.json()
        reg_id = body.get("registration_id")
        decision = str(body.get("decision") or "").strip().lower()
        reason = str(body.get("reason") or "").strip()[:200]

        mapping = {
            "approve": "approved",
            "reject": "rejected",
            "suspend": "suspended",
            "restore": "approved",
        }
        if decision not in mapping or not reg_id:
            return JSONResponse(
                {"ok": False, "message": "Provide valid registration_id and decision (approve/reject/suspend/restore)."},
                status_code=400,
            )
        new_status = mapping[decision]
        now = time.time()
        conn = sqlite3.connect(db_path)
        try:
            cur = conn.execute(
                "UPDATE android_registrations SET status = ?, rejection_reason = ?, updated_at = ? WHERE id = ?",
                (new_status, reason if new_status == "rejected" else "", now, int(reg_id)),
            )
            conn.commit()
            if cur.rowcount == 0:
                return JSONResponse({"ok": False, "message": "Registration not found."}, status_code=404)
        finally:
            conn.close()
        return JSONResponse({"ok": True, "status": new_status, "message": f"Registration #{reg_id} updated to {new_status.upper()}."})
