package com.teamlegend.app.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.teamlegend.app.BuildConfig

/**
 * Hardware-backed EncryptedSharedPreferences for session tokens and preferences.
 * Never persists raw user or Master Admin passwords.
 */
class TokenManager(context: Context) {
    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "tl_secure_vault",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("tl_secure_vault_fallback", Context.MODE_PRIVATE)
    }

    fun saveSession(token: String, role: String, username: String, mustChangePassword: Boolean) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_ROLE, role)
            .putString(KEY_USERNAME, username)
            .putBoolean(KEY_FORCE_PWD, mustChangePassword)
            .apply()
    }

    fun clearForcePasswordChange() {
        prefs.edit().putBoolean(KEY_FORCE_PWD, false).apply()
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_ROLE)
            .remove(KEY_USERNAME)
            .remove(KEY_FORCE_PWD)
            .apply()
    }

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)
    fun getRole(): String = prefs.getString(KEY_ROLE, "USER") ?: "USER"
    fun getUsername(): String = prefs.getString(KEY_USERNAME, "") ?: ""
    fun mustChangePassword(): Boolean = prefs.getBoolean(KEY_FORCE_PWD, false)
    fun isDarkTheme(): Boolean = prefs.getBoolean(KEY_DARK_THEME, true)
    fun setDarkTheme(dark: Boolean) = prefs.edit().putBoolean(KEY_DARK_THEME, dark).apply()

    fun getApiBaseUrl(): String =
        prefs.getString(KEY_BASE_URL, BuildConfig.DEFAULT_API_BASE_URL) ?: BuildConfig.DEFAULT_API_BASE_URL

    fun setApiBaseUrl(url: String) = prefs.edit().putString(KEY_BASE_URL, url.trim().trimEnd('/')).apply()

    companion object {
        private const val KEY_TOKEN = "jwt_access_token"
        private const val KEY_ROLE = "account_role"
        private const val KEY_USERNAME = "account_username"
        private const val KEY_FORCE_PWD = "must_change_password"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_BASE_URL = "api_base_url"
    }
}
