"""
TEAM LEGEND — Complete Standalone Android Backend API Extension
================================================================
Drop-in FastAPI router + standalone server that integrates with Main.py's
SQLite WAL architecture and adds:
  1. Single Master Admin authentication (`teamlegend_admin`, env-seeded,
     PBKDF2-HMAC-SHA256 hashed, forced password change on first login).
  2. Independent User Signup -> Pending Approval -> Admin Approve/Reject -> Login.
  3. Full User Vault & Admin Command Center REST + SSE endpoints with 100% parity
     to Main.py (Numbers 5 modes, Live OTP SSE, 8-Engine Temp Mail, Dual-Currency
     Wallet & Atomic Exchange, Polygon/Binance/TRC-20/29 PK Bank Withdrawals,
     5% Server-Side Referrals, VIP Tiers, 7-Day Streaks, TV Video Methods,
     Privacy-Masked Leaderboard, Support Tickets, Inline Bot Console, and
     complete Admin Console).

Usage with Main.py:
    from backend.android_api_extension import router as android_v1_router, bootstrap_android_backend
    bootstrap_android_backend()
    app.include_router(android_v1_router)

Standalone execution:
    uvicorn backend.android_api_extension:app --host 0.0.0.0 --port 8080
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import io
import json
import os
import random
import re
import secrets
import sqlite3
import string
import time
import zipfile
from collections import defaultdict
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

import sys
from pathlib import Path as _Path
_CUR_DIR = str(_Path(__file__).resolve().parent)
if _CUR_DIR not in sys.path:
    sys.path.insert(0, _CUR_DIR)

try:
    from db_migrations import DEFAULT_DB_PATH, get_connection, run_migrations
except ImportError:
    from backend.db_migrations import DEFAULT_DB_PATH, get_connection, run_migrations

# ==============================================================================
# SECURITY CONSTANTS & HELPERS
# ==============================================================================
MASTER_ADMIN_USERNAME = os.environ.get("TL_ADMIN_USERNAME", "teamlegend_admin").strip().lower()
JWT_SECRET = os.environ.get("TL_JWT_SECRET") or secrets.token_hex(32)
PBKDF2_ITERATIONS = 310_000
SESSION_TTL_SECONDS = 60 * 60 * 24 * 7  # 7 days
NUMBER_LOCK_SECONDS = 1800  # 30 minutes (parity with Main.py _v10_number_expiry_daemon)

PK_BANKS_AND_WALLETS = [
    "EasyPaisa", "JazzCash", "NayaPay", "SadaPay", "UPaisa", "Zindigi",
    "Meezan Bank", "HBL (Habib Bank)", "UBL (United Bank)", "MCB Bank",
    "Allied Bank (ABL)", "Bank Alfalah", "Faysal Bank", "Askari Bank",
    "Bank Al Habib", "Standard Chartered PK", "JS Bank", "HabibMetro",
    "Soneri Bank", "Silk Bank", "Summit Bank", "Bank of Punjab (BOP)",
    "Bank of Khyber", "Sindh Bank", "National Bank (NBP)", "Dubai Islamic Bank",
    "Al Baraka Bank", "MCB Islamic Bank", "First Women Bank",
]

TEMPMAIL_ENGINES = [
    {"id": "mailtm", "label": "Mail.tm Engine", "domains": ["dollicons.com", "exelica.com", "bugfoo.com"]},
    {"id": "mailgw", "label": "Mail.gw Engine", "domains": ["wireconnected.com", "mechanicspedia.com"]},
    {"id": "dropmail", "label": "DropMail Engine", "domains": ["10mail.org", "yomail.info"]},
    {"id": "tempmail_lol", "label": "TempMail.lol Engine", "domains": ["tempmail.lol", "fastmail.lol"]},
    {"id": "guerrilla", "label": "Guerrilla Engine", "domains": ["sharklasers.com", "grr.la"]},
    {"id": "tempmailplus", "label": "TempMailPlus Engine", "domains": ["mailto.plus", "fexpost.com"]},
    {"id": "maildrop", "label": "Maildrop Engine", "domains": ["maildrop.cc"]},
    {"id": "1secmail", "label": "1SecMail Engine", "domains": ["1secmail.com", "1secmail.org"]},
]

# Simple in-memory sliding-window rate limiter for auth endpoints
_RATE_BUCKETS: Dict[str, List[float]] = defaultdict(list)


def _check_rate_limit(key: str, limit: int = 20, window_sec: int = 60) -> None:
    now = time.time()
    bucket = [t for t in _RATE_BUCKETS[key] if now - t < window_sec]
    if len(bucket) >= limit:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many requests. Please wait a moment and try again.",
        )
    bucket.append(now)
    _RATE_BUCKETS[key] = bucket


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algo, iters_str, salt_b64, dk_b64 = stored_hash.split("$")
        if algo != "pbkdf2_sha256":
            return False
        iters = int(iters_str)
        salt = base64.b64decode(salt_b64)
        expected_dk = base64.b64decode(dk_b64)
        actual_dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iters)
        return hmac.compare_digest(actual_dk, expected_dk)
    except Exception:
        return False


def validate_password_strength(password: str) -> None:
    if len(password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long.")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"[0-9]", password):
        raise HTTPException(status_code=400, detail="Password must include both letters and numbers.")


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def create_access_token(payload: Dict[str, Any]) -> str:
    header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    body = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
    sig = hmac.new(JWT_SECRET.encode("utf-8"), f"{header}.{body}".encode("ascii"), hashlib.sha256).digest()
    return f"{header}.{body}.{_b64url_encode(sig)}"


def decode_access_token(token: str) -> Dict[str, Any]:
    parts = token.split(".")
    if len(parts) != 3:
        raise HTTPException(status_code=401, detail="Invalid session token.")
    header, body, sig = parts
    expected_sig = _b64url_encode(
        hmac.new(JWT_SECRET.encode("utf-8"), f"{header}.{body}".encode("ascii"), hashlib.sha256).digest()
    )
    if not hmac.compare_digest(sig, expected_sig):
        raise HTTPException(status_code=401, detail="Session signature verification failed.")
    payload = json.loads(_b64url_decode(body).decode("utf-8"))
    if payload.get("exp", 0) < int(time.time()):
        raise HTTPException(status_code=401, detail="Session expired. Please sign in again.")
    return payload


def mask_number_prefix_minus_one(phone_number: str, prefix: str = "") -> str:
    """Parity with Main.py Prefix-Minus-One masking: +{P[:-1]}••{N[-4:]}."""
    digits = re.sub(r"\D", "", phone_number or "")
    if len(digits) < 6:
        return f"+{digits}"
    p = re.sub(r"\D", "", prefix or digits[:4])
    lead = p[:-1] if len(p) > 1 else digits[:2]
    return f"+{lead}••{digits[-4:]}"


def mask_username_privacy(username: str) -> str:
    """Parity with Main.py Privacy-Masked Leaderboard: User••••XX."""
    clean = (username or "User").strip()
    if len(clean) <= 4:
        return f"{clean[:2]}••••"
    return f"{clean[:4]}••••{clean[-2:]}"


def generate_referral_code(username: str) -> str:
    base = re.sub(r"[^A-Z0-9]", "", username.upper())[:6] or "TL"
    suffix = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(4))
    return f"TL-{base}-{suffix}"


# ==============================================================================
# DATABASE CONTEXT & SINGLE MASTER ADMIN BOOTSTRAP
# ==============================================================================
_ACTIVE_DB_PATH = DEFAULT_DB_PATH


def set_active_db_path(db_path: str) -> None:
    global _ACTIVE_DB_PATH
    _ACTIVE_DB_PATH = db_path


def _db() -> sqlite3.Connection:
    return get_connection(_ACTIVE_DB_PATH)


def _get_config(conn: sqlite3.Connection, key: str, default: Any) -> Any:
    row = conn.execute("SELECT value_json FROM system_config WHERE key = ?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["value_json"])
    except Exception:
        return default


def _set_config(conn: sqlite3.Connection, key: str, value: Any) -> None:
    now = int(time.time())
    conn.execute(
        "INSERT INTO system_config (key, value_json, updated_at) VALUES (?, ?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
        (key, json.dumps(value), now),
    )


def _record_audit(
    conn: sqlite3.Connection,
    admin_id: int,
    action: str,
    target_type: str = "",
    target_id: str = "",
    details: Optional[Dict[str, Any]] = None,
    ip_address: str = "",
) -> None:
    conn.execute(
        "INSERT INTO admin_audit_logs (admin_id, action, target_type, target_id, details_json, ip_address, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (admin_id, action, target_type, str(target_id), json.dumps(details or {}), ip_address, int(time.time())),
    )


def _notify(conn: sqlite3.Connection, account_id: int, title: str, body: str, category: str = "SYSTEM") -> None:
    conn.execute(
        "INSERT INTO android_notifications (account_id, title, body, category, is_read, created_at) "
        "VALUES (?, ?, ?, ?, 0, ?)",
        (account_id, title, body, category, int(time.time())),
    )


def bootstrap_android_backend(db_path: Optional[str] = None, initial_admin_password: Optional[str] = None) -> None:
    """
    Runs SQLite WAL migrations and seeds the SINGLE Master Admin account (`teamlegend_admin`)
    strictly from environment variable `TL_ADMIN_INITIAL_PASSWORD` (or explicit bootstrap arg).
    Never hardcodes the admin password in source code.
    """
    if db_path:
        set_active_db_path(db_path)
    run_migrations(_ACTIVE_DB_PATH)

    conn = _db()
    try:
        existing_admin = conn.execute(
            "SELECT id, username FROM android_accounts WHERE role = 'ADMIN'"
        ).fetchone()
        if existing_admin:
            return

        bootstrap_pwd = initial_admin_password or os.environ.get("TL_ADMIN_INITIAL_PASSWORD", "").strip()
        if not bootstrap_pwd:
            # Secure fallback: do not seed with an insecure default password
            return

        now = int(time.time())
        conn.execute(
            """
            INSERT INTO android_accounts (
                full_name, username, email, password_hash, role, status,
                must_change_password, referral_code, created_at, updated_at, approved_at
            ) VALUES (?, ?, ?, ?, 'ADMIN', 'APPROVED', 1, ?, ?, ?, ?)
            """,
            (
                "Team Legend Master Admin",
                MASTER_ADMIN_USERNAME,
                "admin@teamlegendsofficial.site",
                hash_password(bootstrap_pwd),
                "TL-MASTER-ADMIN",
                now,
                now,
                now,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def _resolve_vip_tier(conn: sqlite3.Connection, total_otps: int) -> Dict[str, Any]:
    tiers = _get_config(conn, "vip_tiers", [])
    current = {"name": "Bronze", "min_otps": 0, "multiplier": 1.0}
    next_tier = None
    for idx, t in enumerate(sorted(tiers, key=lambda x: x.get("min_otps", 0))):
        if total_otps >= t.get("min_otps", 0):
            current = t
            if idx + 1 < len(tiers):
                next_tier = sorted(tiers, key=lambda x: x.get("min_otps", 0))[idx + 1]
    return {
        "rank": current["name"],
        "multiplier": current["multiplier"],
        "next_rank": next_tier["name"] if next_tier else None,
        "otps_to_next": max(0, next_tier["min_otps"] - total_otps) if next_tier else 0,
    }


def _compute_otp_payout(
    conn: sqlite3.Connection, service_name: str, range_name: str, user_total_otps: int
) -> Dict[str, float]:
    """3-Tier Dynamic Pricing Waterfall (Tier 1 Service -> Tier 2 Range -> Tier 3 Global Default) * VIP * Peak."""
    svc_map = _get_config(conn, "service_pricing", {})
    rng_map = _get_config(conn, "range_pricing", {})
    global_usd = float(_get_config(conn, "global_otp_usd", 0.007))
    fx_rate = float(_get_config(conn, "fx_usd_to_pkr", 280.0))
    peak_pct = float(_get_config(conn, "peak_hour_boost_pct", 0.0))

    base_usd = global_usd
    if service_name in svc_map:
        base_usd = float(svc_map[service_name])
    elif range_name in rng_map:
        base_usd = float(rng_map[range_name])

    vip = _resolve_vip_tier(conn, user_total_otps)
    final_usd = round(base_usd * float(vip["multiplier"]) * (1.0 + peak_pct / 100.0), 6)
    final_pkr = round(final_usd * fx_rate, 2)
    return {"usd": final_usd, "pkr": final_pkr}


# ==============================================================================
# AUTH DEPENDENCIES (STRICT RBAC + FORCED ADMIN PASSWORD CHANGE GUARD)
# ==============================================================================
def _get_authenticated_account(
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token.")
    token = authorization.split(" ", 1)[1].strip()
    payload = decode_access_token(token)
    sid = payload.get("sid")
    acc_id = payload.get("sub")
    if not sid or not acc_id:
        raise HTTPException(status_code=401, detail="Malformed session token.")

    conn = _db()
    try:
        sess = conn.execute(
            "SELECT * FROM android_sessions WHERE session_id = ? AND account_id = ? AND revoked = 0",
            (sid, acc_id),
        ).fetchone()
        if not sess or sess["expires_at"] < int(time.time()):
            raise HTTPException(status_code=401, detail="Session revoked or expired.")
        acc = conn.execute("SELECT * FROM android_accounts WHERE id = ?", (acc_id,)).fetchone()
        if not acc:
            raise HTTPException(status_code=401, detail="Account not found.")
        res = dict(acc)
        res["session_id"] = sid
        res.pop("password_hash", None)
        return res
    finally:
        conn.close()


def require_approved_user(acc: Dict[str, Any] = Depends(_get_authenticated_account)) -> Dict[str, Any]:
    if acc["status"] != "APPROVED":
        raise HTTPException(
            status_code=403,
            detail=f"ACCOUNT_{acc['status']}: Your account is not approved for access.",
        )
    return acc


def require_master_admin_allow_pwd_change(
    acc: Dict[str, Any] = Depends(_get_authenticated_account),
) -> Dict[str, Any]:
    if acc["role"] != "ADMIN" or acc["username"].lower() != MASTER_ADMIN_USERNAME:
        raise HTTPException(status_code=403, detail="Admin access restricted to the single Master Admin account.")
    return acc


def require_master_admin(
    acc: Dict[str, Any] = Depends(require_master_admin_allow_pwd_change),
) -> Dict[str, Any]:
    if acc.get("must_change_password"):
        raise HTTPException(
            status_code=403,
            detail="FORCE_PASSWORD_CHANGE_REQUIRED: You must change the temporary bootstrap password before accessing Admin controls.",
        )
    return acc


# ==============================================================================
# PYDANTIC REQUEST SCHEMAS
# ==============================================================================
class SignupRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    username: str = Field(..., min_length=3, max_length=40, pattern=r"^[a-zA-Z0-9_.-]+$")
    email: str = Field(..., min_length=5, max_length=120)
    password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)
    phone: str = ""
    whatsapp: str = ""
    referral_code: str = ""


class LoginRequest(BaseModel):
    identifier: str = Field(..., min_length=3, max_length=120)  # username or email
    password: str = Field(..., min_length=1, max_length=128)
    device_name: str = "Android Device"


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
    confirm_new_password: str


class ClaimNumberRequest(BaseModel):
    number_id: Optional[int] = None
    country_name: Optional[str] = None
    service_name: Optional[str] = None
    range_name: Optional[str] = None
    prefix: Optional[str] = None


class ExchangeRequest(BaseModel):
    direction: str = Field(..., pattern=r"^(USD_TO_PKR|PKR_TO_USD)$")
    amount: float = Field(..., gt=0)


class WithdrawalCreateRequest(BaseModel):
    method: str = Field(..., pattern=r"^(USDT_POLYGON|BINANCE_PAY|USDT_TRC20|EASYPAISA|JAZZCASH|PK_BANK)$")
    bank_or_network: str = ""
    amount: float = Field(..., gt=0)
    destination: str = Field(..., min_length=4, max_length=160)
    account_title: str = ""


class TempMailCreateRequest(BaseModel):
    engine: str = "mailtm"
    custom_username: str = ""
    domain: str = ""


class SupportTicketCreateRequest(BaseModel):
    subject: str = Field(..., min_length=3, max_length=140)
    category: str = "General"
    message: str = Field(..., min_length=3, max_length=3000)
    attachment_url: str = ""


class SupportReplyRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=3000)
    attachment_url: str = ""
    close_ticket: bool = False


class PreferencesUpdateRequest(BaseModel):
    preferred_lang: Optional[str] = None
    preferred_currency: Optional[str] = None
    clean_mode: Optional[bool] = None
    notifications_enabled: Optional[bool] = None
    phone: Optional[str] = None
    whatsapp: Optional[str] = None


class AdminDecisionRequest(BaseModel):
    reason: str = ""
    tx_reference: str = ""


class AdminBalanceAdjustRequest(BaseModel):
    currency: str = Field(..., pattern=r"^(USD|PKR)$")
    delta: float
    note: str = "Admin adjustment"


class AdminPanelSaveRequest(BaseModel):
    id: Optional[str] = None
    name: str
    panel_type: str = "REST_CDR"
    base_url: str
    sms_endpoint: str = ""
    numbers_endpoint: str = ""
    ws_url: str = ""
    username: str = ""
    password: str = ""
    api_token: str = ""
    cli_restricted: bool = False
    enabled: bool = True


class AdminStockUploadRequest(BaseModel):
    country_name: str
    country_code: str
    country_flag: str = ""
    service_name: str = "All Services"
    range_name: str = ""
    panel_id: str = "default"
    numbers: List[str]


class AdminPricingSaveRequest(BaseModel):
    fx_usd_to_pkr: Optional[float] = None
    global_otp_usd: Optional[float] = None
    global_otp_pkr: Optional[float] = None
    referral_commission_pct: Optional[float] = None
    max_otp_per_number: Optional[int] = None
    peak_hour_boost_pct: Optional[float] = None
    service_pricing: Optional[Dict[str, float]] = None
    range_pricing: Optional[Dict[str, float]] = None
    streak_ladder_usd: Optional[List[float]] = None


class AdminBroadcastRequest(BaseModel):
    title: str
    message: str
    target: str = "ALL_APPROVED"  # ALL_APPROVED | ACTIVE_NUMBERS | VIP_ONLY


class AdminTvMethodRequest(BaseModel):
    title: str
    category: str = "Guide"
    description: str = ""
    video_url: str
    thumbnail_url: str = ""


# ==============================================================================
# ROUTER DEFINITION
# ==============================================================================
router = APIRouter(prefix="/api/v1", tags=["TeamLegend Android v1"])


# --- 1. AUTHENTICATION & REGISTRATION -----------------------------------------

@router.post("/auth/signup", status_code=201)
def user_signup(body: SignupRequest, request: Request) -> Dict[str, Any]:
    _check_rate_limit(f"signup:{request.client.host if request.client else 'local'}", limit=10, window_sec=60)
    if body.password != body.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match.")
    validate_password_strength(body.password)

    username_clean = body.username.strip()
    email_clean = body.email.strip().lower()
    if username_clean.lower() == MASTER_ADMIN_USERNAME or "admin" in username_clean.lower():
        raise HTTPException(status_code=400, detail="This username is reserved.")
    if "@" not in email_clean or "." not in email_clean.split("@")[-1]:
        raise HTTPException(status_code=400, detail="Please enter a valid email address.")

    conn = _db()
    try:
        dup = conn.execute(
            "SELECT id FROM android_accounts WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)",
            (username_clean, email_clean),
        ).fetchone()
        if dup:
            raise HTTPException(status_code=409, detail="Username or email address is already registered.")

        referred_by_id = None
        if body.referral_code.strip():
            ref_row = conn.execute(
                "SELECT id FROM android_accounts WHERE referral_code = ? AND status = 'APPROVED'",
                (body.referral_code.strip().upper(),),
            ).fetchone()
            if ref_row:
                referred_by_id = ref_row["id"]

        now = int(time.time())
        ref_code = generate_referral_code(username_clean)
        cur = conn.execute(
            """
            INSERT INTO android_accounts (
                full_name, username, email, password_hash, phone, whatsapp,
                role, status, must_change_password, referral_code, referred_by,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'USER', 'PENDING', 0, ?, ?, ?, ?)
            """,
            (
                body.full_name.strip(),
                username_clean,
                email_clean,
                hash_password(body.password),
                body.phone.strip(),
                body.whatsapp.strip(),
                ref_code,
                referred_by_id,
                now,
                now,
            ),
        )
        new_user_id = cur.lastrowid

        # Notify the single Master Admin
        admin_row = conn.execute("SELECT id FROM android_accounts WHERE role = 'ADMIN'").fetchone()
        if admin_row:
            _notify(
                conn,
                admin_row["id"],
                "New User Pending Approval",
                f"{body.full_name.strip()} (@{username_clean}) requested account access.",
                category="APPROVAL",
            )
        conn.commit()
        return {
            "status": "PENDING",
            "account_id": new_user_id,
            "username": username_clean,
            "message": "Registration submitted. Your account is pending Master Admin approval.",
        }
    finally:
        conn.close()


def _issue_session(conn: sqlite3.Connection, acc: sqlite3.Row, device_name: str, ip: str) -> Dict[str, Any]:
    now = int(time.time())
    sid = secrets.token_urlsafe(24)
    exp = now + SESSION_TTL_SECONDS
    token = create_access_token(
        {
            "sub": acc["id"],
            "sid": sid,
            "role": acc["role"],
            "username": acc["username"],
            "iat": now,
            "exp": exp,
        }
    )
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    conn.execute(
        "INSERT INTO android_sessions (session_id, account_id, token_hash, device_name, ip_address, created_at, expires_at, revoked) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, 0)",
        (sid, acc["id"], token_hash, device_name[:80], ip[:64], now, exp),
    )
    conn.commit()
    return {
        "access_token": token,
        "token_type": "Bearer",
        "expires_at": exp,
        "user": {
            "id": acc["id"],
            "full_name": acc["full_name"],
            "username": acc["username"],
            "email": acc["email"],
            "role": acc["role"],
            "status": acc["status"],
            "must_change_password": bool(acc["must_change_password"]),
            "referral_code": acc["referral_code"],
        },
    }


@router.post("/auth/login")
def user_login(body: LoginRequest, request: Request) -> Dict[str, Any]:
    ip = request.client.host if request.client else "local"
    _check_rate_limit(f"login:{ip}", limit=25, window_sec=60)
    ident = body.identifier.strip()

    conn = _db()
    try:
        acc = conn.execute(
            "SELECT * FROM android_accounts WHERE (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) AND role = 'USER'",
            (ident, ident),
        ).fetchone()
        if not acc or not verify_password(body.password, acc["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid username/email or password.")
        if acc["status"] == "PENDING":
            raise HTTPException(
                status_code=403,
                detail="ACCOUNT_PENDING: Your account is awaiting Admin approval.",
            )
        if acc["status"] == "REJECTED":
            raise HTTPException(
                status_code=403,
                detail=f"ACCOUNT_REJECTED: {acc['rejection_reason'] or 'Your registration was declined.'}",
            )
        if acc["status"] == "SUSPENDED":
            raise HTTPException(status_code=403, detail="ACCOUNT_SUSPENDED: Your account has been suspended.")
        return _issue_session(conn, acc, body.device_name, ip)
    finally:
        conn.close()


@router.post("/auth/admin/login")
def admin_login(body: LoginRequest, request: Request) -> Dict[str, Any]:
    ip = request.client.host if request.client else "local"
    _check_rate_limit(f"admin_login:{ip}", limit=15, window_sec=60)
    ident = body.identifier.strip().lower()
    if ident != MASTER_ADMIN_USERNAME:
        raise HTTPException(status_code=401, detail="Invalid Master Admin credentials.")

    conn = _db()
    try:
        acc = conn.execute(
            "SELECT * FROM android_accounts WHERE LOWER(username) = ? AND role = 'ADMIN'",
            (MASTER_ADMIN_USERNAME,),
        ).fetchone()
        if not acc or not verify_password(body.password, acc["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid Master Admin credentials.")
        _record_audit(conn, acc["id"], "ADMIN_LOGIN", "ACCOUNT", str(acc["id"]), {"device": body.device_name}, ip)
        return _issue_session(conn, acc, body.device_name, ip)
    finally:
        conn.close()


@router.post("/auth/logout")
def logout(acc: Dict[str, Any] = Depends(_get_authenticated_account)) -> Dict[str, Any]:
    conn = _db()
    try:
        conn.execute("UPDATE android_sessions SET revoked = 1 WHERE session_id = ?", (acc["session_id"],))
        conn.commit()
        return {"ok": True, "message": "Signed out cleanly."}
    finally:
        conn.close()


@router.post("/auth/change-password")
def user_change_password(
    body: ChangePasswordRequest,
    acc: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    if body.new_password != body.confirm_new_password:
        raise HTTPException(status_code=400, detail="New passwords do not match.")
    validate_password_strength(body.new_password)

    conn = _db()
    try:
        row = conn.execute("SELECT password_hash FROM android_accounts WHERE id = ?", (acc["id"],)).fetchone()
        if not row or not verify_password(body.current_password, row["password_hash"]):
            raise HTTPException(status_code=400, detail="Current password is incorrect.")
        conn.execute(
            "UPDATE android_accounts SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?",
            (hash_password(body.new_password), int(time.time()), acc["id"]),
        )
        conn.commit()
        return {"ok": True, "message": "Password updated successfully."}
    finally:
        conn.close()


@router.post("/admin/change-password")
def admin_change_password(
    body: ChangePasswordRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin_allow_pwd_change),
) -> Dict[str, Any]:
    if body.new_password != body.confirm_new_password:
        raise HTTPException(status_code=400, detail="New passwords do not match.")
    if body.new_password == body.current_password:
        raise HTTPException(status_code=400, detail="New password must differ from temporary password.")
    validate_password_strength(body.new_password)

    conn = _db()
    try:
        row = conn.execute("SELECT password_hash FROM android_accounts WHERE id = ?", (admin["id"],)).fetchone()
        if not row or not verify_password(body.current_password, row["password_hash"]):
            raise HTTPException(status_code=400, detail="Current password is incorrect.")
        conn.execute(
            "UPDATE android_accounts SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?",
            (hash_password(body.new_password), int(time.time()), admin["id"]),
        )
        _record_audit(
            conn,
            admin["id"],
            "ADMIN_PASSWORD_CHANGED",
            "ACCOUNT",
            str(admin["id"]),
            {"forced_reset_cleared": True},
            request.client.host if request.client else "local",
        )
        conn.commit()
        return {"ok": True, "must_change_password": False, "message": "Master Admin password updated."}
    finally:
        conn.close()


# --- 2. USER VAULT: DASHBOARD, NUMBERS, LIVE OTP, TEMP MAIL -------------------

@router.get("/user/dashboard")
def user_dashboard(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        acc = conn.execute("SELECT * FROM android_accounts WHERE id = ?", (user["id"],)).fetchone()
        active_nums = conn.execute(
            "SELECT COUNT(*) AS c FROM number_inventory WHERE assigned_user_id = ? AND status = 'ACTIVE'",
            (user["id"],),
        ).fetchone()["c"]
        refs = conn.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN status='APPROVED' THEN 1 ELSE 0 END) AS verified "
            "FROM android_accounts WHERE referred_by = ?",
            (user["id"],),
        ).fetchone()
        recent_otps = [
            dict(r)
            for r in conn.execute(
                "SELECT id, phone_number, sender, otp_code, service_name, country_name, payout_usd, payout_pkr, received_at "
                "FROM otp_messages WHERE assigned_user_id = ? ORDER BY received_at DESC LIMIT 8",
                (user["id"],),
            ).fetchall()
        ]
        notifs = [
            dict(r)
            for r in conn.execute(
                "SELECT id, title, body, category, is_read, created_at FROM android_notifications "
                "WHERE account_id = ? ORDER BY created_at DESC LIMIT 10",
                (user["id"],),
            ).fetchall()
        ]
        fx_rate = float(_get_config(conn, "fx_usd_to_pkr", 280.0))
        vip = _resolve_vip_tier(conn, acc["total_otps"])
        streak_ladder = _get_config(conn, "streak_ladder_usd", [0.005, 0.008, 0.012, 0.018, 0.025, 0.035, 0.05])
        next_claim_at = acc["last_streak_claim"] + 86400 if acc["last_streak_claim"] else 0

        return {
            "profile": {
                "id": acc["id"],
                "full_name": acc["full_name"],
                "username": acc["username"],
                "email": acc["email"],
                "status": acc["status"],
                "referral_code": acc["referral_code"],
                "preferred_lang": acc["preferred_lang"],
                "preferred_currency": acc["preferred_currency"],
            },
            "wallet": {
                "balance_usd": round(acc["balance_usd"], 4),
                "balance_pkr": round(acc["balance_pkr"], 2),
                "total_earnings_usd": round(acc["total_earnings_usd"], 4),
                "fx_usd_to_pkr": fx_rate,
            },
            "stats": {
                "active_numbers": active_nums,
                "total_number_requests": acc["total_number_requests"],
                "total_otps": acc["total_otps"],
                "referrals_total": refs["total"] or 0,
                "referrals_verified": refs["verified"] or 0,
            },
            "vip": vip,
            "streak": {
                "current_days": acc["streak_days"],
                "can_claim": int(time.time()) >= next_claim_at,
                "next_claim_at": next_claim_at,
                "ladder_usd": streak_ladder,
            },
            "recent_activity": recent_otps,
            "notifications": notifs,
            "system_status": {"online": True, "otp_engine": "OPERATIONAL", "server_time": int(time.time())},
        }
    finally:
        conn.close()


@router.get("/numbers/stock")
def get_live_stock(
    mode: str = Query(default="all", pattern=r"^(all|live24h|country|range|prefix)$"),
    country: Optional[str] = None,
    service: Optional[str] = None,
    range_name: Optional[str] = None,
    prefix: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    """
    Returns available stock across all 5 Main.py modes.
    Privacy invariant: NEVER returns internal panel_id or provider URLs to normal users.
    """
    conn = _db()
    try:
        clauses = ["status = 'AVAILABLE'"]
        params: List[Any] = []
        if country:
            clauses.append("LOWER(country_name) LIKE LOWER(?)")
            params.append(f"%{country.strip()}%")
        if service:
            clauses.append("LOWER(service_name) LIKE LOWER(?)")
            params.append(f"%{service.strip()}%")
        if range_name:
            clauses.append("LOWER(range_name) LIKE LOWER(?)")
            params.append(f"%{range_name.strip()}%")
        if prefix:
            clean_p = re.sub(r"\D", "", prefix)
            if len(clean_p) < 3 or len(clean_p) > 9:
                raise HTTPException(status_code=400, detail="Prefix search must be between 3 and 9 digits.")
            clauses.append("(prefix LIKE ? OR phone_number LIKE ?)")
            params.extend([f"{clean_p}%", f"%{clean_p}%"])

        where_sql = " AND ".join(clauses)
        rows = conn.execute(
            f"SELECT id, phone_number, country_name, country_code, country_flag, service_name, range_name, prefix "
            f"FROM number_inventory WHERE {where_sql} ORDER BY id DESC LIMIT 120",
            params,
        ).fetchall()

        countries = [
            dict(r)
            for r in conn.execute(
                "SELECT country_name, country_code, country_flag, COUNT(*) AS stock_count "
                "FROM number_inventory WHERE status = 'AVAILABLE' GROUP BY country_name, country_code, country_flag "
                "ORDER BY stock_count DESC"
            ).fetchall()
        ]
        ranges = [
            dict(r)
            for r in conn.execute(
                "SELECT range_name, country_name, COUNT(*) AS stock_count "
                "FROM number_inventory WHERE status = 'AVAILABLE' AND range_name != '' "
                "GROUP BY range_name, country_name ORDER BY stock_count DESC LIMIT 40"
            ).fetchall()
        ]
        return {
            "mode": mode,
            "total_available": len(rows),
            "countries": countries,
            "hot_ranges": ranges,
            "items": [dict(r) for r in rows],
            "synced_at": int(time.time()),
        }
    finally:
        conn.close()


@router.post("/numbers/claim")
def claim_number(body: ClaimNumberRequest, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        now = int(time.time())
        # Auto-expire stale locks
        conn.execute(
            "UPDATE number_inventory SET status = 'EXPIRED' WHERE status = 'ACTIVE' AND expires_at IS NOT NULL AND expires_at < ?",
            (now,),
        )
        clauses = ["status = 'AVAILABLE'"]
        params: List[Any] = []
        if body.number_id:
            clauses.append("id = ?")
            params.append(body.number_id)
        if body.country_name:
            clauses.append("LOWER(country_name) = LOWER(?)")
            params.append(body.country_name.strip())
        if body.service_name:
            clauses.append("LOWER(service_name) = LOWER(?)")
            params.append(body.service_name.strip())
        if body.range_name:
            clauses.append("LOWER(range_name) = LOWER(?)")
            params.append(body.range_name.strip())
        if body.prefix:
            clean_p = re.sub(r"\D", "", body.prefix)
            clauses.append("(prefix LIKE ? OR phone_number LIKE ?)")
            params.extend([f"{clean_p}%", f"%{clean_p}%"])

        row = conn.execute(
            f"SELECT id, phone_number, country_name, country_code, country_flag, service_name, range_name, prefix "
            f"FROM number_inventory WHERE {' AND '.join(clauses)} ORDER BY id ASC LIMIT 1",
            params,
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="No matching available stock right now. Join the waitlist to be notified.")

        expires_at = now + NUMBER_LOCK_SECONDS
        conn.execute(
            "UPDATE number_inventory SET status = 'ACTIVE', assigned_user_id = ?, assigned_at = ?, expires_at = ? "
            "WHERE id = ? AND status = 'AVAILABLE'",
            (user["id"], now, expires_at, row["id"]),
        )
        conn.execute(
            "UPDATE android_accounts SET total_number_requests = total_number_requests + 1, updated_at = ? WHERE id = ?",
            (now, user["id"]),
        )
        conn.commit()
        return {
            "ok": True,
            "number": {
                "id": row["id"],
                "phone_number": row["phone_number"],
                "country_name": row["country_name"],
                "country_code": row["country_code"],
                "country_flag": row["country_flag"],
                "service_name": row["service_name"],
                "range_name": row["range_name"],
                "assigned_at": now,
                "expires_at": expires_at,
                "status": "ACTIVE",
            },
        }
    finally:
        conn.close()


@router.post("/numbers/release/{number_id}")
def release_number(number_id: int, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT id, assigned_user_id, status FROM number_inventory WHERE id = ?",
            (number_id,),
        ).fetchone()
        if not row or row["assigned_user_id"] != user["id"]:
            raise HTTPException(status_code=404, detail="Active number not found for your account.")
        conn.execute(
            "UPDATE number_inventory SET status = 'CANCELLED' WHERE id = ?",
            (number_id,),
        )
        conn.commit()
        return {"ok": True, "number_id": number_id, "status": "CANCELLED"}
    finally:
        conn.close()


@router.get("/numbers/history")
def number_history(
    status_filter: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    conn = _db()
    try:
        sql = (
            "SELECT id, phone_number, country_name, country_code, country_flag, service_name, range_name, "
            "status, assigned_at, expires_at, otp_count FROM number_inventory WHERE assigned_user_id = ?"
        )
        params: List[Any] = [user["id"]]
        if status_filter:
            sql += " AND status = ?"
            params.append(status_filter.upper())
        sql += " ORDER BY assigned_at DESC LIMIT 100"
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        return {"items": rows}
    finally:
        conn.close()


@router.get("/otp/inbox")
def otp_inbox(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        mine = [
            dict(r)
            for r in conn.execute(
                "SELECT id, phone_number, sender, otp_code, full_message, country_name, service_name, "
                "payout_usd, payout_pkr, received_at FROM otp_messages WHERE assigned_user_id = ? "
                "ORDER BY received_at DESC LIMIT 60",
                (user["id"],),
            ).fetchall()
        ]
        # Public live feed with Prefix-Minus-One masking (zero user PII)
        public_feed = []
        for r in conn.execute(
            "SELECT id, phone_number, sender, service_name, country_name, received_at "
            "FROM otp_messages ORDER BY received_at DESC LIMIT 20"
        ).fetchall():
            public_feed.append(
                {
                    "id": r["id"],
                    "masked_number": mask_number_prefix_minus_one(r["phone_number"]),
                    "sender": r["sender"],
                    "service_name": r["service_name"],
                    "country_name": r["country_name"],
                    "received_at": r["received_at"],
                }
            )
        return {"my_otps": mine, "live_group_feed": public_feed}
    finally:
        conn.close()


@router.get("/otp/stream")
async def otp_sse_stream(user: Dict[str, Any] = Depends(require_approved_user)) -> StreamingResponse:
    async def event_gen():
        last_id = 0
        for _ in range(3):
            conn = _db()
            try:
                rows = conn.execute(
                    "SELECT id, phone_number, sender, otp_code, full_message, service_name, received_at "
                    "FROM otp_messages WHERE assigned_user_id = ? AND id > ? ORDER BY id ASC LIMIT 20",
                    (user["id"], last_id),
                ).fetchall()
                for r in rows:
                    last_id = r["id"]
                    yield f"event: otp\ndata: {json.dumps(dict(r))}\n\n"
            finally:
                conn.close()
            yield f"event: ping\ndata: {json.dumps({'ts': int(time.time())})}\n\n"
            await asyncio.sleep(1.5)

    return StreamingResponse(event_gen(), media_type="text/event-stream")


# --- 3. TEMP MAIL (8 ENGINES) -------------------------------------------------

@router.get("/tempmail/domains")
def tempmail_domains(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    engines = [dict(e) for e in TEMPMAIL_ENGINES]
    random.shuffle(engines)
    return {"engines": engines}


@router.get("/tempmail/mailboxes")
def tempmail_list(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        rows = [
            dict(r)
            for r in conn.execute(
                "SELECT id, address, engine, domain, created_at FROM tempmail_mailboxes "
                "WHERE account_id = ? ORDER BY created_at DESC",
                (user["id"],),
            ).fetchall()
        ]
        return {"mailboxes": rows}
    finally:
        conn.close()


@router.post("/tempmail/create", status_code=201)
def tempmail_create(body: TempMailCreateRequest, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    engine_obj = next((e for e in TEMPMAIL_ENGINES if e["id"] == body.engine), TEMPMAIL_ENGINES[0])
    domain = body.domain.strip() if body.domain.strip() in engine_obj["domains"] else random.choice(engine_obj["domains"])
    if body.custom_username.strip():
        local_part = re.sub(r"[^a-z0-9._-]", "", body.custom_username.strip().lower())
    else:
        first_names = ["hamza", "zain", "bilal", "ayesha", "sana", "usman", "tariq", "farhan", "nadia", "omar"]
        last_names = ["khan", "malik", "raza", "ali", "sheikh", "ahmed", "qureshi", "baig"]
        local_part = f"{random.choice(first_names)}.{random.choice(last_names)}{random.randint(10, 999)}"
    address = f"{local_part}@{domain}"

    conn = _db()
    try:
        now = int(time.time())
        cur = conn.execute(
            "INSERT INTO tempmail_mailboxes (account_id, address, engine, domain, token, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (user["id"], address, engine_obj["id"], domain, secrets.token_hex(16), now),
        )
        conn.commit()
        return {
            "id": cur.lastrowid,
            "address": address,
            "engine": engine_obj["id"],
            "domain": domain,
            "created_at": now,
        }
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="That temporary email address is already in use.")
    finally:
        conn.close()


@router.delete("/tempmail/{mailbox_id}")
def tempmail_delete(mailbox_id: int, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        cur = conn.execute(
            "DELETE FROM tempmail_mailboxes WHERE id = ? AND account_id = ?",
            (mailbox_id, user["id"]),
        )
        conn.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Mailbox not found.")
        return {"ok": True, "deleted_id": mailbox_id}
    finally:
        conn.close()


@router.get("/tempmail/{mailbox_id}/inbox")
def tempmail_inbox(mailbox_id: int, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        box = conn.execute(
            "SELECT id, address, engine, domain FROM tempmail_mailboxes WHERE id = ? AND account_id = ?",
            (mailbox_id, user["id"]),
        ).fetchone()
        if not box:
            raise HTTPException(status_code=404, detail="Mailbox not found.")
        msgs = [
            dict(r)
            for r in conn.execute(
                "SELECT id, sender, subject, body_text, extracted_otp, extracted_links_json, received_at "
                "FROM tempmail_messages WHERE mailbox_id = ? ORDER BY received_at DESC",
                (mailbox_id,),
            ).fetchall()
        ]
        return {"mailbox": dict(box), "messages": msgs}
    finally:
        conn.close()


# --- 4. WALLET, EXCHANGE, WITHDRAWALS, STREAKS, REFERRALS ---------------------

@router.get("/wallet")
def wallet_summary(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        acc = conn.execute(
            "SELECT balance_usd, balance_pkr, total_earnings_usd FROM android_accounts WHERE id = ?",
            (user["id"],),
        ).fetchone()
        txs = [
            dict(r)
            for r in conn.execute(
                "SELECT id, tx_type, currency, amount, balance_after, reference, note, created_at "
                "FROM wallet_transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 50",
                (user["id"],),
            ).fetchall()
        ]
        wds = [
            dict(r)
            for r in conn.execute(
                "SELECT id, method, bank_or_network, currency, amount, fee, net_amount, destination, status, tx_reference, created_at "
                "FROM withdrawal_requests WHERE account_id = ? ORDER BY created_at DESC LIMIT 30",
                (user["id"],),
            ).fetchall()
        ]
        return {
            "balance_usd": round(acc["balance_usd"], 4),
            "balance_pkr": round(acc["balance_pkr"], 2),
            "total_earnings_usd": round(acc["total_earnings_usd"], 4),
            "fx_usd_to_pkr": float(_get_config(conn, "fx_usd_to_pkr", 280.0)),
            "min_withdrawals": {
                "PKR": float(_get_config(conn, "min_wd_pkr", 100.0)),
                "USDT_POLYGON": float(_get_config(conn, "min_wd_usdt_polygon", 1.0)),
                "USDT_TRC20": float(_get_config(conn, "min_wd_usdt_trc20", 2.0)),
                "BINANCE_PAY": float(_get_config(conn, "min_wd_binance", 1.0)),
            },
            "pk_banks": PK_BANKS_AND_WALLETS,
            "transactions": txs,
            "withdrawals": wds,
        }
    finally:
        conn.close()


@router.post("/wallet/exchange")
def wallet_exchange(body: ExchangeRequest, user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        fx = float(_get_config(conn, "fx_usd_to_pkr", 280.0))
        acc = conn.execute("SELECT balance_usd, balance_pkr FROM android_accounts WHERE id = ?", (user["id"],)).fetchone()
        now = int(time.time())
        ref = f"FX-{secrets.token_hex(4).upper()}"

        if body.direction == "USD_TO_PKR":
            if acc["balance_usd"] < body.amount:
                raise HTTPException(status_code=400, detail="Insufficient USD balance.")
            new_usd = round(acc["balance_usd"] - body.amount, 6)
            credited_pkr = round(body.amount * fx, 2)
            new_pkr = round(acc["balance_pkr"] + credited_pkr, 2)
            conn.execute(
                "UPDATE android_accounts SET balance_usd = ?, balance_pkr = ?, updated_at = ? WHERE id = ?",
                (new_usd, new_pkr, now, user["id"]),
            )
            conn.execute(
                "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
                "VALUES (?, 'EXCHANGE_DEBIT', 'USD', ?, ?, ?, ?, ?)",
                (user["id"], -body.amount, new_usd, ref, f"Converted to {credited_pkr} PKR @ {fx}", now),
            )
            conn.execute(
                "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
                "VALUES (?, 'EXCHANGE_CREDIT', 'PKR', ?, ?, ?, ?, ?)",
                (user["id"], credited_pkr, new_pkr, ref, f"Converted from ${body.amount:.4f} USD @ {fx}", now),
            )
        else:
            if acc["balance_pkr"] < body.amount:
                raise HTTPException(status_code=400, detail="Insufficient PKR balance.")
            new_pkr = round(acc["balance_pkr"] - body.amount, 2)
            credited_usd = round(body.amount / fx, 6)
            new_usd = round(acc["balance_usd"] + credited_usd, 6)
            conn.execute(
                "UPDATE android_accounts SET balance_usd = ?, balance_pkr = ?, updated_at = ? WHERE id = ?",
                (new_usd, new_pkr, now, user["id"]),
            )
            conn.execute(
                "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
                "VALUES (?, 'EXCHANGE_DEBIT', 'PKR', ?, ?, ?, ?, ?)",
                (user["id"], -body.amount, new_pkr, ref, f"Converted to ${credited_usd:.4f} USD @ {fx}", now),
            )
            conn.execute(
                "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
                "VALUES (?, 'EXCHANGE_CREDIT', 'USD', ?, ?, ?, ?, ?)",
                (user["id"], credited_usd, new_usd, ref, f"Converted from {body.amount:.2f} PKR @ {fx}", now),
            )
        conn.commit()
        return {"ok": True, "reference": ref, "balance_usd": new_usd, "balance_pkr": new_pkr, "fx_rate": fx}
    finally:
        conn.close()


@router.post("/wallet/withdraw", status_code=201)
def request_withdrawal(
    body: WithdrawalCreateRequest,
    user: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    conn = _db()
    try:
        gateways = _get_config(conn, "gateways_enabled", {})
        if gateways and not gateways.get(body.method, True):
            raise HTTPException(status_code=400, detail=f"{body.method} withdrawals are currently disabled.")

        is_pkr = body.method in ("EASYPAISA", "JAZZCASH", "PK_BANK")
        currency = "PKR" if is_pkr else "USD"
        fx = float(_get_config(conn, "fx_usd_to_pkr", 280.0))

        min_map = {
            "EASYPAISA": float(_get_config(conn, "min_wd_pkr", 100.0)),
            "JAZZCASH": float(_get_config(conn, "min_wd_pkr", 100.0)),
            "PK_BANK": float(_get_config(conn, "min_wd_pkr", 100.0)),
            "USDT_POLYGON": float(_get_config(conn, "min_wd_usdt_polygon", 1.0)),
            "USDT_TRC20": float(_get_config(conn, "min_wd_usdt_trc20", 2.0)),
            "BINANCE_PAY": float(_get_config(conn, "min_wd_binance", 1.0)),
        }
        if body.amount < min_map[body.method]:
            raise HTTPException(
                status_code=400,
                detail=f"Minimum withdrawal for {body.method} is {min_map[body.method]} {currency}.",
            )

        acc = conn.execute("SELECT balance_usd, balance_pkr FROM android_accounts WHERE id = ?", (user["id"],)).fetchone()
        now = int(time.time())
        if is_pkr:
            if acc["balance_pkr"] < body.amount:
                raise HTTPException(status_code=400, detail="Insufficient PKR balance.")
            new_bal = round(acc["balance_pkr"] - body.amount, 2)
            conn.execute("UPDATE android_accounts SET balance_pkr = ?, updated_at = ? WHERE id = ?", (new_bal, now, user["id"]))
        else:
            if acc["balance_usd"] < body.amount:
                raise HTTPException(status_code=400, detail="Insufficient USD balance.")
            new_bal = round(acc["balance_usd"] - body.amount, 6)
            conn.execute("UPDATE android_accounts SET balance_usd = ?, updated_at = ? WHERE id = ?", (new_bal, now, user["id"]))

        cur = conn.execute(
            """
            INSERT INTO withdrawal_requests (
                account_id, method, bank_or_network, currency, amount, fee, net_amount,
                fx_rate, destination, account_title, status, created_at
            ) VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?, 'PENDING', ?)
            """,
            (
                user["id"],
                body.method,
                body.bank_or_network.strip() or body.method,
                currency,
                body.amount,
                body.amount,
                fx,
                body.destination.strip(),
                body.account_title.strip(),
                now,
            ),
        )
        wd_id = cur.lastrowid
        conn.execute(
            "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
            "VALUES (?, 'WITHDRAWAL_DEBIT', ?, ?, ?, ?, ?, ?)",
            (user["id"], currency, -body.amount, new_bal, f"WD-{wd_id}", f"{body.method} payout request", now),
        )
        conn.commit()
        return {"ok": True, "withdrawal_id": wd_id, "status": "PENDING", "currency": currency, "amount": body.amount}
    finally:
        conn.close()


@router.post("/rewards/claim-streak")
def claim_daily_streak(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        acc = conn.execute(
            "SELECT streak_days, last_streak_claim, balance_usd, total_earnings_usd FROM android_accounts WHERE id = ?",
            (user["id"],),
        ).fetchone()
        now = int(time.time())
        if acc["last_streak_claim"] and (now - acc["last_streak_claim"]) < 86400:
            raise HTTPException(status_code=400, detail="Daily bonus already claimed. Come back after 24 hours.")

        ladder = _get_config(conn, "streak_ladder_usd", [0.005, 0.008, 0.012, 0.018, 0.025, 0.035, 0.05])
        # Reset streak if more than 48h elapsed
        next_day = 1 if (acc["last_streak_claim"] and (now - acc["last_streak_claim"]) > 172800) else (acc["streak_days"] % len(ladder)) + 1
        reward_usd = float(ladder[next_day - 1])
        new_bal = round(acc["balance_usd"] + reward_usd, 6)
        new_earn = round(acc["total_earnings_usd"] + reward_usd, 6)

        conn.execute(
            "UPDATE android_accounts SET streak_days = ?, last_streak_claim = ?, balance_usd = ?, total_earnings_usd = ?, updated_at = ? WHERE id = ?",
            (next_day, now, new_bal, new_earn, now, user["id"]),
        )
        conn.execute(
            "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
            "VALUES (?, 'STREAK_BONUS', 'USD', ?, ?, ?, ?, ?)",
            (user["id"], reward_usd, new_bal, f"STREAK-D{next_day}", f"Day {next_day} daily streak reward", now),
        )
        conn.commit()
        return {"ok": True, "streak_day": next_day, "reward_usd": reward_usd, "balance_usd": new_bal}
    finally:
        conn.close()


@router.get("/referrals")
def referral_stats(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        pct = float(_get_config(conn, "referral_commission_pct", 5.0))
        rows = conn.execute(
            "SELECT username, status, total_otps, created_at FROM android_accounts WHERE referred_by = ? ORDER BY created_at DESC",
            (user["id"],),
        ).fetchall()
        commissions = [
            dict(r)
            for r in conn.execute(
                "SELECT amount, note, created_at FROM wallet_transactions "
                "WHERE account_id = ? AND tx_type = 'REFERRAL_COMMISSION' ORDER BY created_at DESC LIMIT 30",
                (user["id"],),
            ).fetchall()
        ]
        total_earned = sum(c["amount"] for c in commissions)
        return {
            "referral_code": user["referral_code"],
            "referral_link": f"https://teamlegendsofficial.site/?ref={user['referral_code']}",
            "commission_rate_pct": pct,
            "total_referrals": len(rows),
            "verified_referrals": sum(1 for r in rows if r["status"] == "APPROVED"),
            "total_referral_earnings_usd": round(total_earned, 4),
            "referrals": [
                {
                    "masked_user": mask_username_privacy(r["username"]),
                    "status": r["status"],
                    "otps": r["total_otps"],
                    "joined_at": r["created_at"],
                }
                for r in rows
            ],
            "commission_history": commissions,
        }
    finally:
        conn.close()


@router.get("/tv-methods")
def list_tv_methods(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        rows = [dict(r) for r in conn.execute("SELECT * FROM tv_methods ORDER BY created_at DESC").fetchall()]
        return {"methods": rows}
    finally:
        conn.close()


@router.get("/leaderboard")
def leaderboard(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT username, total_otps, total_earnings_usd FROM android_accounts "
            "WHERE role = 'USER' AND status = 'APPROVED' ORDER BY total_otps DESC, total_earnings_usd DESC LIMIT 25"
        ).fetchall()
        items = []
        for idx, r in enumerate(rows, start=1):
            items.append(
                {
                    "rank": idx,
                    "masked_user": mask_username_privacy(r["username"]),
                    "total_otps": r["total_otps"],
                    "vip_rank": _resolve_vip_tier(conn, r["total_otps"])["rank"],
                }
            )
        return {"leaderboard": items}
    finally:
        conn.close()


@router.get("/support/tickets")
def list_user_tickets(user: Dict[str, Any] = Depends(require_approved_user)) -> Dict[str, Any]:
    conn = _db()
    try:
        tickets = [
            dict(r)
            for r in conn.execute(
                "SELECT * FROM support_tickets WHERE account_id = ? ORDER BY updated_at DESC",
                (user["id"],),
            ).fetchall()
        ]
        for t in tickets:
            t["messages"] = [
                dict(m)
                for m in conn.execute(
                    "SELECT id, sender_role, message, attachment_url, created_at "
                    "FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC",
                    (t["id"],),
                ).fetchall()
            ]
        return {"tickets": tickets}
    finally:
        conn.close()


@router.post("/support/tickets", status_code=201)
def create_support_ticket(
    body: SupportTicketCreateRequest,
    user: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    conn = _db()
    try:
        now = int(time.time())
        cur = conn.execute(
            "INSERT INTO support_tickets (account_id, subject, category, status, created_at, updated_at) "
            "VALUES (?, ?, ?, 'OPEN', ?, ?)",
            (user["id"], body.subject.strip(), body.category.strip(), now, now),
        )
        tid = cur.lastrowid
        conn.execute(
            "INSERT INTO support_messages (ticket_id, sender_id, sender_role, message, attachment_url, created_at) "
            "VALUES (?, ?, 'USER', ?, ?, ?)",
            (tid, user["id"], body.message.strip(), body.attachment_url.strip(), now),
        )
        conn.commit()
        return {"ok": True, "ticket_id": tid, "status": "OPEN"}
    finally:
        conn.close()


@router.put("/preferences")
def update_preferences(
    body: PreferencesUpdateRequest,
    user: Dict[str, Any] = Depends(require_approved_user),
) -> Dict[str, Any]:
    conn = _db()
    try:
        updates = []
        params: List[Any] = []
        if body.preferred_lang in ("en", "ur"):
            updates.append("preferred_lang = ?")
            params.append(body.preferred_lang)
        if body.preferred_currency in ("USD", "PKR"):
            updates.append("preferred_currency = ?")
            params.append(body.preferred_currency)
        if body.clean_mode is not None:
            updates.append("clean_mode = ?")
            params.append(1 if body.clean_mode else 0)
        if body.notifications_enabled is not None:
            updates.append("notifications_enabled = ?")
            params.append(1 if body.notifications_enabled else 0)
        if body.phone is not None:
            updates.append("phone = ?")
            params.append(body.phone.strip())
        if body.whatsapp is not None:
            updates.append("whatsapp = ?")
            params.append(body.whatsapp.strip())
        if updates:
            updates.append("updated_at = ?")
            params.append(int(time.time()))
            params.append(user["id"])
            conn.execute(f"UPDATE android_accounts SET {', '.join(updates)} WHERE id = ?", params)
            conn.commit()
        return {"ok": True, "message": "Preferences saved."}
    finally:
        conn.close()


# --- 5. MASTER ADMIN COMMAND CENTER (STRICT SINGLE-ADMIN RBAC) ----------------

@router.get("/admin/overview")
def admin_overview(admin: Dict[str, Any] = Depends(require_master_admin)) -> Dict[str, Any]:
    conn = _db()
    try:
        u = conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status='APPROVED' THEN 1 ELSE 0 END) AS approved,
                SUM(CASE WHEN status='PENDING' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN status='REJECTED' THEN 1 ELSE 0 END) AS rejected,
                SUM(CASE WHEN status='SUSPENDED' THEN 1 ELSE 0 END) AS suspended,
                COALESCE(SUM(balance_usd), 0) AS total_usd,
                COALESCE(SUM(balance_pkr), 0) AS total_pkr
            FROM android_accounts WHERE role = 'USER'
            """
        ).fetchone()
        n = conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status='AVAILABLE' THEN 1 ELSE 0 END) AS available,
                SUM(CASE WHEN status='ACTIVE' THEN 1 ELSE 0 END) AS active
            FROM number_inventory
            """
        ).fetchone()
        otps_count = conn.execute("SELECT COUNT(*) AS c FROM otp_messages").fetchone()["c"]
        w = conn.execute(
            """
            SELECT
                SUM(CASE WHEN status='PENDING' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN status IN ('APPROVED', 'COMPLETED') THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN status IN ('REJECTED', 'FAILED') THEN 1 ELSE 0 END) AS failed
            FROM withdrawal_requests
            """
        ).fetchone()
        panels = [
            dict(r)
            for r in conn.execute(
                "SELECT id, name, panel_type, enabled, last_status, last_sync_at FROM admin_panels"
            ).fetchall()
        ]
        audits = [
            dict(r)
            for r in conn.execute(
                "SELECT id, action, target_type, target_id, created_at FROM admin_audit_logs ORDER BY id DESC LIMIT 15"
            ).fetchall()
        ]
        return {
            "users": dict(u),
            "numbers": dict(n),
            "total_otps": otps_count,
            "withdrawals": dict(w),
            "panels": panels,
            "recent_audit_logs": audits,
            "server_health": {"status": "HEALTHY", "db_mode": "SQLITE_WAL", "timestamp": int(time.time())},
        }
    finally:
        conn.close()


@router.get("/admin/users")
def admin_list_users(
    status_filter: Optional[str] = None,
    q: Optional[str] = None,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        clauses = ["role = 'USER'"]
        params: List[Any] = []
        if status_filter:
            clauses.append("status = ?")
            params.append(status_filter.upper())
        if q:
            clauses.append("(LOWER(username) LIKE LOWER(?) OR LOWER(email) LIKE LOWER(?) OR LOWER(full_name) LIKE LOWER(?))")
            like = f"%{q.strip()}%"
            params.extend([like, like, like])
        rows = [
            dict(r)
            for r in conn.execute(
                f"SELECT id, full_name, username, email, phone, whatsapp, status, balance_usd, balance_pkr, "
                f"total_otps, abuse_score, created_at, approved_at FROM android_accounts "
                f"WHERE {' AND '.join(clauses)} ORDER BY created_at DESC LIMIT 200",
                params,
            ).fetchall()
        ]
        return {"users": rows}
    finally:
        conn.close()


@router.post("/admin/users/{user_id}/approve")
def admin_approve_user(
    user_id: int,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        row = conn.execute("SELECT id, username, role FROM android_accounts WHERE id = ?", (user_id,)).fetchone()
        if not row or row["role"] == "ADMIN":
            raise HTTPException(status_code=404, detail="User not found.")
        now = int(time.time())
        conn.execute(
            "UPDATE android_accounts SET status = 'APPROVED', approved_at = ?, rejection_reason = '', updated_at = ? WHERE id = ?",
            (now, now, user_id),
        )
        _notify(conn, user_id, "Account Approved", "Your Team Legend account has been approved. You can now sign in.", "APPROVAL")
        _record_audit(conn, admin["id"], "APPROVE_USER", "USER", str(user_id), {"username": row["username"]}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "user_id": user_id, "status": "APPROVED"}
    finally:
        conn.close()


@router.post("/admin/users/{user_id}/reject")
def admin_reject_user(
    user_id: int,
    body: AdminDecisionRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        row = conn.execute("SELECT id, username, role FROM android_accounts WHERE id = ?", (user_id,)).fetchone()
        if not row or row["role"] == "ADMIN":
            raise HTTPException(status_code=404, detail="User not found.")
        now = int(time.time())
        conn.execute(
            "UPDATE android_accounts SET status = 'REJECTED', rejection_reason = ?, updated_at = ? WHERE id = ?",
            (body.reason.strip(), now, user_id),
        )
        _notify(conn, user_id, "Registration Declined", body.reason.strip() or "Your account request was declined.", "APPROVAL")
        _record_audit(conn, admin["id"], "REJECT_USER", "USER", str(user_id), {"reason": body.reason}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "user_id": user_id, "status": "REJECTED"}
    finally:
        conn.close()


@router.post("/admin/users/{user_id}/balance")
def admin_adjust_balance(
    user_id: int,
    body: AdminBalanceAdjustRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        acc = conn.execute("SELECT id, balance_usd, balance_pkr FROM android_accounts WHERE id = ? AND role = 'USER'", (user_id,)).fetchone()
        if not acc:
            raise HTTPException(status_code=404, detail="User not found.")
        now = int(time.time())
        col = "balance_usd" if body.currency == "USD" else "balance_pkr"
        new_val = round(max(0.0, acc[col] + body.delta), 4 if body.currency == "USD" else 2)
        tx_type = "ADMIN_CREDIT" if body.delta >= 0 else "ADMIN_DEBIT"
        conn.execute(f"UPDATE android_accounts SET {col} = ?, updated_at = ? WHERE id = ?", (new_val, now, user_id))
        conn.execute(
            "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, tx_type, body.currency, body.delta, new_val, f"ADM-{now}", body.note, now),
        )
        _record_audit(conn, admin["id"], tx_type, "USER", str(user_id), {"currency": body.currency, "delta": body.delta}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "user_id": user_id, "currency": body.currency, "new_balance": new_val}
    finally:
        conn.close()


@router.get("/admin/panels")
def admin_list_panels(admin: Dict[str, Any] = Depends(require_master_admin)) -> Dict[str, Any]:
    conn = _db()
    try:
        rows = [
            dict(r)
            for r in conn.execute(
                "SELECT id, name, panel_type, base_url, sms_endpoint, numbers_endpoint, ws_url, username, "
                "cli_restricted, enabled, last_status, last_sync_at, created_at FROM admin_panels ORDER BY created_at DESC"
            ).fetchall()
        ]
        return {"panels": rows}
    finally:
        conn.close()


@router.post("/admin/panels")
def admin_save_panel(
    body: AdminPanelSaveRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        pid = body.id or f"pnl_{secrets.token_hex(4)}"
        now = int(time.time())
        conn.execute(
            """
            INSERT INTO admin_panels (
                id, name, panel_type, base_url, sms_endpoint, numbers_endpoint, ws_url,
                username, password_enc, api_token, cli_restricted, enabled, last_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIGURED', ?)
            ON CONFLICT(id) DO UPDATE SET
                name=excluded.name, panel_type=excluded.panel_type, base_url=excluded.base_url,
                sms_endpoint=excluded.sms_endpoint, numbers_endpoint=excluded.numbers_endpoint,
                ws_url=excluded.ws_url, username=excluded.username, api_token=excluded.api_token,
                cli_restricted=excluded.cli_restricted, enabled=excluded.enabled
            """,
            (
                pid, body.name, body.panel_type, body.base_url, body.sms_endpoint,
                body.numbers_endpoint, body.ws_url, body.username, body.password,
                body.api_token, 1 if body.cli_restricted else 0, 1 if body.enabled else 0, now,
            ),
        )
        _record_audit(conn, admin["id"], "SAVE_PANEL", "PANEL", pid, {"name": body.name}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "panel_id": pid}
    finally:
        conn.close()


@router.post("/admin/stock/upload")
def admin_upload_stock(
    body: AdminStockUploadRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        now = int(time.time())
        added = 0
        for raw in body.numbers:
            digits = re.sub(r"\D", "", raw)
            if len(digits) < 7:
                continue
            formatted = f"+{digits}"
            prefix = digits[:6]
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO number_inventory (
                    phone_number, country_name, country_code, country_flag,
                    service_name, range_name, prefix, panel_id, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'AVAILABLE', ?)
                """,
                (
                    formatted, body.country_name.strip(), body.country_code.strip(),
                    body.country_flag.strip(), body.service_name.strip(),
                    body.range_name.strip(), prefix, body.panel_id.strip(), now,
                ),
            )
            added += cur.rowcount
        _record_audit(conn, admin["id"], "UPLOAD_STOCK", "STOCK", body.country_name, {"added": added}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "added": added}
    finally:
        conn.close()


@router.post("/admin/pricing")
def admin_save_pricing(
    body: AdminPricingSaveRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        data = body.model_dump(exclude_none=True) if hasattr(body, 'model_dump') else body.dict(exclude_none=True)
        for k, v in data.items():
            _set_config(conn, k, v)
        _record_audit(conn, admin["id"], "UPDATE_PRICING", "CONFIG", "pricing", data, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "updated_keys": list(data.keys())}
    finally:
        conn.close()


@router.get("/admin/withdrawals")
def admin_list_withdrawals(
    status_filter: Optional[str] = None,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        sql = (
            "SELECT w.*, a.username, a.full_name FROM withdrawal_requests w "
            "JOIN android_accounts a ON a.id = w.account_id"
        )
        params: List[Any] = []
        if status_filter:
            sql += " WHERE w.status = ?"
            params.append(status_filter.upper())
        sql += " ORDER BY w.created_at DESC LIMIT 150"
        return {"withdrawals": [dict(r) for r in conn.execute(sql, params).fetchall()]}
    finally:
        conn.close()


@router.post("/admin/withdrawals/{wd_id}/{decision}")
def admin_decide_withdrawal(
    wd_id: int,
    decision: str,
    body: AdminDecisionRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    if decision not in ("approve", "reject"):
        raise HTTPException(status_code=400, detail="Decision must be 'approve' or 'reject'.")
    conn = _db()
    try:
        wd = conn.execute("SELECT * FROM withdrawal_requests WHERE id = ?", (wd_id,)).fetchone()
        if not wd or wd["status"] != "PENDING":
            raise HTTPException(status_code=404, detail="Pending withdrawal request not found.")
        now = int(time.time())
        if decision == "approve":
            conn.execute(
                "UPDATE withdrawal_requests SET status = 'COMPLETED', tx_reference = ?, admin_note = ?, decided_at = ? WHERE id = ?",
                (body.tx_reference.strip(), body.reason.strip(), now, wd_id),
            )
            _notify(conn, wd["account_id"], "Withdrawal Completed", f"Your {wd['amount']} {wd['currency']} payout via {wd['method']} is completed.", "WALLET")
        else:
            # Refund balance on rejection
            col = "balance_pkr" if wd["currency"] == "PKR" else "balance_usd"
            acc = conn.execute(f"SELECT {col} AS bal FROM android_accounts WHERE id = ?", (wd["account_id"],)).fetchone()
            new_bal = round(acc["bal"] + wd["amount"], 2 if wd["currency"] == "PKR" else 6)
            conn.execute(f"UPDATE android_accounts SET {col} = ?, updated_at = ? WHERE id = ?", (new_bal, now, wd["account_id"]))
            conn.execute(
                "UPDATE withdrawal_requests SET status = 'REJECTED', admin_note = ?, decided_at = ? WHERE id = ?",
                (body.reason.strip(), now, wd_id),
            )
            conn.execute(
                "INSERT INTO wallet_transactions (account_id, tx_type, currency, amount, balance_after, reference, note, created_at) "
                "VALUES (?, 'WITHDRAWAL_REFUND', ?, ?, ?, ?, ?, ?)",
                (wd["account_id"], wd["currency"], wd["amount"], new_bal, f"WD-REFUND-{wd_id}", body.reason.strip() or "Withdrawal rejected & refunded", now),
            )
            _notify(conn, wd["account_id"], "Withdrawal Refunded", f"Your {wd['amount']} {wd['currency']} withdrawal was rejected and refunded.", "WALLET")

        _record_audit(conn, admin["id"], f"WITHDRAWAL_{decision.upper()}", "WITHDRAWAL", str(wd_id), {"ref": body.tx_reference}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "withdrawal_id": wd_id, "status": "COMPLETED" if decision == "approve" else "REJECTED"}
    finally:
        conn.close()


@router.post("/admin/broadcast/start")
def admin_broadcast(
    body: AdminBroadcastRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        users = conn.execute("SELECT id FROM android_accounts WHERE role = 'USER' AND status = 'APPROVED'").fetchall()
        for u in users:
            _notify(conn, u["id"], body.title.strip(), body.message.strip(), category="BROADCAST")
        _record_audit(conn, admin["id"], "BROADCAST_SENT", "USERS", str(len(users)), {"title": body.title}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "delivered_count": len(users)}
    finally:
        conn.close()


@router.post("/admin/tv-methods", status_code=201)
def admin_add_tv_method(
    body: AdminTvMethodRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_master_admin),
) -> Dict[str, Any]:
    conn = _db()
    try:
        now = int(time.time())
        cur = conn.execute(
            "INSERT INTO tv_methods (title, category, description, video_url, thumbnail_url, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (body.title.strip(), body.category.strip(), body.description.strip(), body.video_url.strip(), body.thumbnail_url.strip(), now),
        )
        _record_audit(conn, admin["id"], "ADD_TV_METHOD", "TV_METHOD", str(cur.lastrowid), {"title": body.title}, request.client.host if request.client else "local")
        conn.commit()
        return {"ok": True, "id": cur.lastrowid}
    finally:
        conn.close()


@router.get("/admin/system/backup")
def admin_download_backup(admin: Dict[str, Any] = Depends(require_master_admin)) -> StreamingResponse:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists(_ACTIVE_DB_PATH):
            zf.write(_ACTIVE_DB_PATH, arcname="teamlegend_android.db")
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=teamlegend_backup_{int(time.time())}.zip"},
    )


@router.get("/admin/audit-logs")
def admin_audit_logs(admin: Dict[str, Any] = Depends(require_master_admin)) -> Dict[str, Any]:
    conn = _db()
    try:
        rows = [
            dict(r)
            for r in conn.execute("SELECT * FROM admin_audit_logs ORDER BY id DESC LIMIT 100").fetchall()
        ]
        return {"logs": rows}
    finally:
        conn.close()


# ==============================================================================
# STANDALONE FASTAPI APP INSTANCE
# ==============================================================================
def create_app(db_path: Optional[str] = None, initial_admin_password: Optional[str] = None) -> FastAPI:
    bootstrap_android_backend(db_path=db_path, initial_admin_password=initial_admin_password)
    application = FastAPI(title="Team Legend Standalone Android API", version="2.0.0")
    origins = [o.strip() for o in os.environ.get("TL_CORS_ORIGINS", "*").split(",") if o.strip()]
    application.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    application.include_router(router)

    @application.get("/health")
    def health() -> Dict[str, Any]:
        return {"status": "ok", "service": "teamlegend-android-api", "ts": int(time.time())}

    return application


app = create_app()
