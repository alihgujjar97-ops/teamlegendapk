"""
Team Legend Android Clone — SQLite WAL Database Migrations & Schema Manager
Coexists cleanly with Main.py's 7 domain SQLite WAL DBs (db/*.db) and tempmail_vault.db.
"""

from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path
from typing import Optional

DEFAULT_DB_PATH = os.environ.get(
    "TL_ANDROID_DB_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "teamlegend_android.db"),
)

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

-- 1. Standalone Android Accounts (Single Master Admin + Normal Users with Approval Workflow)
CREATE TABLE IF NOT EXISTS android_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    phone TEXT DEFAULT '',
    whatsapp TEXT DEFAULT '',
    telegram_id TEXT DEFAULT '',
    role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('ADMIN', 'USER')),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED')),
    must_change_password INTEGER NOT NULL DEFAULT 0,
    referral_code TEXT NOT NULL UNIQUE,
    referred_by INTEGER DEFAULT NULL REFERENCES android_accounts(id),
    balance_usd REAL NOT NULL DEFAULT 0.0,
    balance_pkr REAL NOT NULL DEFAULT 0.0,
    total_earnings_usd REAL NOT NULL DEFAULT 0.0,
    total_otps INTEGER NOT NULL DEFAULT 0,
    total_number_requests INTEGER NOT NULL DEFAULT 0,
    streak_days INTEGER NOT NULL DEFAULT 0,
    last_streak_claim INTEGER NOT NULL DEFAULT 0,
    abuse_score INTEGER NOT NULL DEFAULT 0,
    preferred_lang TEXT NOT NULL DEFAULT 'en',
    preferred_currency TEXT NOT NULL DEFAULT 'USD',
    clean_mode INTEGER NOT NULL DEFAULT 0,
    notifications_enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    approved_at INTEGER DEFAULT NULL,
    rejection_reason TEXT DEFAULT ''
);

-- Enforce SINGLE MASTER ADMIN at database level via partial unique index
CREATE UNIQUE INDEX IF NOT EXISTS idx_single_master_admin
ON android_accounts(role)
WHERE role = 'ADMIN';

-- 2. Active Sessions & Refresh Tokens
CREATE TABLE IF NOT EXISTS android_sessions (
    session_id TEXT PRIMARY KEY,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    device_name TEXT DEFAULT '',
    ip_address TEXT DEFAULT '',
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    revoked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sessions_account ON android_sessions(account_id);

-- 3. Immutable Admin Audit Logs
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL REFERENCES android_accounts(id),
    action TEXT NOT NULL,
    target_type TEXT NOT NULL DEFAULT '',
    target_id TEXT NOT NULL DEFAULT '',
    details_json TEXT NOT NULL DEFAULT '{}',
    ip_address TEXT DEFAULT '',
    created_at INTEGER NOT NULL
);

-- 4. User & Admin Notifications
CREATE TABLE IF NOT EXISTS android_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'SYSTEM',
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_account ON android_notifications(account_id, is_read);

-- 5. Numbers Stock & Exclusive Allocations (30-min lock parity with Main.py)
CREATE TABLE IF NOT EXISTS number_inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone_number TEXT NOT NULL UNIQUE,
    country_name TEXT NOT NULL,
    country_code TEXT NOT NULL,
    country_flag TEXT NOT NULL DEFAULT '',
    service_name TEXT NOT NULL DEFAULT 'All Services',
    range_name TEXT NOT NULL DEFAULT '',
    prefix TEXT NOT NULL DEFAULT '',
    panel_id TEXT NOT NULL DEFAULT 'default',
    status TEXT NOT NULL DEFAULT 'AVAILABLE' CHECK(status IN ('AVAILABLE', 'ACTIVE', 'COMPLETED', 'EXPIRED', 'CANCELLED')),
    assigned_user_id INTEGER DEFAULT NULL REFERENCES android_accounts(id),
    assigned_at INTEGER DEFAULT NULL,
    expires_at INTEGER DEFAULT NULL,
    otp_count INTEGER NOT NULL DEFAULT 0,
    max_otp_quota INTEGER NOT NULL DEFAULT 5,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_num_status_country ON number_inventory(status, country_name);
CREATE INDEX IF NOT EXISTS idx_num_prefix ON number_inventory(prefix);
CREATE INDEX IF NOT EXISTS idx_num_assigned ON number_inventory(assigned_user_id, status);

-- 6. SMS & OTP Messages (with duplicate hash protection)
CREATE TABLE IF NOT EXISTS otp_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number_id INTEGER REFERENCES number_inventory(id),
    phone_number TEXT NOT NULL,
    assigned_user_id INTEGER REFERENCES android_accounts(id),
    sender TEXT NOT NULL DEFAULT 'SMS',
    otp_code TEXT NOT NULL DEFAULT '',
    full_message TEXT NOT NULL,
    country_name TEXT NOT NULL DEFAULT '',
    service_name TEXT NOT NULL DEFAULT '',
    payout_usd REAL NOT NULL DEFAULT 0.0,
    payout_pkr REAL NOT NULL DEFAULT 0.0,
    dedup_hash TEXT NOT NULL UNIQUE,
    received_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_otp_user ON otp_messages(assigned_user_id, received_at DESC);

-- 7. Wallet Ledger (Credits, Debits, Currency Exchanges, Referral Commissions, Streak Rewards)
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id),
    tx_type TEXT NOT NULL CHECK(tx_type IN ('OTP_CREDIT', 'STREAK_BONUS', 'MILESTONE_BONUS', 'REFERRAL_COMMISSION', 'EXCHANGE_DEBIT', 'EXCHANGE_CREDIT', 'WITHDRAWAL_DEBIT', 'WITHDRAWAL_REFUND', 'ADMIN_CREDIT', 'ADMIN_DEBIT')),
    currency TEXT NOT NULL CHECK(currency IN ('USD', 'PKR')),
    amount REAL NOT NULL,
    balance_after REAL NOT NULL,
    reference TEXT DEFAULT '',
    note TEXT DEFAULT '',
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_account ON wallet_transactions(account_id, created_at DESC);

-- 8. Withdrawals (USDT Polygon, Binance Pay, TRC-20, EasyPaisa, JazzCash, 29 PK Banks)
CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id),
    method TEXT NOT NULL,
    bank_or_network TEXT NOT NULL DEFAULT '',
    currency TEXT NOT NULL CHECK(currency IN ('USD', 'PKR')),
    amount REAL NOT NULL,
    fee REAL NOT NULL DEFAULT 0.0,
    net_amount REAL NOT NULL,
    fx_rate REAL NOT NULL DEFAULT 280.0,
    destination TEXT NOT NULL,
    account_title TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'APPROVED', 'COMPLETED', 'REJECTED', 'FAILED')),
    tx_reference TEXT DEFAULT '',
    admin_note TEXT DEFAULT '',
    created_at INTEGER NOT NULL,
    decided_at INTEGER DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS idx_wd_status ON withdrawal_requests(status, created_at DESC);

-- 9. Temp Mail Mailboxes & Messages (8-Engine Parity)
CREATE TABLE IF NOT EXISTS tempmail_mailboxes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id) ON DELETE CASCADE,
    address TEXT NOT NULL UNIQUE,
    engine TEXT NOT NULL DEFAULT 'mailtm',
    domain TEXT NOT NULL,
    token TEXT DEFAULT '',
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS tempmail_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mailbox_id INTEGER NOT NULL REFERENCES tempmail_mailboxes(id) ON DELETE CASCADE,
    sender TEXT NOT NULL,
    subject TEXT NOT NULL DEFAULT '(No Subject)',
    body_text TEXT NOT NULL DEFAULT '',
    extracted_otp TEXT DEFAULT '',
    extracted_links_json TEXT DEFAULT '[]',
    received_at INTEGER NOT NULL
);

-- 10. Support Tickets & Replies
CREATE TABLE IF NOT EXISTS support_tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id),
    subject TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'General',
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN', 'REPLIED', 'CLOSED')),
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS support_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    sender_id INTEGER NOT NULL REFERENCES android_accounts(id),
    sender_role TEXT NOT NULL CHECK(sender_role IN ('USER', 'ADMIN')),
    message TEXT NOT NULL,
    attachment_url TEXT DEFAULT '',
    created_at INTEGER NOT NULL
);

-- 11. Admin Panels, CLI Rules, TV Video Methods, System Config & Waitlist
CREATE TABLE IF NOT EXISTS admin_panels (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    panel_type TEXT NOT NULL DEFAULT 'REST_CDR',
    base_url TEXT NOT NULL,
    sms_endpoint TEXT DEFAULT '',
    numbers_endpoint TEXT DEFAULT '',
    ws_url TEXT DEFAULT '',
    username TEXT DEFAULT '',
    password_enc TEXT DEFAULT '',
    api_token TEXT DEFAULT '',
    cookies_json TEXT DEFAULT '{}',
    cli_restricted INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    last_status TEXT DEFAULT 'IDLE',
    last_sync_at INTEGER DEFAULT 0,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS cli_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_id TEXT NOT NULL,
    service_or_sender TEXT NOT NULL,
    rule_action TEXT NOT NULL DEFAULT 'ALLOW' CHECK(rule_action IN ('ALLOW', 'BLOCK')),
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS tv_methods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Guide',
    description TEXT NOT NULL DEFAULT '',
    video_url TEXT NOT NULL,
    thumbnail_url TEXT DEFAULT '',
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_waitlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL REFERENCES android_accounts(id) ON DELETE CASCADE,
    country_or_range TEXT NOT NULL,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS system_config (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at INTEGER NOT NULL
);
"""


def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or DEFAULT_DB_PATH
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def run_migrations(db_path: Optional[str] = None) -> str:
    path = db_path or DEFAULT_DB_PATH
    conn = get_connection(path)
    try:
        conn.executescript(SCHEMA_SQL)
        now = int(time.time())
        defaults = {
            "fx_usd_to_pkr": "280.0",
            "global_otp_usd": "0.007",
            "global_otp_pkr": "2.00",
            "referral_commission_pct": "5.0",
            "max_otp_per_number": "5",
            "peak_hour_boost_pct": "0.0",
            "min_wd_pkr": "100.0",
            "min_wd_usdt_polygon": "1.0",
            "min_wd_usdt_trc20": "2.0",
            "min_wd_binance": "1.0",
            "service_pricing": "{}",
            "range_pricing": "{}",
            "vip_tiers": '[{"name":"Bronze","min_otps":0,"multiplier":1.0},{"name":"Silver","min_otps":50,"multiplier":1.03},{"name":"Gold","min_otps":200,"multiplier":1.06},{"name":"VIP King","min_otps":500,"multiplier":1.10}]',
            "streak_ladder_usd": "[0.005, 0.008, 0.012, 0.018, 0.025, 0.035, 0.050]",
            "force_join_enabled": "false",
            "official_links": '{"website":"https://teamlegendsofficial.site/","support_tg":"https://t.me/teamlegendsofficial","channel_tg":"https://t.me/teamlegendsofficial"}',
            "apk_config": '{"version":"2.0.0","download_url":"https://teamlegendsofficial.site/download/app.apk"}',
            "gateways_enabled": '{"USDT_POLYGON":true,"BINANCE_PAY":true,"USDT_TRC20":true,"EASYPAISA":true,"JAZZCASH":true,"PK_BANK":true}',
            "abuse_shield": '{"max_claims_per_hour":15,"auto_ban_score":100,"silent_drop_on_quota":true}',
        }
        for k, v in defaults.items():
            conn.execute(
                "INSERT OR IGNORE INTO system_config (key, value_json, updated_at) VALUES (?, ?, ?)",
                (k, v, now),
            )
        conn.commit()
    finally:
        conn.close()
    return path


if __name__ == "__main__":
    migrated = run_migrations()
    print(f"[TeamLegend] Migrations applied successfully at: {migrated}")
