"""
NovaHost / Pterodactyl / VPS Universal Entrypoint (backend/main.py)
Auto-installs fastapi/uvicorn if missing, and works from /app or /app/backend.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_THIS_DIR = Path(__file__).resolve().parent
for _p in (str(_THIS_DIR), str(_THIS_DIR.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import fastapi  # noqa: F401
    import uvicorn  # noqa: F401
except ImportError:
    _req = _THIS_DIR / "requirements.txt"
    if not _req.exists():
        _req = _THIS_DIR.parent / "requirements.txt"
    print(f"[TeamLegend] Installing missing packages from {_req} ...", flush=True)
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--no-cache-dir", "-r", str(_req)])

try:
    from android_api_extension import app, router, bootstrap_android_backend
except ImportError:
    from backend.android_api_extension import app, router, bootstrap_android_backend

if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT") or os.environ.get("PORT") or "8080")
    uvicorn.run(app, host=host, port=port)
