"""
Comprehensive automated test suite for Team Legend Standalone Android Backend.
Verifies:
  - Single Master Admin bootstrap & forced first-login password change
  - Database-level single admin enforcement (cannot create a second admin)
  - User Signup -> Pending Approval -> Blocked Login -> Admin Approve -> Login
  - Strict RBAC (normal user cannot access any /admin/* endpoint)
  - Privacy isolation (stock endpoint never exposes panel_id or provider URLs)
  - Number Claim / Release, Temp Mail creation, Wallet Credit, Atomic FX Exchange,
    Daily Streak (no duplicate claim), Withdrawal + Rejection Refund.
"""

import os
import sqlite3
import tempfile

import pytest
from fastapi.testclient import TestClient

from backend.android_api_extension import create_app


@pytest.fixture()
def client():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_file = os.path.join(tmpdir, "test_tl.db")
        app = create_app(db_path=db_file, initial_admin_password="TempAdmin#99TestPass")
        with TestClient(app) as c:
            yield c, db_file


def test_single_master_admin_forced_password_change_and_full_lifecycle(client):
    c, db_file = client

    # 1. Admin login with temporary bootstrap password
    r = c.post("/api/v1/auth/admin/login", json={"identifier": "teamlegend_admin", "password": "TempAdmin#99TestPass"})
    assert r.status_code == 200
    admin_data = r.json()
    assert admin_data["user"]["role"] == "ADMIN"
    assert admin_data["user"]["must_change_password"] is True
    admin_headers = {"Authorization": f"Bearer {admin_data['access_token']}"}

    # 2. Admin controls MUST be blocked until temporary password is changed
    r_blocked = c.get("/api/v1/admin/overview", headers=admin_headers)
    assert r_blocked.status_code == 403
    assert "FORCE_PASSWORD_CHANGE_REQUIRED" in r_blocked.json()["detail"]

    # 3. Change temporary admin password
    r_pwd = c.post(
        "/api/v1/admin/change-password",
        headers=admin_headers,
        json={
            "current_password": "TempAdmin#99TestPass",
            "new_password": "NewMaster#88VaultPass",
            "confirm_new_password": "NewMaster#88VaultPass",
        },
    )
    assert r_pwd.status_code == 200
    assert r_pwd.json()["must_change_password"] is False

    # 4. Admin overview now accessible
    r_ov = c.get("/api/v1/admin/overview", headers=admin_headers)
    assert r_ov.status_code == 200

    # 5. DB enforces single Master Admin (cannot insert a second ADMIN row)
    conn = sqlite3.connect(db_file)
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            "INSERT INTO android_accounts (full_name, username, email, password_hash, role, status, referral_code, created_at, updated_at) "
            "VALUES ('Fake Admin', 'admin2', 'a2@test.com', 'x', 'ADMIN', 'APPROVED', 'TL-FAKE', 1, 1)"
        )
    conn.close()

    # 6. User Signup creates PENDING account & blocks login
    r_su = c.post(
        "/api/v1/auth/signup",
        json={
            "full_name": "Ali Raza",
            "username": "aliraza99",
            "email": "ali@example.com",
            "password": "UserPass123!",
            "confirm_password": "UserPass123!",
            "phone": "+923001234567",
        },
    )
    assert r_su.status_code == 201
    user_id = r_su.json()["account_id"]
    assert r_su.json()["status"] == "PENDING"

    r_login_pending = c.post("/api/v1/auth/login", json={"identifier": "aliraza99", "password": "UserPass123!"})
    assert r_login_pending.status_code == 403
    assert "ACCOUNT_PENDING" in r_login_pending.json()["detail"]

    # 7. Admin approves user -> User can now login
    r_app = c.post(f"/api/v1/admin/users/{user_id}/approve", headers=admin_headers)
    assert r_app.status_code == 200

    r_login_ok = c.post("/api/v1/auth/login", json={"identifier": "ali@example.com", "password": "UserPass123!"})
    assert r_login_ok.status_code == 200
    user_headers = {"Authorization": f"Bearer {r_login_ok.json()['access_token']}"}

    # 8. Strict RBAC: Normal user CANNOT access admin endpoints
    assert c.get("/api/v1/admin/overview", headers=user_headers).status_code == 403
    assert c.get("/api/v1/admin/panels", headers=user_headers).status_code == 403

    # 9. Admin uploads stock -> User fetches stock (no panel_id exposed!) -> Claims & Releases
    r_up = c.post(
        "/api/v1/admin/stock/upload",
        headers=admin_headers,
        json={
            "country_name": "United Kingdom",
            "country_code": "+44",
            "country_flag": "GB",
            "service_name": "WhatsApp",
            "range_name": "UK-4474",
            "panel_id": "secret_internal_panel_99",
            "numbers": ["+447412345678", "+447412345679"],
        },
    )
    assert r_up.status_code == 200
    assert r_up.json()["added"] == 2

    r_stock = c.get("/api/v1/numbers/stock?mode=prefix&prefix=4474", headers=user_headers)
    assert r_stock.status_code == 200
    assert r_stock.json()["total_available"] == 2
    assert "panel_id" not in r_stock.json()["items"][0]

    r_claim = c.post("/api/v1/numbers/claim", headers=user_headers, json={"prefix": "4474"})
    assert r_claim.status_code == 200
    num_id = r_claim.json()["number"]["id"]
    assert c.post(f"/api/v1/numbers/release/{num_id}", headers=user_headers).status_code == 200

    # 10. Temp Mail creation
    r_tm = c.post("/api/v1/tempmail/create", headers=user_headers, json={"engine": "mailtm"})
    assert r_tm.status_code == 201
    assert "@" in r_tm.json()["address"]

    # 11. Daily Streak claim + duplicate protection
    r_st1 = c.post("/api/v1/rewards/claim-streak", headers=user_headers)
    assert r_st1.status_code == 200
    r_st2 = c.post("/api/v1/rewards/claim-streak", headers=user_headers)
    assert r_st2.status_code == 400

    # 12. Admin credits USD -> User converts USD->PKR -> Requests Withdrawal -> Admin rejects & auto-refunds
    assert c.post(
        f"/api/v1/admin/users/{user_id}/balance",
        headers=admin_headers,
        json={"currency": "USD", "delta": 5.0, "note": "Test credit"},
    ).status_code == 200

    r_fx = c.post("/api/v1/wallet/exchange", headers=user_headers, json={"direction": "USD_TO_PKR", "amount": 2.0})
    assert r_fx.status_code == 200
    assert r_fx.json()["balance_pkr"] == 560.0

    r_wd = c.post(
        "/api/v1/wallet/withdraw",
        headers=user_headers,
        json={"method": "EASYPAISA", "amount": 300.0, "destination": "03001234567", "account_title": "Ali Raza"},
    )
    assert r_wd.status_code == 201
    wd_id = r_wd.json()["withdrawal_id"]

    r_rej = c.post(f"/api/v1/admin/withdrawals/{wd_id}/reject", headers=admin_headers, json={"reason": "Invalid account"})
    assert r_rej.status_code == 200

    r_wal = c.get("/api/v1/wallet", headers=user_headers)
    assert r_wal.json()["balance_pkr"] == 560.0
