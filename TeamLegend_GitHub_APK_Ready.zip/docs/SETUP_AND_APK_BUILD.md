# TEAM LEGEND — Setup & Installable APK Build Guide

## 1. Backend Deployment (Python FastAPI + SQLite WAL)
1. Copy `backend/.env.example` to `backend/.env` and set your real secrets:
   - `TL_ADMIN_USERNAME=teamlegend_admin`
   - `TL_ADMIN_INITIAL_PASSWORD=<your-bootstrap-password>`
   - `TL_JWT_SECRET=<64-char-random-hex>`
2. Install dependencies and start the server:
   ```bash
   pip install -r backend/requirements.txt
   uvicorn backend.android_api_extension:app --host 0.0.0.0 --port 8080
   ```
   Or mount directly inside your existing `Main.py`:
   ```python
   from backend.android_api_extension import router as android_v1_router, bootstrap_android_backend
   bootstrap_android_backend()
   app.include_router(android_v1_router)
   ```
3. On first Master Admin login (`teamlegend_admin`), the app will automatically enforce changing the temporary bootstrap password before unlocking Admin controls.

## 2. Build Installable `.apk` via GitHub Actions (No Android Studio Needed)
1. Extract `TeamLegend_Android_Clone_Full.zip` and push the folder to a private GitHub repository.
2. Open the **Actions** tab -> select **Build Team Legend Android APK** -> click **Run workflow**.
3. When the job completes (~3 minutes), download the **TeamLegend-Android-APKs** artifact containing `TeamLegend-v2.0.0-debug.apk` (ready to install directly on any Android 7.0+ phone).

## 3. Local Build in Android Studio
1. Open the `android/` directory in **Android Studio Koala / Ladybug** (JDK 17).
2. Let Gradle sync, then select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
