"""
TEAM LEGEND — Self-Bootstrapping Universal Entrypoint (Root main.py)
Automatically installs missing packages (fastapi, uvicorn, pydantic) on first boot
so `ModuleNotFoundError: No module named 'fastapi'` never happens on NovaHost,
Pterodactyl, Render, Railway, or VPS.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
BACKEND_DIR = ROOT_DIR / "backend"

for p in (str(ROOT_DIR), str(BACKEND_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)


def _ensure_dependencies() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        req_file = ROOT_DIR / "requirements.txt"
        if not req_file.exists():
            req_file = BACKEND_DIR / "requirements.txt"
        print(f"[TeamLegend] Installing missing packages from {req_file} ...", flush=True)
        cmd = [sys.executable, "-m", "pip", "install", "--no-cache-dir", "-r", str(req_file)]
        subprocess.check_call(cmd)


_ensure_dependencies()

from backend.android_api_extension import app, router, bootstrap_android_backend  # noqa: E402

if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT") or os.environ.get("PORT") or "8080")
    uvicorn.run(app, host=host, port=port)
